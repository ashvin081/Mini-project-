Suggested filenames:
royal-rajasthan.jpg
gujarat-explorer.jpg
kashmir-paradise.jpg
kerala-explorer.jpg
ladakh-adventure.jpg
