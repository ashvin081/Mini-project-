<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Select Hotel';

$tripId = (int)($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header("Location: ai-planner.php"); exit; }

if (empty($_SESSION['selection'][$tripId]['transport_id'])) {
    header("Location: transport.php?trip_id=$tripId");
    exit;
}

// Hotels tied to the two destinations configured for this package.
$cities = getTripRoute($trip);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hotelId = (int)($_POST['hotel_id'] ?? 0);
    $allowed = false;
    if ($hotelId > 0 && $cities) {
        $ph = implode(',', array_fill(0, count($cities), '?'));
        $check = $pdo->prepare("SELECT h.id FROM hotels h JOIN destinations d ON d.id=h.destination_id WHERE h.id=? AND h.status='active' AND d.name IN ($ph)");
        $check->execute(array_merge([$hotelId], $cities));
        $allowed = (bool)$check->fetchColumn();
    }
    if (!$allowed) { flash('error', 'Please choose a valid hotel for this package.'); header("Location: hotels.php?trip_id=$tripId"); exit; }
    $_SESSION['selection'][$tripId]['hotel_id'] = $hotelId;
    header("Location: activities.php?trip_id=$tripId");
    exit;
}

if (!empty($cities)) {
    $placeholders = implode(',', array_fill(0, count($cities), '?'));
    $stmt = $pdo->prepare("SELECT h.*, d.name AS dest_name FROM hotels h
        JOIN destinations d ON h.destination_id = d.id
        WHERE d.name IN ($placeholders) AND h.status = 'active'
        ORDER BY d.name, h.price_per_night");
    $stmt->execute($cities);
    $hotelList = $stmt->fetchAll();
} else {
    $hotelList = $pdo->query("SELECT h.*, d.name AS dest_name FROM hotels h JOIN destinations d ON h.destination_id = d.id WHERE h.status='active' ORDER BY d.name")->fetchAll();
}

// Smart default recommendation: choose one hotel from the user's budget + travel style.
// The recommendation is stored only when the user has not already made a choice,
// so changing the hotel always remains under the user's control.
$selection = $_SESSION['selection'][$tripId] ?? [];
if (!array_key_exists('hotel_id', $selection) && !empty($hotelList)) {
    $style = $trip['travel_style'] ?? 'Standard';
    $days = max(1, (int)$trip['days']);
    $budget = (float)$trip['budget'];

    if ($style === 'Budget') {
        usort($hotelList, function ($a, $b) {
            return (float)$a['price_per_night'] <=> (float)$b['price_per_night'];
        });
        $recommendedHotel = $hotelList[0];
    } elseif ($style === 'Luxury') {
        usort($hotelList, function ($a, $b) {
            $ratingCompare = (float)$b['rating'] <=> (float)$a['rating'];
            return $ratingCompare !== 0 ? $ratingCompare : ((float)$b['price_per_night'] <=> (float)$a['price_per_night']);
        });
        $recommendedHotel = $hotelList[0];
    } else {
        // Standard: select the hotel closest to a sensible per-night share of the trip budget.
        $targetNightly = max(1, ($budget * 0.25) / $days);
        usort($hotelList, function ($a, $b) use ($targetNightly) {
            $aDiff = abs((float)$a['price_per_night'] - $targetNightly);
            $bDiff = abs((float)$b['price_per_night'] - $targetNightly);
            return $aDiff <=> $bDiff;
        });
        $recommendedHotel = $hotelList[0];
    }

    $_SESSION['selection'][$tripId]['hotel_id'] = (int)$recommendedHotel['id'];
}

$selectedHotel = $_SESSION['selection'][$tripId]['hotel_id'] ?? null;

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="page-header">
        <h1>Select Your Hotel</h1>
        <p>A hotel is automatically recommended using your budget and travel style. You can change it anytime.</p>
    </div>

    <form method="POST" action="hotels.php?trip_id=<?php echo $tripId; ?>">
        <input type="hidden" name="trip_id" value="<?php echo $tripId; ?>">
        <div class="selection-note" style="margin:0 0 18px;padding:14px 16px;border:1px solid #b8dce2;border-radius:12px;background:#f3fbfc;color:#17324d;">
            <strong>✨ Smart recommendation applied</strong><br>
            <span>Based on your budget and travel style. Select any other hotel if you prefer.</span>
        </div>
        <div class="select-grid row g-4">
            <?php foreach ($hotelList as $h): ?>
                <label class="select-card col-md-6 col-lg-4 <?php echo (int)$selectedHotel === (int)$h['id'] ? 'selected' : ''; ?>">
                    <img src="<?php echo e($h['image']); ?>" alt="<?php echo e($h['name']); ?>" onerror="this.style.background='#d9e4e1';this.src='';">
                    <div class="select-card-body">
                        <span class="badge"><?php echo e($h['dest_name']); ?></span><?php if ((int)$selectedHotel === (int)$h['id']): ?><span class="badge" style="margin-left:6px; background:#dff4ea; color:#17643a;">Recommended ✓</span><?php endif; ?>
                        <h3><?php echo e($h['name']); ?></h3>
                        <div class="meta">⭐ <?php echo e($h['rating']); ?> · <?php echo e($h['room_type']); ?></div>
                        <div class="meta"><?php echo e($h['amenities']); ?></div>
                        <div class="price"><?php echo formatMoney($h['price_per_night']); ?>/night</div>
                        <label style="font-size:13px;"><input type="radio" name="hotel_id" value="<?php echo $h['id']; ?>" <?php echo (int)$selectedHotel === (int)$h['id'] ? 'checked' : ''; ?> required> Select this hotel</label>
                    </div>
                </label>
            <?php endforeach; ?>
        </div>
        <div class="hero-actions" style="justify-content:flex-start; margin-bottom:50px;">
            <a href="transport.php?trip_id=<?php echo $tripId; ?>" class="btn btn-outline">← Back</a>
            <button type="submit" class="btn btn-primary">Continue to Activities →</button>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
