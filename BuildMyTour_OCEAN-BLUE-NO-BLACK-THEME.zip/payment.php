<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Demo Payment';

$tripId = (int)($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header("Location: ai-planner.php"); exit; }

$sel = $_SESSION['selection'][$tripId] ?? null;
$checkoutInfo = $_SESSION['checkout'][$tripId] ?? null;
if (!$sel || !$checkoutInfo || empty($sel['transport_id']) || empty($sel['hotel_id']) || !isset($sel['total_cost'])) {
    header("Location: checkout.php?trip_id=$tripId");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $method = in_array($_POST['payment_method'] ?? '', ['UPI','Card','Net Banking']) ? $_POST['payment_method'] : 'UPI';

    $reference = generateBookingReference();
    $transactionId = generateTransactionId();

    $stmt = $pdo->prepare("UPDATE trips SET selected_transport_id=?, selected_hotel_id=?, selected_activity_ids=?, booking_reference=?, total_amount=?, payment_method=?, transaction_id=?, payment_status='success', booking_status='pending', status='booked' WHERE id=? AND user_id=?");
    $stmt->execute([
        $sel['transport_id'] ?? null, $sel['hotel_id'] ?? null,
        !empty($sel['activity_ids']) ? implode(',', array_map('intval', $sel['activity_ids'])) : null,
        $reference, (float)$sel['total_cost'], $method, $transactionId,
        $tripId, currentUserId()
    ]);

    unset($_SESSION['selection'][$tripId], $_SESSION['checkout'][$tripId]);

    header("Location: booking-confirmation.php?trip_id=$tripId");
    exit;
}

include 'includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1>Demo Payment</h1>
        <p>This is a demo checkout for a college mini project — no real payment gateway is connected.</p>
    </div>

    <div class="summary-box" style="max-width:600px;">
        <div class="summary-row total"><span>Amount to Pay</span><span><?php echo formatMoney($sel['total_cost']); ?></span></div>

        <form method="POST" action="payment.php?trip_id=<?php echo $tripId; ?>">
            <input type="hidden" name="trip_id" value="<?php echo $tripId; ?>">
            <h3 style="margin-top:20px;">Choose Payment Method</h3>
            <div class="payment-methods">
                <label class="payment-method active">
                    <input type="radio" name="payment_method" value="UPI" checked style="display:none;">
                    📱<br>UPI
                </label>
                <label class="payment-method">
                    <input type="radio" name="payment_method" value="Card" style="display:none;">
                    💳<br>Card
                </label>
                <label class="payment-method">
                    <input type="radio" name="payment_method" value="Net Banking" style="display:none;">
                    🏦<br>Net Banking
                </label>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Pay Now</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
