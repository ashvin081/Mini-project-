# BuildMyTour

**Project Title:** Smart Travel Planning and Booking System  
**Website Name:** BuildMyTour  
**Technology:** HTML5, CSS3, JavaScript, Bootstrap 5, PHP, MySQL

## Final College Mini Project Scope

- User registration and login
- Separate admin login
- Destination management
- Tour packages with package offers
- Hotel, transport and activity management
- Rule-based Smart Trip Planner
- Hotel, transport and activity recommendations
- Trip booking and payment simulation
- Admin booking approval and completion
- Completed-trip review with admin approval
- Exactly 8 database tables

## Database Tables

1. users
2. admins
3. destinations
4. tour_packages
5. hotels
6. transport
7. activities
8. trips

## Setup

1. Import `database/buildmytour.sql` in phpMyAdmin.
2. Update database credentials in `config/database.php` if required.
3. Place the project inside your local web server directory.
4. Open `index.php`.

### Demo Admin

- Email: `admin@buildmytour.com`
- Password: `admin123`

> For demonstration only, payment is simulated and no real payment gateway is used.
