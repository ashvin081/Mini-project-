<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Select Transport';

$tripId = (int)($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header("Location: ai-planner.php"); exit; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $transportId = (int)($_POST['transport_id'] ?? 0);
    $check = $pdo->prepare("SELECT id FROM transport WHERE id = ? AND status = 'active'");
    $check->execute([$transportId]);
    if (!$check->fetchColumn()) { flash('error', 'Please choose a valid transport option.'); header("Location: transport.php?trip_id=$tripId"); exit; }
    $_SESSION['selection'][$tripId]['transport_id'] = $transportId;
    header("Location: hotels.php?trip_id=$tripId");
    exit;
}

// Only Flight / Train / Bus, as per project scope
$stmt = $pdo->prepare("SELECT * FROM transport WHERE (from_location LIKE ? OR from_location LIKE '%') AND status = 'active' ORDER BY type, price");
$stmt->execute(["%{$trip['start_location']}%"]);
$options = $stmt->fetchAll();
if (empty($options)) {
    $options = $pdo->query("SELECT * FROM transport WHERE status = 'active' ORDER BY type, price")->fetchAll();
}

// Budget-based default recommendation.
// The user can still switch to Flight, Train or Bus manually.
$selectedTransport = $_SESSION['selection'][$tripId]['transport_id'] ?? null;
$budgetPerTraveler = ((float)$trip['budget']) / max(1, (int)$trip['travelers']);

if ($budgetPerTraveler >= 12000) {
    $recommendedType = 'Flight';
} elseif ($budgetPerTraveler >= 5000) {
    $recommendedType = 'Train';
} else {
    $recommendedType = 'Bus';
}

$availableTypes = array_values(array_unique(array_map(function ($opt) {
    return $opt['type'];
}, $options)));

// If the preferred recommendation is not available, choose the closest available option.
if (!in_array($recommendedType, $availableTypes, true)) {
    foreach (['Flight', 'Train', 'Bus'] as $fallbackType) {
        if (in_array($fallbackType, $availableTypes, true)) {
            $recommendedType = $fallbackType;
            break;
        }
    }
}

// When the user has not chosen anything yet, preselect the cheapest option
// inside the recommended transport type.
if (!$selectedTransport) {
    foreach ($options as $opt) {
        if ($opt['type'] === $recommendedType) {
            $selectedTransport = (int)$opt['id'];
            break;
        }
    }
}

$activeType = $recommendedType;
foreach ($options as $opt) {
    if ((int)$opt['id'] === (int)$selectedTransport) {
        $activeType = $opt['type'];
        break;
    }
}

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="page-header">
        <h1>Select Transport</h1>
        <p>Choose how you'd like to travel for this trip. Prices shown are demo data for this project.</p>
    </div>

    <div class="transport-recommendation">
        <strong>Recommended for your budget:</strong> <?php echo e($activeType); ?>
        <span>You can change it anytime using the Flight, Train or Bus options below.</span>
    </div>

    <div class="transport-tabs" aria-label="Transport type">
        <div class="transport-tab <?php echo $activeType === 'Flight' ? 'active' : ''; ?>" data-type="Flight">Flight</div>
        <div class="transport-tab <?php echo $activeType === 'Train' ? 'active' : ''; ?>" data-type="Train">Train</div>
        <div class="transport-tab <?php echo $activeType === 'Bus' ? 'active' : ''; ?>" data-type="Bus">Bus</div>
    </div>

    <form method="POST" action="transport.php?trip_id=<?php echo $tripId; ?>">
        <input type="hidden" name="trip_id" value="<?php echo $tripId; ?>">
        <div class="select-grid row g-4">
            <?php foreach ($options as $opt): ?>
                <?php
                    $transportImages = [
                        'Flight' => 'assets/images/transport/flight.png',
                        'Train'  => 'assets/images/transport/train.png',
                        'Bus'    => 'assets/images/transport/bus.png'
                    ];
                    $imagePath = $transportImages[$opt['type']] ?? '';
                ?>
                <label class="select-card col-md-6 col-lg-4 transport-option <?php echo (int)$selectedTransport === (int)$opt['id'] ? 'selected' : ''; ?>" data-type="<?php echo e($opt['type']); ?>" style="<?php echo $opt['type'] === $activeType ? '' : 'display:none;'; ?>">
                    <?php if ($imagePath): ?>
                        <img class="transport-card-image" src="<?php echo e($imagePath); ?>" alt="<?php echo e($opt['type']); ?> travel option">
                    <?php endif; ?>
                    <div class="select-card-body">
                        <span class="badge"><?php echo e($opt['type']); ?></span>
                        <h3><?php echo e($opt['provider']); ?></h3>
                        <div class="meta"><?php echo e($opt['from_location']); ?> → <?php echo e($opt['to_location']); ?></div>
                        <div class="meta">Departs <?php echo e($opt['departure']); ?> · Arrives <?php echo e($opt['arrival']); ?> · <?php echo e($opt['duration']); ?></div>
                        <div class="price"><?php echo formatMoney($opt['price']); ?>/person</div>
                        <input type="radio" name="transport_id" value="<?php echo $opt['id']; ?>" <?php echo (int)$selectedTransport === (int)$opt['id'] ? 'checked' : ''; ?> style="margin-bottom:8px;" required>
                        Select this option
                    </div>
                </label>
            <?php endforeach; ?>
        </div>
        <div class="hero-actions" style="justify-content:flex-start; margin-bottom:50px;">
            <a href="ai-planner.php" class="btn btn-outline">← Back</a>
            <button type="submit" class="btn btn-primary">Continue to Hotels →</button>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
