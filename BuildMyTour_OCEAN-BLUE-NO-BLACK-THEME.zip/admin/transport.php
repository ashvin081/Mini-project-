<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Transport';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $type = in_array($_POST['type'], ['Flight','Train','Bus']) ? $_POST['type'] : 'Train';
        $provider = trim($_POST['provider']);
        $from_location = trim($_POST['from_location']);
        $to_location = trim($_POST['to_location']);
        $departure = trim($_POST['departure']);
        $arrival = trim($_POST['arrival']);
        $duration = trim($_POST['duration']);
        $price = (float)$_POST['price'];
        $seats = (int)$_POST['seats'];
        $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';

        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO transport (type, provider, from_location, to_location, departure, arrival, duration, price, seats, status) VALUES (?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$type, $provider, $from_location, $to_location, $departure, $arrival, $duration, $price, $seats, $status]);
        } else {
            $id = (int)$_POST['id'];
            $stmt = $pdo->prepare("UPDATE transport SET type=?, provider=?, from_location=?, to_location=?, departure=?, arrival=?, duration=?, price=?, seats=?, status=? WHERE id=?");
            $stmt->execute([$type, $provider, $from_location, $to_location, $departure, $arrival, $duration, $price, $seats, $status, $id]);
        }
    }

    if ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM transport WHERE id = ?");
        $stmt->execute([(int)$_POST['id']]);
    }

    header("Location: transport.php");
    exit;
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM transport WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch();
}

$transportList = $pdo->query("SELECT * FROM transport ORDER BY id DESC")->fetchAll();
include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div><h1>Transport</h1><p>Manage available transport options for travelers.</p></div>
    <div class="admin-page-meta">Admin Panel</div>
</div>

<div class="admin-form-card">
    <h3><?php echo $editItem ? 'Edit Transport' : 'Add New Transport'; ?></h3>
    <form method="POST" action="transport.php">
        <input type="hidden" name="action" value="<?php echo $editItem ? 'edit' : 'add'; ?>">
        <?php if ($editItem): ?><input type="hidden" name="id" value="<?php echo $editItem['id']; ?>"><?php endif; ?>
        <div class="form-row">
            <div class="form-group"><label>Type</label>
                <select name="type" class="form-control">
                    <?php foreach (['Flight','Train','Bus'] as $t): ?>
                        <option value="<?php echo $t; ?>" <?php echo (($editItem['type'] ?? '') === $t) ? 'selected' : ''; ?>><?php echo $t; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Provider</label><input type="text" name="provider" class="form-control" value="<?php echo e($editItem['provider'] ?? ''); ?>" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>From</label><input type="text" name="from_location" class="form-control" value="<?php echo e($editItem['from_location'] ?? ''); ?>" required></div>
            <div class="form-group"><label>To</label><input type="text" name="to_location" class="form-control" value="<?php echo e($editItem['to_location'] ?? ''); ?>" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Departure</label><input type="text" name="departure" class="form-control" value="<?php echo e($editItem['departure'] ?? ''); ?>" placeholder="e.g. 07:00 AM"></div>
            <div class="form-group"><label>Arrival</label><input type="text" name="arrival" class="form-control" value="<?php echo e($editItem['arrival'] ?? ''); ?>" placeholder="e.g. 01:00 PM"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Duration</label><input type="text" name="duration" class="form-control" value="<?php echo e($editItem['duration'] ?? ''); ?>" placeholder="e.g. 6h"></div>
            <div class="form-group"><label>Price</label><input type="number" name="price" class="form-control" value="<?php echo e($editItem['price'] ?? ''); ?>" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Seats</label><input type="number" name="seats" class="form-control" value="<?php echo e($editItem['seats'] ?? '40'); ?>"></div>
            <div class="form-group"><label>Status</label>
                <select name="status" class="form-control">
                    <option value="active" <?php echo (($editItem['status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (($editItem['status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $editItem ? 'Update' : 'Add'; ?> Transport</button>
        <?php if ($editItem): ?><a href="transport.php" class="btn btn-outline">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="admin-table-card">
    <div class="admin-table-card-head"><h2>Transport records</h2><span>Latest data</span></div>
    <div class="admin-table-scroll">
    <table>
    <tr><th>ID</th><th>Type</th><th>Provider</th><th>Route</th><th>Price</th><th>Status</th><th>Actions</th></tr>
    <?php foreach ($transportList as $t): ?>
    <tr>
        <td><?php echo $t['id']; ?></td>
        <td><?php echo e($t['type']); ?></td>
        <td><?php echo e($t['provider']); ?></td>
        <td><?php echo e($t['from_location']); ?> → <?php echo e($t['to_location']); ?></td>
        <td><?php echo formatMoney($t['price']); ?></td>
        <td><span class="admin-status-badge admin-status-<?php echo e($t['status']); ?>"><?php echo ucfirst(e($t['status'])); ?></span></td>
        <td class="admin-actions">
            <a class="admin-action-link" href="transport.php?edit=<?php echo $t['id']; ?>">Edit</a>
            <form method="POST" action="transport.php" style="display:inline;" onsubmit="return confirm('Delete this transport option?');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?php echo $t['id']; ?>">
                <button type="submit" class="admin-delete-btn">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
    </div>
</div>

<?php include '../includes/admin-footer.php'; ?>
