<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Trips & Bookings';

// Admin can keep a booking Pending or change it to Confirmed / Cancelled.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId = (int)($_POST['trip_id'] ?? 0);
    $status = $_POST['booking_status'] ?? '';
    $allowed = ['pending', 'confirmed', 'completed', 'cancelled'];

    if ($bookingId > 0 && in_array($status, $allowed, true)) {
        $stmt = $pdo->prepare("UPDATE trips SET booking_status = ? WHERE id = ?");
        $stmt->execute([$status, $bookingId]);
        $tripStatus = $status === 'completed' ? 'completed' : ($status === 'cancelled' ? 'planned' : 'booked');
        $stmt = $pdo->prepare("UPDATE trips SET status = ? WHERE id = ?");
        $stmt->execute([$tripStatus, $bookingId]);

        flash('success', 'Booking status updated to ' . ucfirst($status) . '.');
    }

    header('Location: bookings.php');
    exit;
}

$bookings = $pdo->query("SELECT t.*, u.name AS user_name, u.email FROM trips t JOIN users u ON t.user_id = u.id WHERE t.booking_status != 'not_booked' ORDER BY CASE t.booking_status WHEN 'pending' THEN 0 WHEN 'confirmed' THEN 1 WHEN 'completed' THEN 2 ELSE 3 END, t.created_at DESC")->fetchAll();
$successMsg = flash('success');
include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div><h1>Trips & Booking Management</h1><p>Review planned trips, booking requests and update their booking status.</p></div>
    <div class="admin-page-meta">Admin Panel</div>
</div>
<?php if ($successMsg): ?><div class="alert alert-success admin-alert"><?php echo e($successMsg); ?></div><?php endif; ?>

<div class="admin-table-card">
    <div class="admin-table-card-head"><h2>All booking requests</h2><span>Latest data</span></div>
    <div class="admin-table-scroll">
    <table>
    <tr><th>Ref</th><th>User</th><th>Destination</th><th>Dates</th><th>Amount</th><th>Payment</th><th>Status</th></tr>
    <?php foreach ($bookings as $b): ?>
    <tr>
        <td><?php echo e($b['booking_reference']); ?></td>
        <td><?php echo e($b['user_name']); ?><br><small><?php echo e($b['email']); ?></small></td>
        <td><?php echo e($b['destination']); ?></td>
        <td><?php echo date('d M', strtotime($b['start_date'])); ?> – <?php echo date('d M Y', strtotime($b['end_date'])); ?></td>
        <td><?php echo formatMoney($b['total_amount']); ?></td>
        <td><?php echo e($b['payment_method']); ?> (<?php echo e($b['payment_status']); ?>)</td>
        <td>
            <details class="booking-status-menu status-<?php echo e($b['booking_status']); ?>">
                <summary>
                    <span class="status-label"><?php echo $b['booking_status'] === 'confirmed' ? 'Confirmed' : ($b['booking_status'] === 'completed' ? 'Completed' : ($b['booking_status'] === 'cancelled' ? 'Cancelled' : 'Pending')); ?></span>
                    <span class="status-arrow">⌄</span>
                </summary>
                <form method="POST" class="booking-status-options">
                    <input type="hidden" name="trip_id" value="<?php echo (int)$b['id']; ?>">
                    <button type="submit" name="booking_status" value="pending" class="status-option <?php echo $b['booking_status'] === 'pending' ? 'is-active' : ''; ?>">Pending</button>
                    <button type="submit" name="booking_status" value="confirmed" class="status-option <?php echo $b['booking_status'] === 'confirmed' ? 'is-active' : ''; ?>">Confirm</button>
                    <button type="submit" name="booking_status" value="completed" class="status-option <?php echo $b['booking_status'] === 'completed' ? 'is-active' : ''; ?>">Complete</button>
                    <button type="submit" name="booking_status" value="cancelled" class="status-option <?php echo $b['booking_status'] === 'cancelled' ? 'is-active' : ''; ?>">Cancel</button>
                </form>
            </details>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
    </div>
</div>

<?php include '../includes/admin-footer.php'; ?>
