<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Activities';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $hasActivityCategory = activityCategoryAvailable($pdo);

    if ($action === 'add' || $action === 'edit') {
        $destination_id = (int)$_POST['destination_id'];
        $name = trim($_POST['name']);
        $description = trim($_POST['description']);
        $duration = trim($_POST['duration']);
        $price = (float)$_POST['price'];
        $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';
        $category = trim($_POST['category'] ?? '');

        if ($action === 'add') {
            if ($hasActivityCategory) {
                $stmt = $pdo->prepare("INSERT INTO activities (destination_id, name, description, duration, price, category, status) VALUES (?,?,?,?,?,?,?)");
                $stmt->execute([$destination_id, $name, $description, $duration, $price, $category ?: 'Culture', $status]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO activities (destination_id, name, description, duration, price, status) VALUES (?,?,?,?,?,?)");
                $stmt->execute([$destination_id, $name, $description, $duration, $price, $status]);
            }
        } else {
            $id = (int)$_POST['id'];
            if ($hasActivityCategory) {
                $stmt = $pdo->prepare("UPDATE activities SET destination_id=?, name=?, description=?, duration=?, price=?, category=?, status=? WHERE id=?");
                $stmt->execute([$destination_id, $name, $description, $duration, $price, $category ?: 'Culture', $status, $id]);
            } else {
                $stmt = $pdo->prepare("UPDATE activities SET destination_id=?, name=?, description=?, duration=?, price=?, status=? WHERE id=?");
                $stmt->execute([$destination_id, $name, $description, $duration, $price, $status, $id]);
            }
        }
    }

    if ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM activities WHERE id = ?");
        $stmt->execute([(int)$_POST['id']]);
    }

    header("Location: activities.php");
    exit;
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM activities WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch();
}

$destinations = $pdo->query("SELECT id, name FROM destinations ORDER BY name")->fetchAll();
$activities = $pdo->query("SELECT a.*, d.name AS dest_name FROM activities a JOIN destinations d ON a.destination_id = d.id ORDER BY a.id DESC")->fetchAll();
include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div><h1>Activities</h1><p>Manage activities and experiences for each destination.</p></div>
    <div class="admin-page-meta">Admin Panel</div>
</div>

<div class="admin-form-card">
    <h3><?php echo $editItem ? 'Edit Activity' : 'Add New Activity'; ?></h3>
    <form method="POST" action="activities.php">
        <input type="hidden" name="action" value="<?php echo $editItem ? 'edit' : 'add'; ?>">
        <?php if ($editItem): ?><input type="hidden" name="id" value="<?php echo $editItem['id']; ?>"><?php endif; ?>
        <div class="form-row">
            <div class="form-group"><label>Destination</label>
                <select name="destination_id" class="form-control" required>
                    <?php foreach ($destinations as $d): ?>
                        <option value="<?php echo $d['id']; ?>" <?php echo (($editItem['destination_id'] ?? 0) == $d['id']) ? 'selected' : ''; ?>><?php echo e($d['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Activity Name</label><input type="text" name="name" class="form-control" value="<?php echo e($editItem['name'] ?? ''); ?>" required></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="2"><?php echo e($editItem['description'] ?? ''); ?></textarea></div>
        <div class="form-row">
            <?php if (activityCategoryAvailable($pdo)): ?>
            <div class="form-group"><label>Category</label>
                <select name="category" class="form-control">
                    <?php foreach (['Historical','Nature','Adventure','Culture','Food','Shopping'] as $cat): ?>
                    <option value="<?php echo $cat; ?>" <?php echo (($editItem['category'] ?? 'Culture') === $cat) ? 'selected' : ''; ?>><?php echo $cat; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <?php endif; ?>
            <div class="form-group"><label>Duration</label><input type="text" name="duration" class="form-control" value="<?php echo e($editItem['duration'] ?? ''); ?>" placeholder="e.g. 2h"></div>
            <div class="form-group"><label>Price</label><input type="number" name="price" class="form-control" value="<?php echo e($editItem['price'] ?? '0'); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Status</label>
                <select name="status" class="form-control">
                    <option value="active" <?php echo (($editItem['status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (($editItem['status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $editItem ? 'Update' : 'Add'; ?> Activity</button>
        <?php if ($editItem): ?><a href="activities.php" class="btn btn-outline">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="admin-table-card">
    <div class="admin-table-card-head"><h2>Activity records</h2><span>Latest data</span></div>
    <div class="admin-table-scroll">
    <table>
    <tr><th>ID</th><th>Name</th><th>Destination</th><?php if (activityCategoryAvailable($pdo)): ?><th>Category</th><?php endif; ?><th>Price</th><th>Status</th><th>Actions</th></tr>
    <?php foreach ($activities as $a): ?>
    <tr>
        <td><?php echo $a['id']; ?></td>
        <td><?php echo e($a['name']); ?></td>
        <td><?php echo e($a['dest_name']); ?></td>
        <?php if (activityCategoryAvailable($pdo)): ?><td><?php echo e($a['category'] ?? '-'); ?></td><?php endif; ?>
        <td><?php echo $a['price'] > 0 ? formatMoney($a['price']) : 'Free'; ?></td>
        <td><span class="admin-status-badge admin-status-<?php echo e($a['status']); ?>"><?php echo ucfirst(e($a['status'])); ?></span></td>
        <td class="admin-actions">
            <a class="admin-action-link" href="activities.php?edit=<?php echo $a['id']; ?>">Edit</a>
            <form method="POST" action="activities.php" style="display:inline;" onsubmit="return confirm('Delete this activity?');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?php echo $a['id']; ?>">
                <button type="submit" class="admin-delete-btn">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
    </div>
</div>

<?php include '../includes/admin-footer.php'; ?>
