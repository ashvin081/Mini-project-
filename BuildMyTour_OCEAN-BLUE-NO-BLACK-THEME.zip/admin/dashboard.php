<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Dashboard';

$counts = [
    'users' => $pdo->query("SELECT COUNT(*) c FROM users")->fetch()['c'],
    'destinations' => $pdo->query("SELECT COUNT(*) c FROM destinations")->fetch()['c'],
    'hotels' => $pdo->query("SELECT COUNT(*) c FROM hotels")->fetch()['c'],
    'transport' => $pdo->query("SELECT COUNT(*) c FROM transport")->fetch()['c'],
    'activities' => $pdo->query("SELECT COUNT(*) c FROM activities")->fetch()['c'],
    'trips' => $pdo->query("SELECT COUNT(*) c FROM trips")->fetch()['c'],
    'bookings' => $pdo->query("SELECT COUNT(*) c FROM trips WHERE booking_status != 'not_booked'")->fetch()['c'],
    'pending' => $pdo->query("SELECT COUNT(*) c FROM trips WHERE booking_status='pending'")->fetch()['c'],
    'confirmed' => $pdo->query("SELECT COUNT(*) c FROM trips WHERE booking_status='confirmed'")->fetch()['c'],
    'cancelled' => $pdo->query("SELECT COUNT(*) c FROM trips WHERE booking_status='cancelled'")->fetch()['c'],
    'pending_reviews' => $pdo->query("SELECT COUNT(*) c FROM trips WHERE review_status='pending'")->fetch()['c'],
    'approved_reviews' => $pdo->query("SELECT COUNT(*) c FROM trips WHERE review_status='approved'")->fetch()['c'],
];

include '../includes/admin-header.php';
?>

<div class="admin-dashboard-head">
    <div>
        <h1>Admin Dashboard</h1>
        <p>Welcome back, <?php echo e($_SESSION['admin_name'] ?? 'Admin'); ?>. Here's an overview of BuildMyTour.</p>
    </div>
    <div class="admin-date"><?php echo date('l, d M Y'); ?></div>
</div>

<section class="dashboard-section">
    <div class="dashboard-section-title"><h2>PLATFORM OVERVIEW</h2></div>
    <div class="admin-stats-grid three">
        <div class="admin-stat-card"><div class="admin-stat-icon">◉</div><div class="admin-stat-value"><?php echo $counts['users']; ?></div><p class="admin-stat-label">Registered Users</p></div>
        <div class="admin-stat-card"><div class="admin-stat-icon">⌖</div><div class="admin-stat-value"><?php echo $counts['trips']; ?></div><p class="admin-stat-label">Trips Planned</p></div>
        <div class="admin-stat-card booking"><div class="admin-stat-icon">▤</div><div class="admin-stat-value"><?php echo $counts['bookings']; ?></div><p class="admin-stat-label">Total Bookings</p></div>
    </div>
</section>

<section class="dashboard-section">
    <div class="dashboard-section-title"><h2>BOOKING STATUS</h2><a href="bookings.php">Manage Bookings →</a></div>
    <div class="admin-stats-grid three">
        <div class="admin-stat-card pending"><div class="admin-stat-icon">◷</div><div class="admin-stat-value"><?php echo $counts['pending']; ?></div><p class="admin-stat-label">Pending Approval</p></div>
        <div class="admin-stat-card confirmed"><div class="admin-stat-icon">✓</div><div class="admin-stat-value"><?php echo $counts['confirmed']; ?></div><p class="admin-stat-label">Confirmed Bookings</p></div>
        <div class="admin-stat-card cancelled"><div class="admin-stat-icon">×</div><div class="admin-stat-value"><?php echo $counts['cancelled']; ?></div><p class="admin-stat-label">Cancelled Bookings</p></div>
    </div>
</section>

<section class="dashboard-section">
    <div class="dashboard-section-title"><h2>ENGAGEMENT</h2><a href="reviews.php">Manage Reviews →</a></div>
    <div class="admin-stats-grid three">
        <div class="admin-stat-card pending"><div class="admin-stat-icon">★</div><div class="admin-stat-value"><?php echo $counts['pending_reviews']; ?></div><p class="admin-stat-label">Pending Reviews</p></div>
        <div class="admin-stat-card confirmed"><div class="admin-stat-icon">★</div><div class="admin-stat-value"><?php echo $counts['approved_reviews']; ?></div><p class="admin-stat-label">Approved Reviews</p></div>
        <div class="admin-stat-card"><div class="admin-stat-icon">◈</div><div class="admin-stat-value"><?php echo $pdo->query("SELECT COUNT(*) FROM tour_packages")->fetchColumn(); ?></div><p class="admin-stat-label">Tour Packages</p></div>
    </div>
</section>

<section class="dashboard-section">
    <div class="dashboard-section-title"><h2>TRAVEL CONTENT</h2></div>
    <div class="admin-stats-grid four">
        <div class="admin-stat-card"><div class="admin-stat-icon">⌖</div><div class="admin-stat-value"><?php echo $counts['destinations']; ?></div><p class="admin-stat-label">Destinations</p></div>
        <div class="admin-stat-card"><div class="admin-stat-icon">▣</div><div class="admin-stat-value"><?php echo $counts['hotels']; ?></div><p class="admin-stat-label">Hotels</p></div>
        <div class="admin-stat-card"><div class="admin-stat-icon">↔</div><div class="admin-stat-value"><?php echo $counts['transport']; ?></div><p class="admin-stat-label">Transport Options</p></div>
        <div class="admin-stat-card"><div class="admin-stat-icon">★</div><div class="admin-stat-value"><?php echo $counts['activities']; ?></div><p class="admin-stat-label">Activities</p></div>
    </div>
</section>

<?php include '../includes/admin-footer.php'; ?>
