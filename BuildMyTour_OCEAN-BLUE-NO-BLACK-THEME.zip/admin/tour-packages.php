<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Tour Packages & Offers';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    if ($action === 'add' || $action === 'edit') {
        $name = trim($_POST['name'] ?? '');
        $description = trim($_POST['description'] ?? '');
        $duration = trim($_POST['duration'] ?? '');
        $price = max(0, (float)($_POST['price'] ?? 0));
        $image = trim($_POST['image'] ?? '');
        $offer = max(0, min(100, (float)($_POST['offer_percentage'] ?? 0)));
        $start = $_POST['offer_start_date'] ?: null;
        $end = $_POST['offer_end_date'] ?: null;
        $status = ($_POST['status'] ?? 'active') === 'inactive' ? 'inactive' : 'active';
        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO tour_packages (name,description,duration,price,image,offer_percentage,offer_start_date,offer_end_date,status) VALUES (?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$name,$description,$duration,$price,$image,$offer,$start,$end,$status]);
        } else {
            $id=(int)$_POST['id'];
            $stmt=$pdo->prepare("UPDATE tour_packages SET name=?,description=?,duration=?,price=?,image=?,offer_percentage=?,offer_start_date=?,offer_end_date=?,status=? WHERE id=?");
            $stmt->execute([$name,$description,$duration,$price,$image,$offer,$start,$end,$status,$id]);
        }
    }
    if ($action === 'delete') { $stmt=$pdo->prepare("DELETE FROM tour_packages WHERE id=?"); $stmt->execute([(int)$_POST['id']]); }
    header('Location: tour-packages.php'); exit;
}
$editItem=null;
if (!empty($_GET['edit'])) { $stmt=$pdo->prepare("SELECT * FROM tour_packages WHERE id=?"); $stmt->execute([(int)$_GET['edit']]); $editItem=$stmt->fetch(); }
$items=$pdo->query("SELECT * FROM tour_packages ORDER BY id DESC")->fetchAll();
include '../includes/admin-header.php';
?>
<div class="admin-page-header"><div><h1>Tour Packages & Offers</h1><p>Manage package prices and optional offers. Offers use the existing tour_packages table.</p></div><div class="admin-page-meta">No extra offer table</div></div>
<div class="admin-form-card"><h3><?php echo $editItem ? 'Edit Tour Package' : 'Add Tour Package'; ?></h3>
<form method="POST"><input type="hidden" name="action" value="<?php echo $editItem?'edit':'add'; ?>"><?php if($editItem): ?><input type="hidden" name="id" value="<?php echo $editItem['id']; ?>"><?php endif; ?>
<div class="form-row"><div class="form-group"><label>Package Name</label><input class="form-control" name="name" required value="<?php echo e($editItem['name']??''); ?>"></div><div class="form-group"><label>Duration</label><input class="form-control" name="duration" required value="<?php echo e($editItem['duration']??''); ?>"></div></div>
<div class="form-group"><label>Description</label><textarea class="form-control" name="description" rows="2"><?php echo e($editItem['description']??''); ?></textarea></div>
<div class="form-row"><div class="form-group"><label>Regular Price (₹)</label><input type="number" min="0" class="form-control" name="price" required value="<?php echo e($editItem['price']??''); ?>"></div><div class="form-group"><label>Offer Percentage</label><input type="number" min="0" max="100" step="0.01" class="form-control" name="offer_percentage" value="<?php echo e($editItem['offer_percentage']??0); ?>"></div></div>
<div class="form-row"><div class="form-group"><label>Offer Start Date (optional)</label><input type="date" class="form-control" name="offer_start_date" value="<?php echo e($editItem['offer_start_date']??''); ?>"></div><div class="form-group"><label>Offer End Date (optional)</label><input type="date" class="form-control" name="offer_end_date" value="<?php echo e($editItem['offer_end_date']??''); ?>"></div></div>
<div class="form-row"><div class="form-group"><label>Image Path</label><input class="form-control" name="image" value="<?php echo e($editItem['image']??''); ?>"></div><div class="form-group"><label>Status</label><select class="form-control" name="status"><option value="active" <?php echo (($editItem['status']??'active')==='active')?'selected':''; ?>>Active</option><option value="inactive" <?php echo (($editItem['status']??'')==='inactive')?'selected':''; ?>>Inactive</option></select></div></div>
<button class="btn btn-primary"><?php echo $editItem?'Update':'Add'; ?> Package</button><?php if($editItem): ?><a class="btn btn-outline" href="tour-packages.php">Cancel</a><?php endif; ?>
</form></div>
<div class="admin-table-card"><div class="admin-table-card-head"><h2>Packages</h2><span>Offer management</span></div><div class="admin-table-scroll"><table><tr><th>Name</th><th>Duration</th><th>Regular Price</th><th>Offer</th><th>Final Price</th><th>Status</th><th>Actions</th></tr><?php foreach($items as $item): ?><tr><td><?php echo e($item['name']); ?></td><td><?php echo e($item['duration']); ?></td><td><?php echo formatMoney($item['price']); ?></td><td><?php echo packageOfferActive($item)?e(packageOfferLabel($item)):'—'; ?></td><td><?php echo formatMoney(packageOfferPrice($item)); ?></td><td><span class="admin-status-badge admin-status-<?php echo e($item['status']); ?>"><?php echo e(ucfirst($item['status'])); ?></span></td><td class="admin-actions"><a class="admin-action-link" href="tour-packages.php?edit=<?php echo $item['id']; ?>">Edit</a><form method="POST" style="display:inline" onsubmit="return confirm('Delete this package?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo $item['id']; ?>"><button class="admin-delete-btn">Delete</button></form></td></tr><?php endforeach; ?></table></div></div>
<?php include '../includes/admin-footer.php'; ?>
