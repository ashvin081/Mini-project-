<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Hotels';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $destination_id = (int)$_POST['destination_id'];
        $name = trim($_POST['name']);
        $rating = (float)$_POST['rating'];
        $room_type = trim($_POST['room_type']);
        $price_per_night = (float)$_POST['price_per_night'];
        $amenities = trim($_POST['amenities']);
        $image = trim($_POST['image']);
        $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';

        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO hotels (destination_id, name, rating, room_type, price_per_night, amenities, image, status) VALUES (?,?,?,?,?,?,?,?)");
            $stmt->execute([$destination_id, $name, $rating, $room_type, $price_per_night, $amenities, $image, $status]);
        } else {
            $id = (int)$_POST['id'];
            $stmt = $pdo->prepare("UPDATE hotels SET destination_id=?, name=?, rating=?, room_type=?, price_per_night=?, amenities=?, image=?, status=? WHERE id=?");
            $stmt->execute([$destination_id, $name, $rating, $room_type, $price_per_night, $amenities, $image, $status, $id]);
        }
    }

    if ($action === 'delete') {
        $stmt = $pdo->prepare("DELETE FROM hotels WHERE id = ?");
        $stmt->execute([(int)$_POST['id']]);
    }

    header("Location: hotels.php");
    exit;
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM hotels WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch();
}

$destinations = $pdo->query("SELECT id, name FROM destinations ORDER BY name")->fetchAll();
$hotels = $pdo->query("SELECT h.*, d.name AS dest_name FROM hotels h JOIN destinations d ON h.destination_id = d.id ORDER BY h.id DESC")->fetchAll();
include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div><h1>Hotels</h1><p>Manage hotel options available for each destination.</p></div>
    <div class="admin-page-meta">Admin Panel</div>
</div>

<div class="admin-form-card">
    <h3><?php echo $editItem ? 'Edit Hotel' : 'Add New Hotel'; ?></h3>
    <form method="POST" action="hotels.php">
        <input type="hidden" name="action" value="<?php echo $editItem ? 'edit' : 'add'; ?>">
        <?php if ($editItem): ?><input type="hidden" name="id" value="<?php echo $editItem['id']; ?>"><?php endif; ?>
        <div class="form-row">
            <div class="form-group"><label>Destination</label>
                <select name="destination_id" class="form-control" required>
                    <?php foreach ($destinations as $d): ?>
                        <option value="<?php echo $d['id']; ?>" <?php echo (($editItem['destination_id'] ?? 0) == $d['id']) ? 'selected' : ''; ?>><?php echo e($d['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group"><label>Hotel Name</label><input type="text" name="name" class="form-control" value="<?php echo e($editItem['name'] ?? ''); ?>" required></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Rating</label><input type="number" step="0.1" min="1" max="5" name="rating" class="form-control" value="<?php echo e($editItem['rating'] ?? '4.0'); ?>"></div>
            <div class="form-group"><label>Room Type</label><input type="text" name="room_type" class="form-control" value="<?php echo e($editItem['room_type'] ?? ''); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Price / Night</label><input type="number" name="price_per_night" class="form-control" value="<?php echo e($editItem['price_per_night'] ?? ''); ?>" required></div>
            <div class="form-group"><label>Status</label>
                <select name="status" class="form-control">
                    <option value="active" <?php echo (($editItem['status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (($editItem['status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <div class="form-group"><label>Amenities</label><input type="text" name="amenities" class="form-control" value="<?php echo e($editItem['amenities'] ?? ''); ?>"></div>
        <div class="form-group"><label>Image Path</label><input type="text" name="image" class="form-control" value="<?php echo e($editItem['image'] ?? 'assets/images/placeholder.jpg'); ?>"></div>
        <button type="submit" class="btn btn-primary"><?php echo $editItem ? 'Update' : 'Add'; ?> Hotel</button>
        <?php if ($editItem): ?><a href="hotels.php" class="btn btn-outline">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="admin-table-card">
    <div class="admin-table-card-head"><h2>Hotel records</h2><span>Latest data</span></div>
    <div class="admin-table-scroll">
    <table>
    <tr><th>ID</th><th>Name</th><th>Destination</th><th>Price/Night</th><th>Status</th><th>Actions</th></tr>
    <?php foreach ($hotels as $h): ?>
    <tr>
        <td><?php echo $h['id']; ?></td>
        <td><?php echo e($h['name']); ?></td>
        <td><?php echo e($h['dest_name']); ?></td>
        <td><?php echo formatMoney($h['price_per_night']); ?></td>
        <td><span class="admin-status-badge admin-status-<?php echo e($h['status']); ?>"><?php echo ucfirst(e($h['status'])); ?></span></td>
        <td class="admin-actions">
            <a class="admin-action-link" href="hotels.php?edit=<?php echo $h['id']; ?>">Edit</a>
            <form method="POST" action="hotels.php" style="display:inline;" onsubmit="return confirm('Delete this hotel?');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?php echo $h['id']; ?>">
                <button type="submit" class="admin-delete-btn">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
    </div>
</div>

<?php include '../includes/admin-footer.php'; ?>
