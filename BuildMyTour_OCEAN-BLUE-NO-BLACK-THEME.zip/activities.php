<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Select Activities';

$tripId = (int)($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header("Location: ai-planner.php"); exit; }

if (empty($_SESSION['selection'][$tripId]['hotel_id'])) {
    header("Location: hotels.php?trip_id=$tripId");
    exit;
}

// Activities tied to the two destinations configured for this package.
$cities = getTripRoute($trip);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $ids = array_values(array_unique(array_filter(array_map('intval', $_POST['activity_ids'] ?? []))));
    if ($ids && $cities) {
        $idPh = implode(',', array_fill(0, count($ids), '?'));
        $cityPh = implode(',', array_fill(0, count($cities), '?'));
        $check = $pdo->prepare("SELECT COUNT(*) FROM activities a JOIN destinations d ON d.id=a.destination_id WHERE a.status='active' AND a.id IN ($idPh) AND d.name IN ($cityPh)");
        $check->execute(array_merge($ids, $cities));
        if ((int)$check->fetchColumn() !== count($ids)) { flash('error', 'Please choose valid activities for this package.'); header("Location: activities.php?trip_id=$tripId"); exit; }
    }
    $_SESSION['selection'][$tripId]['activity_ids'] = $ids;
    header("Location: trip-summary.php?trip_id=$tripId");
    exit;
}

if (!empty($cities)) {
    $hasActivityCategory = activityCategoryAvailable($pdo);
    $categorySelect = $hasActivityCategory ? ', a.category' : '';
    $placeholders = implode(',', array_fill(0, count($cities), '?'));
    $stmt = $pdo->prepare("SELECT a.*, d.name AS dest_name$categorySelect FROM activities a
        JOIN destinations d ON a.destination_id = d.id
        WHERE d.name IN ($placeholders) AND a.status = 'active'
        ORDER BY d.name, a.price");
    $stmt->execute($cities);
    $activityList = $stmt->fetchAll();
} else {
    $activityList = $pdo->query("SELECT a.*, d.name AS dest_name FROM activities a JOIN destinations d ON a.destination_id = d.id WHERE a.status='active'")->fetchAll();
}

// Smart default recommendations: preselect suitable activities from the user's
// budget, travel style and interests. If the user later changes selections, we keep
// those exact choices and never overwrite them on page reload.
$selection = $_SESSION['selection'][$tripId] ?? [];
if (!array_key_exists('activity_ids', $selection)) {
    $style = $trip['travel_style'] ?? 'Standard';
    $budget = (float)$trip['budget'];
    $interests = normalizeInterests($trip['interests'] ?? '');
    $scored = [];
    foreach ($activityList as $activity) {
        $score = activityInterestScore($activity, $interests);
        if ($style === 'Budget') $score += ((float)$activity['price'] <= ($budget * 0.05)) ? 20 : 0;
        if ($style === 'Standard') $score += 15;
        if ($style === 'Luxury') $score += min(20, ((float)$activity['price'] / 250));
        $scored[] = ['id' => (int)$activity['id'], 'score' => $score, 'price' => (float)$activity['price']];
    }

    usort($scored, function ($a, $b) use ($style) {
        $scoreCompare = $b['score'] <=> $a['score'];
        if ($scoreCompare !== 0) return $scoreCompare;
        return $style === 'Budget' ? ($a['price'] <=> $b['price']) : ($b['price'] <=> $a['price']);
    });

    $limit = $style === 'Budget' ? 3 : ($style === 'Luxury' ? 5 : 4);
    $selectedActivities = array_column(array_slice($scored, 0, min($limit, count($scored))), 'id');
    $_SESSION['selection'][$tripId]['activity_ids'] = $selectedActivities;
} else {
    $selectedActivities = $selection['activity_ids'] ?? [];
}

include 'includes/header.php';
?>

<div class="container py-4">
    <div class="page-header">
        <h1>Select Activities</h1>
        <p>Activities are automatically recommended using your budget, travel style and interests. You can add or remove any activity.</p>
    </div>

    <form method="POST" action="activities.php?trip_id=<?php echo $tripId; ?>">
        <input type="hidden" name="trip_id" value="<?php echo $tripId; ?>">
        <div class="selection-note" style="margin:0 0 18px;padding:14px 16px;border:1px solid #b8dce2;border-radius:12px;background:#f3fbfc;color:#17324d;">
            <strong>✨ Smart activities selected</strong><br>
            <span>Recommendations are based on your trip details. You can freely add or remove activities.</span>
        </div>
        <div class="select-grid row g-4">
            <?php foreach ($activityList as $a): ?>
                <label class="select-card col-md-6 col-lg-4 <?php echo in_array($a['id'], $selectedActivities) ? 'selected' : ''; ?>">
                    <div class="select-card-body">
                        <span class="badge"><?php echo e($a['dest_name']); ?></span>
                        <?php if (!empty($a['category'])): ?><span class="badge" style="margin-left:6px;"><?php echo e($a['category']); ?></span><?php endif; ?>
                        <?php if (in_array((int)$a['id'], array_map('intval', $selectedActivities), true)): ?><span class="badge" style="margin-left:6px; background:#dff4ea; color:#17643a;">Recommended ✓</span><?php endif; ?>
                        <h3><?php echo e($a['name']); ?></h3>
                        <div class="meta"><?php echo e($a['description']); ?></div>
                        <div class="meta">⏱ <?php echo e($a['duration']); ?></div>
                        <div class="price"><?php echo $a['price'] > 0 ? formatMoney($a['price']) . '/person' : 'Free'; ?></div>
                        <label style="font-size:13px;">
                            <input type="checkbox" name="activity_ids[]" value="<?php echo $a['id']; ?>" <?php echo in_array($a['id'], $selectedActivities) ? 'checked' : ''; ?>> Add to trip
                        </label>
                    </div>
                </label>
            <?php endforeach; ?>
        </div>
        <div class="hero-actions" style="justify-content:flex-start; margin-bottom:50px;">
            <a href="hotels.php?trip_id=<?php echo $tripId; ?>" class="btn btn-outline">← Back</a>
            <button type="submit" class="btn btn-primary">View Trip Summary →</button>
        </div>
    </form>
</div>

<?php include 'includes/footer.php'; ?>
