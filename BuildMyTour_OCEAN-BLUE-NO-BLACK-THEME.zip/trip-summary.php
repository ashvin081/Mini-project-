<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Trip Summary';

$tripId = (int)($_GET['trip_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header("Location: ai-planner.php"); exit; }

$sel = $_SESSION['selection'][$tripId] ?? [];

// Restore persisted smart recommendations when the browser session is new or expired.
if (empty($sel['transport_id']) && !empty($trip['selected_transport_id'])) {
    $sel['transport_id'] = (int)$trip['selected_transport_id'];
}
if (empty($sel['hotel_id']) && !empty($trip['selected_hotel_id'])) {
    $sel['hotel_id'] = (int)$trip['selected_hotel_id'];
}
if (empty($sel['activity_ids']) && !empty($trip['selected_activity_ids'])) {
    $sel['activity_ids'] = array_values(array_filter(array_map('intval', explode(',', $trip['selected_activity_ids']))));
}
if (empty($sel['transport_id']) || empty($sel['hotel_id'])) {
    header("Location: transport.php?trip_id=$tripId");
    exit;
}
$_SESSION['selection'][$tripId] = $sel;

$stmt = $pdo->prepare("SELECT * FROM transport WHERE id = ?");
$stmt->execute([$sel['transport_id']]);
$transport = $stmt->fetch();
if (!$transport) { unset($_SESSION['selection'][$tripId]['transport_id']); header("Location: transport.php?trip_id=$tripId"); exit; }

$stmt = $pdo->prepare("SELECT * FROM hotels WHERE id = ?");
$stmt->execute([$sel['hotel_id']]);
$hotel = $stmt->fetch();
if (!$hotel) { unset($_SESSION['selection'][$tripId]['hotel_id']); header("Location: hotels.php?trip_id=$tripId"); exit; }

$activityIds = $sel['activity_ids'] ?? [];
$activities = [];
$activitiesCost = 0;
if (!empty($activityIds)) {
    $ph = implode(',', array_fill(0, count($activityIds), '?'));
    $stmt = $pdo->prepare("SELECT * FROM activities WHERE id IN ($ph)");
    $stmt->execute($activityIds);
    $activities = $stmt->fetchAll();
    foreach ($activities as $a) { $activitiesCost += $a['price'] * $trip['travelers']; }
}

$nights = max(1, (int)$trip['days'] - 1);
$transportCost = $transport['price'] * $trip['travelers'] * 2; // round trip
$hotelCost = $hotel['price_per_night'] * $nights;
$totalCost = $transportCost + $hotelCost + $activitiesCost;
$remaining = $trip['budget'] - $totalCost;
$withinBudget = $remaining >= 0;

// Package route and optional offer information.
$package = getTourPackage($trip['destination']);
$dbPackage = null;
try {
    $dbNameMap = [
        'Royal Rajasthan Tour' => 'Rajasthan Explorer',
        'Gujarat Explorer Tour' => 'Gujarat Heritage Tour',
        'Kashmir Paradise Tour' => 'Kashmir Escape',
        'Kerala Explorer Tour' => 'Kerala Nature Trip',
        'Ladakh Adventure Tour' => 'Ladakh Adventure'
    ];
    $stmt = $pdo->prepare("SELECT * FROM tour_packages WHERE name = ? AND status = 'active' LIMIT 1");
    $stmt->execute([$dbNameMap[$trip['destination']] ?? $trip['destination']]);
    $dbPackage = $stmt->fetch();
} catch (Throwable $e) {}
$routeNames = $package['cities'] ?? [];
$selectedDestinations = [];
if (!empty($routeNames)) {
    $ph = implode(',', array_fill(0, count($routeNames), '?'));
    $stmt = $pdo->prepare("SELECT * FROM destinations WHERE name IN ($ph)");
    $stmt->execute($routeNames);
    $rows = $stmt->fetchAll();
    foreach ($routeNames as $routeName) {
        foreach ($rows as $row) {
            if ($row['name'] === $routeName) { $selectedDestinations[] = $row; break; }
        }
    }
}
$transportImages = [
    'Flight' => 'assets/images/transport/flight.png',
    'Train'  => 'assets/images/transport/train.png',
    'Bus'    => 'assets/images/transport/bus.png'
];
$transportImage = $transportImages[$transport['type']] ?? '';

// Persist recalculated total on the trip
$stmt = $pdo->prepare("UPDATE trips SET estimated_cost = ? WHERE id = ?");
$stmt->execute([$totalCost, $tripId]);

$_SESSION['selection'][$tripId]['total_cost'] = $totalCost;

include 'includes/header.php';
?>

<div class="container trip-summary-page py-4">
    <div class="page-header trip-summary-header">
        <div>
            <span class="summary-eyebrow">SMART TRIP RECOMMENDATION</span>
            <h1>Your Trip Plan</h1>
            <p>The system has prepared a trip based on your details. Review it and customize anything before checkout.</p>
        </div>
        <div class="summary-ready-badge">✓ Plan Ready</div>
    </div>

    <section class="trip-overview-card card border-0 shadow-sm">
        <div class="trip-overview-main">
            <div class="overview-icon">🧭</div>
            <div>
                <span class="overview-label">Selected Tour Package</span>
                <h2><?php echo e($trip['destination']); ?></h2>
                <p>Your personalized recommended trip is ready to review.</p>
            </div>
        </div>
        <div class="trip-mini-stats row g-0">
            <div class="mini-stat col-md-4">
                <span>📅 Dates</span>
                <strong><?php echo date('d M', strtotime($trip['start_date'])); ?> – <?php echo date('d M Y', strtotime($trip['end_date'])); ?></strong>
            </div>
            <div class="mini-stat col-md-4">
                <span>👥 Travelers</span>
                <strong><?php echo (int)$trip['travelers']; ?> Adult(s)</strong>
            </div>
            <div class="mini-stat col-md-4">
                <span>🌙 Duration</span>
                <strong><?php echo (int)$trip['days']; ?> Days</strong>
            </div>
        </div>
    </section>

    <?php if ($dbPackage): ?>
    <section class="card border-0 shadow-sm p-3 mb-4">
        <div class="d-flex flex-wrap align-items-center justify-content-between gap-3">
            <div><span class="summary-eyebrow">PACKAGE PRICE</span><h3 class="mb-0"><?php echo e($dbPackage['name']); ?></h3></div>
            <div class="text-end">
                <?php if (packageOfferActive($dbPackage)): ?>
                    <span class="badge text-bg-danger">🔥 <?php echo e(packageOfferLabel($dbPackage)); ?></span><br>
                    <span class="text-decoration-line-through text-muted"><?php echo formatMoney($dbPackage['price']); ?></span>
                    <strong class="ms-2 fs-5"><?php echo formatMoney(packageOfferPrice($dbPackage)); ?></strong>
                <?php else: ?><strong class="fs-5"><?php echo formatMoney($dbPackage['price']); ?></strong><?php endif; ?>
            </div>
        </div>
        <small class="text-muted d-block mt-2">Package offer is shown separately. Your final smart trip estimate below is calculated from the selected transport, hotel and activities.</small>
    </section>
    <?php endif; ?>

    <?php if (!empty($selectedDestinations)): ?>
    <section class="summary-destinations-section">
        <div class="summary-destinations-heading">
            <div>
                <span class="summary-eyebrow">YOUR DESTINATIONS</span>
                <h2>Explore Your Tour Route</h2>
            </div>
            <p>These are the main destinations included in your selected tour package.</p>
        </div>
        <div class="summary-destination-images row g-4">
            <?php foreach ($selectedDestinations as $destination): ?>
                <article class="summary-destination-image col-md-6">
                    <img src="<?php echo e($destination['image']); ?>" alt="<?php echo e($destination['name']); ?>" onerror="this.style.display='none';this.parentElement.classList.add('image-missing');">
                    <div class="summary-destination-overlay">
                        <span class="summary-destination-label">MAIN DESTINATION</span>
                        <h3>📍 <?php echo e($destination['name']); ?></h3>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>
    <?php endif; ?>

    <div class="summary-section-heading">
        <div>
            <span class="summary-eyebrow">SYSTEM RECOMMENDATIONS</span>
            <h2>Recommended for Your Trip</h2>
        </div>
        <p>Everything below was selected using a rule-based scoring system. You can change any option.</p>
    </div>

    <section class="recommendation-grid row g-4">
        <article class="recommendation-card recommendation-card-image col-lg-4">
            <?php if ($transportImage): ?><img class="summary-option-image" src="<?php echo e($transportImage); ?>" alt="<?php echo e($transport['type']); ?>" onerror="this.style.display='none';"><?php endif; ?>
            <div class="recommendation-card-top">
                <div class="recommendation-icon">✈</div>
                <div><span>TRANSPORT</span><h3><?php echo e($transport['type']); ?></h3></div>
            </div>
            <p class="recommendation-detail"><?php echo e($transport['provider']); ?></p>
            <p class="recommendation-meta">Score: <?php echo e($sel['transport_score'] ?? ''); ?>/100 · <?php echo e(($sel['recommendation_explanation']['transport'] ?? 'Recommended for your trip.')); ?></p>
            <a class="summary-change-btn" href="transport.php?trip_id=<?php echo $tripId; ?>">Change Transport <span>→</span></a>
        </article>

        <article class="recommendation-card recommendation-card-image col-lg-4">
            <?php if (!empty($hotel['image'])): ?><img class="summary-option-image" src="<?php echo e($hotel['image']); ?>" alt="<?php echo e($hotel['name']); ?>" onerror="this.style.display='none';"><?php endif; ?>
            <div class="recommendation-card-top">
                <div class="recommendation-icon">⌂</div>
                <div><span>HOTEL</span><h3><?php echo e($hotel['name']); ?></h3></div>
            </div>
            <p class="recommendation-detail"><?php echo e($hotel['room_type'] ?? 'Recommended stay'); ?></p>
            <p class="recommendation-meta">Score: <?php echo e($sel['hotel_score'] ?? ''); ?>/100 · <?php echo e(($sel['recommendation_explanation']['hotel'] ?? 'Recommended for your trip.')); ?></p>
            <a class="summary-change-btn" href="hotels.php?trip_id=<?php echo $tripId; ?>">Change Hotel <span>→</span></a>
        </article>

        <article class="recommendation-card activities-summary-card col-lg-4">
            <div class="recommendation-card-top">
                <div class="recommendation-icon">★</div>
                <div><span>ACTIVITIES</span><h3><?php echo count($activities); ?> Selected</h3></div>
            </div>
            <?php if (!empty($activities)): ?>
                <div class="summary-activity-list">
                    <?php foreach ($activities as $activity): ?>
                        <div class="summary-activity-item">
                            <span class="summary-activity-check">✓</span>
                            <span><?php echo e($activity['name']); ?></span>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
            <p class="recommendation-detail">Recommended experiences</p>
            <p class="recommendation-meta"><?php echo e(($sel['recommendation_explanation']['activities'] ?? 'Selected using your trip details.')); ?></p>
            <a class="summary-change-btn" href="activities.php?trip_id=<?php echo $tripId; ?>">Customize Activities <span>→</span></a>
        </article>
    </section>

    <section class="cost-summary-card card border-0 shadow-sm">
        <div class="cost-summary-header">
            <div>
                <span class="summary-eyebrow">COST SUMMARY</span>
                <h2>Your Estimated Trip Cost</h2>
                <p>A simple breakdown based on your current selections.</p>
            </div>
        </div>

        <div class="cost-summary-body">
            <div class="cost-item"><span><i>✈</i> Transport</span><strong><?php echo formatMoney($transportCost); ?></strong></div>
            <div class="cost-item"><span><i>⌂</i> Hotel <small><?php echo $nights; ?> nights</small></span><strong><?php echo formatMoney($hotelCost); ?></strong></div>
            <div class="cost-item"><span><i>★</i> Activities</span><strong><?php echo formatMoney($activitiesCost); ?></strong></div>

            <div class="cost-total-row">
                <span>Total Estimated Cost</span>
                <strong><?php echo formatMoney($totalCost); ?></strong>
            </div>

            <div class="cost-budget-grid">
                <div><span>Your Budget</span><strong><?php echo formatMoney($trip['budget']); ?></strong></div>
                <div><span>Remaining Budget</span><strong><?php echo formatMoney($remaining); ?></strong></div>
            </div>

            <?php if ($withinBudget): ?>
                <div class="summary-budget-message success">✓ Your trip is within the selected budget.</div>
            <?php else: ?>
                <div class="summary-budget-message warning">⚠ Your trip is above the selected budget. Change an option to reduce the cost.</div>
            <?php endif; ?>
        </div>
    </section>

    <div class="summary-bottom-actions">
        <a href="ai-planner.php" class="summary-back-link">← Edit Trip Details</a>
        <div class="d-flex flex-wrap gap-2">
            <a href="checkout.php?trip_id=<?php echo $tripId; ?>" class="btn btn-primary summary-checkout-btn">Proceed to Checkout <span>→</span></a>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
