-- =====================================================
-- BuildMyTour Database Schema
-- College Mini Project - Travel Planning & Booking
-- Final simplified schema: exactly 8 tables
-- =====================================================

CREATE DATABASE IF NOT EXISTS buildmytour;
USE buildmytour;

-- Reset only the BuildMyTour tables so this SQL can be imported again cleanly.
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS trips;
DROP TABLE IF EXISTS tour_packages;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS activities;
DROP TABLE IF EXISTS transport;
DROP TABLE IF EXISTS hotels;
DROP TABLE IF EXISTS destinations;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. ADMINS
CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 3. DESTINATIONS
CREATE TABLE destinations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    description TEXT,
    image VARCHAR(255) DEFAULT NULL,
    category VARCHAR(100),
    distance_info VARCHAR(255),
    status ENUM('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB;

-- 4. TOUR PACKAGES
CREATE TABLE tour_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    duration VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255) DEFAULT NULL,
    offer_percentage DECIMAL(5,2) DEFAULT 0,
    offer_start_date DATE DEFAULT NULL,
    offer_end_date DATE DEFAULT NULL,
    status ENUM('active','inactive') DEFAULT 'active'
) ENGINE=InnoDB;

-- 5. HOTELS
CREATE TABLE hotels (
    id INT AUTO_INCREMENT PRIMARY KEY,
    destination_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    rating DECIMAL(2,1) DEFAULT 3.0,
    room_type VARCHAR(100),
    price_per_night DECIMAL(10,2) NOT NULL,
    amenities VARCHAR(255),
    image VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') DEFAULT 'active',
    FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE,
    INDEX idx_hotel_dest (destination_id)
) ENGINE=InnoDB;

-- 6. TRANSPORT
CREATE TABLE transport (
    id INT AUTO_INCREMENT PRIMARY KEY,
    type ENUM('Flight','Train','Bus') NOT NULL,
    provider VARCHAR(100) NOT NULL,
    from_location VARCHAR(100) NOT NULL,
    to_location VARCHAR(100) NOT NULL,
    departure VARCHAR(20),
    arrival VARCHAR(20),
    duration VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    seats INT DEFAULT 40,
    status ENUM('active','inactive') DEFAULT 'active',
    INDEX idx_transport_route (from_location, to_location)
) ENGINE=InnoDB;

-- 7. ACTIVITIES
CREATE TABLE activities (
    id INT AUTO_INCREMENT PRIMARY KEY,
    destination_id INT NOT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    duration VARCHAR(50),
    price DECIMAL(10,2) NOT NULL,
    category ENUM('Historical','Nature','Adventure','Culture','Food','Shopping') DEFAULT 'Culture',
    status ENUM('active','inactive') DEFAULT 'active',
    FOREIGN KEY (destination_id) REFERENCES destinations(id) ON DELETE CASCADE,
    INDEX idx_activity_dest (destination_id)
) ENGINE=InnoDB;

-- 8. TRIPS
CREATE TABLE trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    start_location VARCHAR(100) NOT NULL,
    destination VARCHAR(100) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT NOT NULL,
    travelers INT NOT NULL,
    budget DECIMAL(10,2) NOT NULL,
    travel_style ENUM('Budget','Standard','Luxury') DEFAULT 'Standard',
    interests VARCHAR(255),
    transport_preference VARCHAR(50),
    estimated_distance VARCHAR(100),
    estimated_cost DECIMAL(10,2) DEFAULT 0,
    selected_transport_id INT DEFAULT NULL,
    selected_hotel_id INT DEFAULT NULL,
    selected_activity_ids VARCHAR(255) DEFAULT NULL,
    booking_reference VARCHAR(50) DEFAULT NULL UNIQUE,
    total_amount DECIMAL(10,2) DEFAULT NULL,
    payment_method ENUM('UPI','Card','Net Banking') DEFAULT NULL,
    transaction_id VARCHAR(50) DEFAULT NULL,
    payment_status ENUM('pending','success','failed') DEFAULT 'pending',
    booking_status ENUM('not_booked','pending','confirmed','completed','cancelled') DEFAULT 'not_booked',
    rating TINYINT DEFAULT NULL,
    review_comment TEXT DEFAULT NULL,
    review_status ENUM('not_reviewed','pending','approved','rejected') DEFAULT 'not_reviewed',
    reviewed_at TIMESTAMP NULL DEFAULT NULL,
    status ENUM('draft','planned','booked','completed') DEFAULT 'draft',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (selected_transport_id) REFERENCES transport(id) ON DELETE SET NULL,
    FOREIGN KEY (selected_hotel_id) REFERENCES hotels(id) ON DELETE SET NULL,
    INDEX idx_trip_user (user_id)
) ENGINE=InnoDB;

-- =====================================================
-- DEMO / SEED DATA
-- =====================================================

INSERT INTO destinations (name, state, description, image, category, distance_info, status) VALUES
('Jaipur', 'Rajasthan', 'Pink City known for forts and royal heritage.', 'assets/images/destinations/jaipur.jpg', 'Heritage', 'Package route destination', 'active'),
('Udaipur', 'Rajasthan', 'City of Lakes with palaces and scenic views.', 'assets/images/destinations/udaipur.jpg', 'Heritage', 'Package route destination', 'active'),
('Ahmedabad', 'Gujarat', 'Historic city with culture and architecture.', 'assets/images/destinations/ahmedabad.jpg', 'Cultural', 'Package route destination', 'active'),
('Dwarka', 'Gujarat', 'Famous coastal pilgrimage destination.', 'assets/images/destinations/dwarka.jpg', 'Spiritual', 'Package route destination', 'active'),
('Srinagar', 'Kashmir', 'Beautiful valley city with lakes and gardens.', 'assets/images/destinations/srinagar.jpg', 'Nature', 'Package route destination', 'active'),
('Gulmarg', 'Kashmir', 'Mountain destination known for scenic landscapes.', 'assets/images/destinations/gulmarg.jpg', 'Nature', 'Package route destination', 'active'),
('Kochi', 'Kerala', 'Historic port city with coastal culture.', 'assets/images/destinations/kochi.jpg', 'Cultural', 'Package route destination', 'active'),
('Munnar', 'Kerala', 'Hill station known for tea gardens.', 'assets/images/destinations/munnar.jpg', 'Nature', 'Package route destination', 'active'),
('Leh', 'Ladakh', 'High-altitude Himalayan destination.', 'assets/images/destinations/leh.jpg', 'Adventure', 'Package route destination', 'active'),
('Nubra Valley', 'Ladakh', 'Scenic valley with mountains and desert landscapes.', 'assets/images/destinations/nubra-valley.jpg', 'Adventure', 'Package route destination', 'active');

INSERT INTO hotels (destination_id, name, rating, room_type, price_per_night, amenities, image, status) VALUES
(1, 'Jaipur Heritage Stay', 4.1, 'Standard Room', 2400.00, 'WiFi, AC, Breakfast', 'assets/images/hotels/jaipur-heritage-stay.jpg', 'active'),
(2, 'Lake View Palace Hotel', 4.5, 'Deluxe Room', 3500.00, 'WiFi, AC, Breakfast, Lake View', 'assets/images/hotels/udaipur-lake-view.jpg', 'active'),
(3, 'Ahmedabad Comfort Inn', 4.0, 'Standard Room', 2200.00, 'WiFi, AC, Breakfast', 'assets/images/hotels/ahmedabad-comfort-inn.jpg', 'active'),
(4, 'Dwarka Sea View Stay', 4.1, 'Deluxe Room', 2800.00, 'WiFi, AC, Breakfast', 'assets/images/hotels/dwarka-sea-view.jpg', 'active'),
(5, 'Srinagar Lake Retreat', 4.4, 'Deluxe Room', 3800.00, 'WiFi, Heating, Breakfast', 'assets/images/hotels/srinagar-lake-retreat.jpg', 'active'),
(6, 'Gulmarg Mountain Resort', 4.3, 'Deluxe Room', 4200.00, 'WiFi, Heating, Breakfast', 'assets/images/hotels/gulmarg-mountain-resort.jpg', 'active'),
(7, 'Kochi Harbour Hotel', 4.0, 'Standard Room', 2500.00, 'WiFi, AC, Breakfast', 'assets/images/hotels/kochi-harbour-hotel.jpg', 'active'),
(8, 'Munnar Tea Valley Stay', 4.3, 'Deluxe Room', 3300.00, 'WiFi, Mountain View, Breakfast', 'assets/images/hotels/munnar-tea-valley.jpg', 'active'),
(9, 'Leh Mountain Lodge', 4.2, 'Standard Room', 3600.00, 'WiFi, Heating, Breakfast', 'assets/images/hotels/leh-mountain-lodge.jpg', 'active'),
(10, 'Nubra Desert Camp', 4.1, 'Deluxe Tent', 3900.00, 'Campfire, Breakfast, Scenic View', 'assets/images/hotels/nubra-desert-camp.jpg', 'active');

INSERT INTO transport (type, provider, from_location, to_location, departure, arrival, duration, price, seats, status) VALUES
('Train', 'Indian Railways', 'Ahmedabad', 'Jaipur', '07:00 AM', '02:00 PM', '7h', 900.00, 40, 'active'),
('Bus', 'RSRTC', 'Ahmedabad', 'Jaipur', '08:00 AM', '05:00 PM', '9h', 700.00, 35, 'active'),
('Flight', 'IndiGo', 'Ahmedabad', 'Jaipur', '09:00 AM', '10:30 AM', '1h 30m', 3800.00, 20, 'active');

INSERT INTO activities (destination_id, name, description, duration, price, category, status) VALUES
(1, 'Amber Fort Visit', 'Explore Jaipur’s famous hill fort.', '2h', 350.00, 'Historical', 'active'),
(1, 'Jaipur Local Bazaar Walk', 'Explore local markets and handicrafts.', '2h', 250.00, 'Shopping', 'active'),
(1, 'Rajasthani Food Experience', 'Taste popular local dishes.', '1h 30m', 450.00, 'Food', 'active'),
(2, 'Lake Pichola Boat Ride', 'Enjoy a scenic boat ride in Udaipur.', '1h', 400.00, 'Nature', 'active'),
(2, 'City Palace Visit', 'Explore Udaipur royal architecture and heritage.', '2h', 300.00, 'Historical', 'active'),
(2, 'Udaipur Cultural Evening', 'Enjoy local music and cultural performances.', '2h', 600.00, 'Culture', 'active'),
(3, 'Sabarmati Ashram Visit', 'Visit the historic ashram and museum.', '1h 30m', 100.00, 'Historical', 'active'),
(3, 'Ahmedabad Heritage Walk', 'Walk through historic neighborhoods and landmarks.', '2h', 300.00, 'Culture', 'active'),
(4, 'Dwarkadhish Temple Visit', 'Visit the famous temple complex.', '1h', 0.00, 'Historical', 'active'),
(4, 'Dwarka Coastal Walk', 'Relax and explore the coastal surroundings.', '1h 30m', 150.00, 'Nature', 'active'),
(5, 'Dal Lake Shikara Ride', 'Enjoy a traditional Shikara ride.', '1h', 500.00, 'Nature', 'active'),
(5, 'Srinagar Garden Visit', 'Explore scenic Mughal gardens.', '2h', 250.00, 'Nature', 'active'),
(6, 'Gulmarg Gondola Experience', 'Scenic mountain cable-car experience.', '2h', 900.00, 'Adventure', 'active'),
(6, 'Gulmarg Meadow Walk', 'Explore mountain scenery and open meadows.', '2h', 200.00, 'Nature', 'active'),
(7, 'Fort Kochi Heritage Walk', 'Explore Fort Kochi landmarks.', '2h', 250.00, 'Culture', 'active'),
(7, 'Kochi Street Food Tour', 'Taste local coastal food and snacks.', '2h', 500.00, 'Food', 'active'),
(8, 'Tea Garden Visit', 'Visit scenic Munnar tea gardens.', '1h 30m', 150.00, 'Nature', 'active'),
(8, 'Munnar Viewpoint Trek', 'Short guided trek to scenic viewpoints.', '3h', 600.00, 'Adventure', 'active'),
(9, 'Leh Palace Visit', 'Explore the historic palace and views.', '1h 30m', 200.00, 'Historical', 'active'),
(9, 'Leh Mountain Trail', 'Explore high-altitude landscapes on a guided trail.', '3h', 700.00, 'Adventure', 'active'),
(10, 'Nubra Valley Safari', 'Explore Nubra’s scenic valley landscapes.', '2h', 700.00, 'Adventure', 'active'),
(10, 'Nubra Local Culture Visit', 'Experience local villages and culture.', '2h', 300.00, 'Culture', 'active');

-- Demo admin account (password: admin123)
INSERT INTO admins (name, email, password) VALUES
('Admin', 'admin@buildmytour.com', '$2y$12$03m3wAMfw2dorevPiyy4gOFXGOE0r218QE6GQVe2HrfH7UkEQDxG6');

-- Demo tour packages. Offers are stored directly with the package.
INSERT INTO tour_packages (name, description, duration, price, image, offer_percentage, status) VALUES
('Rajasthan Explorer', 'Explore Jaipur and Udaipur with heritage experiences.', '4 Days / 3 Nights', 15000.00, 'assets/images/destinations/jaipur.jpg', 10.00, 'active'),
('Gujarat Heritage Tour', 'Discover Ahmedabad and Dwarka.', '3 Days / 2 Nights', 12000.00, 'assets/images/destinations/ahmedabad.jpg', 0.00, 'active'),
('Kashmir Escape', 'Enjoy Srinagar and Gulmarg landscapes.', '5 Days / 4 Nights', 25000.00, 'assets/images/destinations/srinagar.jpg', 15.00, 'active'),
('Kerala Nature Trip', 'Experience Kochi and Munnar.', '4 Days / 3 Nights', 18000.00, 'assets/images/destinations/munnar.jpg', 0.00, 'active'),
('Ladakh Adventure', 'Explore Leh and Nubra Valley.', '6 Days / 5 Nights', 32000.00, 'assets/images/destinations/leh.jpg', 5.00, 'active');
