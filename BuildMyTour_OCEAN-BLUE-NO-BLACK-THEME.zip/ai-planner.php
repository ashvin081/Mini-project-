<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Smart Trip Planner';

// Package offers are managed by the admin and shown here without changing the Home page structure.
$packageOfferRows = [];
try {
    foreach ($pdo->query("SELECT * FROM tour_packages WHERE status = 'active' ORDER BY id ASC")->fetchAll() as $row) {
        $packageOfferRows[$row['name']] = $row;
    }
} catch (Throwable $e) {}
include 'includes/header.php';
?>

<div class="container py-4">
    <div class="page-header">
        <h1>Smart Trip Planner</h1>
        <p>Choose a multi-city package and enter your trip details. The Smart Recommendation Engine prepares personalized transport, hotel and activity suggestions for you.</p>
    </div>

    <form class="planner-form card shadow-sm border-0 p-4 p-md-5" id="plannerForm" method="POST" action="generate-trip.php">
        <div class="mb-3">
            <label class="form-label">Select Tour Package</label>
            <select name="destination" id="tourPackage" class="form-control" required>
                <option value="" selected disabled>Choose your multi-city tour package</option>
                <?php foreach (getTourPackages() as $packageName => $package): ?>
                    <?php
                    // Match legacy route names to the package names stored in the 8-table database.
                    $dbNameMap = [
                        'Royal Rajasthan Tour' => 'Rajasthan Explorer',
                        'Gujarat Explorer Tour' => 'Gujarat Heritage Tour',
                        'Kashmir Paradise Tour' => 'Kashmir Escape',
                        'Kerala Explorer Tour' => 'Kerala Nature Trip',
                        'Ladakh Adventure Tour' => 'Ladakh Adventure'
                    ];
                    $dbPackage = $packageOfferRows[$dbNameMap[$packageName] ?? $packageName] ?? null;
                    $offerText = $dbPackage ? packageOfferLabel($dbPackage) : '';
                    ?>
                    <option value="<?php echo e($packageName); ?>" data-route="<?php echo e(implode(' → ', $package['cities'])); ?>" data-offer="<?php echo e($offerText); ?>" data-price="<?php echo e($dbPackage ? formatMoney($dbPackage['price']) : ''); ?>" data-final-price="<?php echo e($dbPackage ? formatMoney(packageOfferPrice($dbPackage)) : ''); ?>">
                        <?php echo e($package['icon'] . ' ' . $packageName . ' — ' . implode(' → ', $package['cities']) . ($offerText ? ' | ' . $offerText : '')); ?>
                    </option>
                <?php endforeach; ?>
            </select>
            <div id="tourPreview" style="display:none; margin-top:12px; padding:14px 16px; border:1px solid #b8dce2; border-radius:12px; background:#f3fbfc; color:#17324d;">
                <strong id="tourPreviewName"></strong><br>
                <span id="tourPreviewRoute"></span><br>
                <small id="tourPreviewStartEnd"></small><div id="tourPreviewOffer" class="mt-2 fw-semibold"></div>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Start Date</label>
                <input type="date" name="start_date" id="start_date" class="form-control" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">End Date</label>
                <input type="date" name="end_date" id="end_date" class="form-control" required>
            </div>
        </div>

        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label">Number of Travelers</label>
                <input type="number" name="travelers" class="form-control" min="1" value="2" required>
            </div>
            <div class="col-md-6">
                <label class="form-label">Budget (₹)</label>
                <input type="number" name="budget" class="form-control" min="1000" value="40000" required>
            </div>
        </div>

        <div class="mb-3">
            <label class="form-label">Travel Style</label>
            <select name="travel_style" class="form-control">
                <option value="Budget">Budget</option>
                <option value="Standard" selected>Standard</option>
                <option value="Luxury">Luxury</option>
            </select>
        </div>

        <div class="mb-3">
            <label class="form-label">Interests</label>
            <div class="checkbox-group">
                <?php foreach (['Historical','Nature','Adventure','Culture','Food','Shopping'] as $interest): ?>
                <label class="chip">
                    <input type="checkbox" name="interests[]" value="<?php echo $interest; ?>">
                    <?php echo $interest; ?>
                </label>
                <?php endforeach; ?>
            </div>
        </div>

        <button type="submit" class="btn btn-primary w-100">Generate My Trip</button>
    </form>
</div>

<script>
const tourPackage = document.getElementById('tourPackage');
const preview = document.getElementById('tourPreview');
if (tourPackage) {
    tourPackage.addEventListener('change', function () {
        const option = this.options[this.selectedIndex];
        document.getElementById('tourPreviewName').textContent = option.textContent.split(' — ')[0];
        document.getElementById('tourPreviewRoute').textContent = 'Route: ' + (option.dataset.route || '');
        document.getElementById('tourPreviewStartEnd').textContent = 'Route preview based on your selected tour package.';
        const offerBox = document.getElementById('tourPreviewOffer');
        if (option.dataset.offer) {
            offerBox.textContent = '🔥 ' + option.dataset.offer + ' — ' + option.dataset.finalPrice + ' (Regular ' + option.dataset.price + ')';
        } else {
            offerBox.textContent = option.dataset.price ? 'Package price: ' + option.dataset.price : '';
        }
        preview.style.display = 'block';
    });
}
</script>
<?php include 'includes/footer.php'; ?>
