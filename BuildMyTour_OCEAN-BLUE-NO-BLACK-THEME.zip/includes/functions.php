<?php
/**
 * Shared helper functions
 * BuildMyTour - College Mini Project
 */

function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function flash($key, $message = null) {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function formatMoney($amount) {
    return '₹' . number_format((float)$amount, 0);
}


function packageOfferActive(array $package) {
    $percent = (float)($package['offer_percentage'] ?? 0);
    if ($percent <= 0) return false;
    $today = date('Y-m-d');
    if (!empty($package['offer_start_date']) && $package['offer_start_date'] > $today) return false;
    if (!empty($package['offer_end_date']) && $package['offer_end_date'] < $today) return false;
    return true;
}

function packageOfferPrice(array $package) {
    $price = (float)($package['price'] ?? 0);
    if (!packageOfferActive($package)) return $price;
    return round($price * (1 - ((float)$package['offer_percentage'] / 100)), 2);
}

function packageOfferLabel(array $package) {
    return packageOfferActive($package) ? rtrim(rtrim(number_format((float)$package['offer_percentage'], 2), '0'), '.') . '% OFF' : '';
}

function getTourPackages() {
    return [
        'Royal Rajasthan Tour' => ['cities' => ['Jaipur', 'Udaipur'], 'icon' => '🏜️'],
        'Gujarat Explorer Tour' => ['cities' => ['Ahmedabad', 'Dwarka'], 'icon' => '🇮🇳'],
        'Kashmir Paradise Tour' => ['cities' => ['Srinagar', 'Gulmarg'], 'icon' => '❄️'],
        'Kerala Explorer Tour' => ['cities' => ['Kochi', 'Munnar'], 'icon' => '🌴'],
        'Ladakh Adventure Tour' => ['cities' => ['Leh', 'Nubra Valley'], 'icon' => '🏔️'],
    ];
}

function getTourPackage($name) {
    $packages = getTourPackages();
    return $packages[$name] ?? null;
}


function getTripRoute(array $trip) {
    $package = getTourPackage($trip['destination'] ?? '');
    return $package['cities'] ?? [];
}

function generateBookingReference() {
    return 'BMT' . date('Y') . strtoupper(substr(uniqid(), -6));
}

function generateTransactionId() {
    return 'TXN' . strtoupper(substr(uniqid(), -10));
}

// Small static route table used only by the college-project demo.
function getRouteDistance($from, $to) {
    $routes = [
        'Ahmedabad-Udaipur'   => ['distance' => '250 km', 'time' => '5-6 hours'],
        'Udaipur-Jodhpur'     => ['distance' => '250 km', 'time' => '5-6 hours'],
        'Jodhpur-Jaisalmer'   => ['distance' => '280 km', 'time' => '5-6 hours'],
        'Jaisalmer-Ahmedabad' => ['distance' => '650 km', 'time' => '12-14 hours'],
    ];
    $key = "$from-$to";
    return $routes[$key] ?? ['distance' => 'Approx. 200 km', 'time' => 'Approx. 4-5 hours'];
}


/**
 * Smart recommendation helpers.
 * This is a rule-based recommendation engine designed for the college mini project.
 */
function activityCategoryAvailable(PDO $pdo) {
    static $available = null;
    if ($available !== null) return $available;
    try {
        $stmt = $pdo->query("SHOW COLUMNS FROM activities LIKE 'category'");
        $available = (bool)$stmt->fetch();
    } catch (Throwable $e) {
        $available = false;
    }
    return $available;
}

function normalizeInterests($interests) {
    if (is_array($interests)) {
        return array_values(array_unique(array_filter(array_map('trim', $interests))));
    }
    return array_values(array_unique(array_filter(array_map('trim', explode(',', (string)$interests)))));
}

function activityInterestScore(array $activity, array $interests) {
    if (!$interests) return 10;

    $category = strtolower(trim((string)($activity['category'] ?? '')));
    $text = strtolower(
        (string)($activity['name'] ?? '') . ' ' .
        (string)($activity['description'] ?? '')
    );

    $keywords = [
        'Historical' => ['historical', 'history', 'fort', 'palace', 'museum', 'heritage', 'ashram'],
        'Nature' => ['nature', 'lake', 'garden', 'valley', 'tea', 'scenic', 'boat'],
        'Adventure' => ['adventure', 'safari', 'trek', 'gondola', 'camp', 'desert'],
        'Culture' => ['culture', 'cultural', 'heritage', 'walk', 'folk', 'city', 'local'],
        'Food' => ['food', 'cuisine', 'culinary', 'restaurant', 'market'],
        'Shopping' => ['shopping', 'market', 'shop', 'bazaar', 'handicraft']
    ];

    $score = 0;
    foreach ($interests as $interest) {
        if (strtolower($interest) === $category) {
            $score += 45;
            continue;
        }
        foreach ($keywords[$interest] ?? [] as $keyword) {
            if (strpos($text, $keyword) !== false) {
                $score += 30;
                break;
            }
        }
    }
    return $score;
}

function hotelRecommendationScore(array $hotel, $travelStyle, $perNightBudget) {
    $ratingScore = min(40, max(0, ((float)$hotel['rating'] / 5) * 40));
    $price = (float)$hotel['price_per_night'];
    $budgetBase = max(1, (float)$perNightBudget);

    $ratio = $price / $budgetBase;
    if ($travelStyle === 'Budget') {
        $styleScore = $ratio <= 1 ? 30 : max(0, 30 - (($ratio - 1) * 30));
    } elseif ($travelStyle === 'Luxury') {
        $styleScore = min(30, 10 + ((float)$hotel['rating'] * 4));
    } else {
        $styleScore = $ratio <= 1.25 ? 30 : max(0, 30 - (($ratio - 1.25) * 35));
    }

    $budgetScore = $ratio <= 1 ? 20 : max(0, 20 - (($ratio - 1) * 20));
    return round($ratingScore + $styleScore + $budgetScore + 10, 1);
}

function transportRecommendationScore(array $transport, $travelStyle, $perTravelerBudget) {
    $price = (float)$transport['price'];
    $budgetBase = max(1, (float)$perTravelerBudget);
    $ratio = $price / $budgetBase;

    $typeScoreMap = [
        'Budget' => ['Bus' => 35, 'Train' => 28, 'Flight' => 12],
        'Standard' => ['Train' => 35, 'Flight' => 30, 'Bus' => 20],
        'Luxury' => ['Flight' => 40, 'Train' => 28, 'Bus' => 15]
    ];

    $typeScore = $typeScoreMap[$travelStyle][$transport['type']] ?? 15;
    $priceScore = $ratio <= 0.35 ? 40 : max(0, 40 - (($ratio - 0.35) * 45));
    $seatScore = ((int)($transport['seats'] ?? 0) > 0) ? 15 : 0;
    $durationScore = 10;

    return round($typeScore + $priceScore + $seatScore + $durationScore, 1);
}
