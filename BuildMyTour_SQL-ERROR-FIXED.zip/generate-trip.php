<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

$userId = (int) currentUserId();
$userCheck = $pdo->prepare("SELECT id FROM users WHERE id = ? LIMIT 1");
$userCheck->execute([$userId]);
if (!$userCheck->fetchColumn()) {
    unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['selection']);
    session_regenerate_id(true);
    flash('error', 'Your previous login session is no longer valid. Please login again.');
    header('Location: login.php');
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ai-planner.php');
    exit;
}

$destination = trim($_POST['destination'] ?? '');
$startDate = $_POST['start_date'] ?? '';
$endDate = $_POST['end_date'] ?? '';
$travelers = max(1, (int)($_POST['travelers'] ?? 1));
$budget = max(0, (float)($_POST['budget'] ?? 0));
$travelStyle = $_POST['travel_style'] ?? 'Standard';
$interests = normalizeInterests($_POST['interests'] ?? []);

$package = getTourPackage($destination);

if (
    !$package ||
    !$startDate ||
    !$endDate ||
    $budget < 1000 ||
    !in_array($travelStyle, ['Budget', 'Standard', 'Luxury'], true) ||
    strtotime($startDate) === false ||
    strtotime($endDate) === false ||
    strtotime($endDate) < strtotime($startDate)
) {
    flash('error', 'Please complete all required trip details.');
    header('Location: ai-planner.php');
    exit;
}

$days = max(1, (int)((strtotime($endDate) - strtotime($startDate)) / 86400) + 1);
$route = $package['cities'];
$startLocation = $route[0];
$estimatedDistance = 'Route planned across ' . implode(' → ', $route);

$stmt = $pdo->prepare(
    "INSERT INTO trips
    (user_id,start_location,destination,start_date,end_date,days,travelers,budget,travel_style,interests,transport_preference,estimated_distance,estimated_cost,status)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'planned')"
);
$stmt->execute([
    $userId,
    $startLocation,
    $destination,
    $startDate,
    $endDate,
    $days,
    $travelers,
    $budget,
    $travelStyle,
    implode(', ', $interests),
    '',
    $estimatedDistance,
    0
]);
$tripId = (int)$pdo->lastInsertId();

$selection =& $_SESSION['selection'][$tripId];
$selection = [];

$perTravelerBudget = $budget / max(1, $travelers);
$nights = max(1, $days - 1);
$perNightBudget = ($budget * 0.35) / $nights;

/* TRANSPORT SCORING */
$placeholders = implode(',', array_fill(0, count($route), '?'));

$transportStmt = $pdo->prepare(
    "SELECT * FROM transport
     WHERE status = 'active' AND seats >= ?
       AND to_location IN ($placeholders)
     ORDER BY price ASC"
);
$transportStmt->execute(array_merge([$travelers], $route));
$transportRows = $transportStmt->fetchAll();

// If demo data does not contain a route-specific option, use any active option.
if (!$transportRows) {
    $transportStmt = $pdo->prepare("SELECT * FROM transport WHERE status = 'active' AND seats >= ? ORDER BY price ASC");
    $transportStmt->execute([$travelers]);
    $transportRows = $transportStmt->fetchAll();
}

if (!$transportRows) {
    flash('error', 'No active transport options are available. Please contact the administrator.');
    header('Location: ai-planner.php');
    exit;
}

$bestTransport = null;
$bestTransportScore = -1;
foreach ($transportRows as $row) {
    $score = transportRecommendationScore($row, $travelStyle, $perTravelerBudget);
    if ($score > $bestTransportScore) {
        $bestTransport = $row;
        $bestTransportScore = $score;
    }
}
$selection['transport_id'] = (int)$bestTransport['id'];
$selection['transport_score'] = $bestTransportScore;

/* HOTEL SCORING */
$stmt = $pdo->prepare(
    "SELECT h.*, d.name AS destination_name
     FROM hotels h
     JOIN destinations d ON d.id = h.destination_id
     WHERE d.name IN ($placeholders) AND h.status = 'active'"
);
$stmt->execute($route);
$hotelRows = $stmt->fetchAll();

if (!$hotelRows) {
    flash('error', 'No active hotel options are available for this package.');
    header('Location: ai-planner.php');
    exit;
}

$bestHotel = null;
$bestHotelScore = -1;
foreach ($hotelRows as $row) {
    $score = hotelRecommendationScore($row, $travelStyle, $perNightBudget);
    if ($score > $bestHotelScore) {
        $bestHotel = $row;
        $bestHotelScore = $score;
    }
}
$selection['hotel_id'] = (int)$bestHotel['id'];
$selection['hotel_score'] = $bestHotelScore;

/* ACTIVITY SCORING */
$hasCategory = activityCategoryAvailable($pdo);
$categoryField = $hasCategory ? ", a.category" : "";
$stmt = $pdo->prepare(
    "SELECT a.*, d.name AS destination_name $categoryField
     FROM activities a
     JOIN destinations d ON d.id = a.destination_id
     WHERE d.name IN ($placeholders) AND a.status = 'active'"
);
$stmt->execute($route);
$activityRows = $stmt->fetchAll();

$scoredActivities = [];
foreach ($activityRows as $activity) {
    $interestScore = activityInterestScore($activity, $interests);
    $price = (float)$activity['price'];

    if ($travelStyle === 'Budget') {
        $styleScore = $price <= ($budget * 0.05) ? 25 : max(0, 25 - (($price / max(1, $budget)) * 200));
    } elseif ($travelStyle === 'Luxury') {
        $styleScore = 18 + min(12, $price / 250);
    } else {
        $styleScore = $price <= ($budget * 0.08) ? 25 : 12;
    }

    $coverageBonus = !empty($interests) ? 0 : 10;
    $score = round($interestScore + $styleScore + $coverageBonus, 1);

    $scoredActivities[] = [
        'id' => (int)$activity['id'],
        'score' => $score,
        'destination_name' => $activity['destination_name']
    ];
}

usort($scoredActivities, function ($a, $b) {
    return $b['score'] <=> $a['score'];
});

$activityLimit = $travelStyle === 'Budget' ? 3 : ($travelStyle === 'Luxury' ? 5 : 4);
$selectedActivityIds = [];
$selectedScores = [];
$coveredDestinations = [];

/* First ensure the route's destinations are represented. */
foreach ($scoredActivities as $candidate) {
    if (count($selectedActivityIds) >= $activityLimit) break;
    if (!in_array($candidate['destination_name'], $coveredDestinations, true)) {
        $selectedActivityIds[] = $candidate['id'];
        $selectedScores[$candidate['id']] = $candidate['score'];
        $coveredDestinations[] = $candidate['destination_name'];
    }
}

/* Then fill remaining recommendation slots by score. */
foreach ($scoredActivities as $candidate) {
    if (count($selectedActivityIds) >= $activityLimit) break;
    if (!in_array($candidate['id'], $selectedActivityIds, true)) {
        $selectedActivityIds[] = $candidate['id'];
        $selectedScores[$candidate['id']] = $candidate['score'];
    }
}

$selection['activity_ids'] = $selectedActivityIds;
$selection['activity_scores'] = $selectedScores;
$selection['interests'] = $interests;
$selection['recommendation_explanation'] = [
    'transport' => 'Scored using travel style, budget fit, price and availability.',
    'hotel' => 'Scored using rating, travel style and estimated nightly budget.',
    'activities' => !empty($interests)
        ? 'Matched primarily with your selected interests, then travel style and budget.'
        : 'Selected using destination coverage, travel style and budget.'
];
$selection['system_generated'] = true;

// Persist the smart selections so the trip can still be opened after the PHP session expires.
$persist = $pdo->prepare(
    "UPDATE trips SET selected_transport_id = ?, selected_hotel_id = ?, selected_activity_ids = ? WHERE id = ? AND user_id = ?"
);
$persist->execute([
    $selection['transport_id'],
    $selection['hotel_id'],
    implode(',', $selection['activity_ids']),
    $tripId,
    $userId
]);

header("Location: trip-summary.php?trip_id=$tripId");
exit;
