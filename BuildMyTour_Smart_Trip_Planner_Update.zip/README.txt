BuildMyTour – Smart Trip Planner Update

1. Backup your current project.
2. Replace/add these files in the project root:
   - ai-planner.php
   - generate-smart-trip.php
   - smart-trip-result.php
3. Run smart_trip_planner_migration.sql once in phpMyAdmin.
4. The existing 8-table structure remains unchanged.
5. The new flow is:
   Smart Planner Form
   -> Preference-based matching
   -> Recommended Stay
   -> Recommended Activities
   -> Transport Suggestion
   -> Estimated Cost
   -> My Trips

Important:
- Update any navbar/home CTA that still points to the old AI planner page only if your current filename differs.
- This version intentionally removes day-wise itinerary generation from the new Smart Trip Planner flow.
- Activities are read from the existing destinations table using:
  parent_id = selected destination
  type = 'activity'
