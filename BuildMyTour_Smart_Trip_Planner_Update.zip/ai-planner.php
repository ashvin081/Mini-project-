<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/session.php';

if (!isset($_SESSION['user_id']) || (int)$_SESSION['user_id'] <= 0) {
    header('Location: ' . BASE_URL . 'login.php');
    exit();
}

$pageTitle = 'Smart Trip Planner';

$destinations = [];
$result = $conn->query("
    SELECT destination_id, name, state
    FROM destinations
    WHERE type = 'main_destination'
    ORDER BY name ASC
");
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $destinations[] = $row;
    }
}

require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<section class="planner-hero">
    <div class="container">
        <div class="planner-hero-content">
            <span class="planner-tag"><i class="bi bi-compass"></i> SMART TRIP PLANNER</span>
            <h1>Plan Smarter. <span>Travel Better.</span></h1>
            <p>Tell us your preferences and BuildMyTour will recommend the best stay, activities, transport and estimated trip cost.</p>
        </div>
    </div>
</section>

<section class="planner-section py-5">
    <div class="container">
        <form id="tripPlannerForm" method="POST" action="generate-smart-trip.php">
            <div class="planner-form-wrapper">

                <div class="planner-input-card">
                    <div class="planner-card-heading">
                        <div class="planner-heading-icon"><i class="bi bi-map"></i></div>
                        <div>
                            <span>STEP 1</span>
                            <h2>Trip Details</h2>
                            <p>Choose where, how long and with whom you want to travel.</p>
                        </div>
                    </div>

                    <div class="planner-grid">
                        <div class="planner-group">
                            <label for="destination_id"><i class="bi bi-pin-map"></i> Destination</label>
                            <select name="destination_id" id="destination_id" required>
                                <option value="">Select Destination</option>
                                <?php foreach ($destinations as $destination): ?>
                                    <option value="<?php echo (int)$destination['destination_id']; ?>">
                                        <?php echo htmlspecialchars($destination['name'] . (!empty($destination['state']) ? ' - ' . $destination['state'] : '')); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="planner-group">
                            <label for="trip_days"><i class="bi bi-calendar-event"></i> Trip Duration</label>
                            <select name="trip_days" id="trip_days" required>
                                <option value="">Select Days</option>
                                <?php for ($day = 1; $day <= 7; $day++): ?>
                                    <option value="<?php echo $day; ?>"><?php echo $day . ' Day' . ($day > 1 ? 's' : ''); ?></option>
                                <?php endfor; ?>
                            </select>
                        </div>

                        <div class="planner-group">
                            <label for="travelers"><i class="bi bi-people"></i> Travelers</label>
                            <input type="number" name="travelers" id="travelers" min="1" max="20" value="2" required>
                        </div>

                        <div class="planner-group">
                            <label for="budget"><i class="bi bi-wallet2"></i> Total Budget</label>
                            <div class="planner-input-prefix">
                                <span>₹</span>
                                <input type="number" name="budget" id="budget" min="1000" step="500" placeholder="Example: 20000" required>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="planner-input-card">
                    <div class="planner-card-heading">
                        <div class="planner-heading-icon"><i class="bi bi-heart"></i></div>
                        <div>
                            <span>STEP 2</span>
                            <h2>Your Travel Interests</h2>
                            <p>Select up to 4 interests. These are used to recommend activities.</p>
                        </div>
                    </div>

                    <div class="interest-options" id="interestOptions">
                        <?php
                        $interestOptions = [
                            'Beach' => 'sun',
                            'Adventure' => 'lightning-charge',
                            'Nature' => 'tree',
                            'Historical' => 'bank',
                            'Food' => 'cup-hot',
                            'Shopping' => 'bag',
                            'Photography' => 'camera',
                            'Spiritual' => 'peace',
                            'Wildlife' => 'binoculars'
                        ];
                        foreach ($interestOptions as $interest => $icon):
                        ?>
                            <label class="interest-option">
                                <input type="checkbox" name="interests[]" value="<?php echo htmlspecialchars($interest); ?>">
                                <span><i class="bi bi-<?php echo $icon; ?>"></i> <?php echo htmlspecialchars($interest); ?></span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                    <small class="text-muted d-block mt-3">Select at least 1 and maximum 4 interests.</small>
                </div>

                <div class="planner-input-card">
                    <div class="planner-card-heading">
                        <div class="planner-heading-icon"><i class="bi bi-building"></i></div>
                        <div>
                            <span>STEP 3</span>
                            <h2>Stay Preference</h2>
                            <p>We will recommend a stay that best matches your budget.</p>
                        </div>
                    </div>

                    <div class="transport-options">
                        <?php
                        $stays = [
                            'Budget' => 'wallet2',
                            'Standard' => 'building',
                            'Premium' => 'stars'
                        ];
                        foreach ($stays as $stay => $icon):
                        ?>
                            <label class="transport-option <?php echo $stay === 'Standard' ? 'active' : ''; ?>">
                                <input type="radio" name="stay_preference" value="<?php echo $stay; ?>" <?php echo $stay === 'Standard' ? 'checked' : ''; ?>>
                                <div><i class="bi bi-<?php echo $icon; ?>"></i><span><?php echo $stay; ?></span></div>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="planner-input-card">
                    <div class="planner-card-heading">
                        <div class="planner-heading-icon"><i class="bi bi-car-front"></i></div>
                        <div>
                            <span>STEP 4</span>
                            <h2>Transport Preference</h2>
                            <p>Choose your preferred way to travel.</p>
                        </div>
                    </div>

                    <div class="transport-options">
                        <?php
                        $transports = ['Any' => 'shuffle', 'Bus' => 'bus-front', 'Train' => 'train-front', 'Flight' => 'airplane', 'Car' => 'car-front'];
                        foreach ($transports as $transport => $icon):
                        ?>
                            <label class="transport-option <?php echo $transport === 'Any' ? 'active' : ''; ?>">
                                <input type="radio" name="transport_preference" value="<?php echo $transport; ?>" <?php echo $transport === 'Any' ? 'checked' : ''; ?>>
                                <div><i class="bi bi-<?php echo $icon; ?>"></i><span><?php echo $transport; ?></span></div>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

                <div class="planner-submit-area">
                    <button type="submit" class="generate-trip-btn">
                        <i class="bi bi-stars"></i>
                        Generate Smart Plan
                        <i class="bi bi-arrow-right"></i>
                    </button>
                    <p>Your recommendations are generated from your destination, duration, budget, interests, travelers and preferences.</p>
                </div>
            </div>
        </form>
    </div>
</section>

<script>
document.querySelectorAll('#interestOptions input[type="checkbox"]').forEach(function(input) {
    input.addEventListener('change', function() {
        const checked = document.querySelectorAll('#interestOptions input[type="checkbox"]:checked');
        if (checked.length > 4) {
            this.checked = false;
            alert('You can select maximum 4 interests.');
        }
    });
});

document.querySelectorAll('.transport-option input[type="radio"]').forEach(function(input) {
    input.addEventListener('change', function() {
        const group = this.closest('.transport-options');
        if (group) {
            group.querySelectorAll('.transport-option').forEach(function(item) {
                item.classList.remove('active');
            });
            this.closest('.transport-option').classList.add('active');
        }
    });
});
</script>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
