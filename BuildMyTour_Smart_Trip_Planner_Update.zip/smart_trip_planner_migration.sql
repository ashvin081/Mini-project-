-- BuildMyTour Smart Trip Planner update
-- Keeps the existing 8-table design. Only one new column is added.

ALTER TABLE trip_plans
ADD COLUMN stay_preference VARCHAR(20) NOT NULL DEFAULT 'Standard'
AFTER food_budget;
