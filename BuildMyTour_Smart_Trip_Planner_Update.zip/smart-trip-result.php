<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/session.php';

if (!isset($_SESSION['user_id']) || (int)$_SESSION['user_id'] <= 0) {
    header('Location: ' . BASE_URL . 'login.php');
    exit();
}

$tripId = (int)($_GET['trip_id'] ?? 0);
if ($tripId <= 0) {
    header('Location: ' . BASE_URL . 'ai-planner.php');
    exit();
}

$resultData = $_SESSION['smart_trip_result'] ?? null;
if (!$resultData || (int)($resultData['trip_id'] ?? 0) !== $tripId) {
    $stmt = $conn->prepare("
        SELECT tp.*, d.name AS destination_name, d.state
        FROM trip_plans tp
        JOIN destinations d ON d.destination_id = tp.destination_id
        WHERE tp.trip_id = ? AND tp.user_id = ?
        LIMIT 1
    ");
    $userId = (int)$_SESSION['user_id'];
    $stmt->bind_param('ii', $tripId, $userId);
    $stmt->execute();
    $trip = $stmt->get_result()->fetch_assoc();
    $stmt->close();

    if (!$trip) {
        header('Location: ' . BASE_URL . 'my-trips.php');
        exit();
    }

    $resultData = [
        'trip_id' => $tripId,
        'destination' => ['name' => $trip['destination_name'], 'state' => $trip['state']],
        'interests' => array_filter(array_map('trim', explode(',', $trip['interests'] ?? ''))),
        'stay_preference' => $trip['stay_preference'] ?? 'Standard',
        'transport_name' => $trip['transport_name'],
        'transport_cost' => (float)$trip['transport_cost'],
        'stay_name' => $trip['resort_name'],
        'stay_price' => (float)$trip['resort_price'],
        'stay_total' => (float)$trip['resort_price'] * max(1, (int)$trip['trip_days'] - 1),
        'activity_budget' => 0,
        'food_total' => 0,
        'local_travel_cost' => 0,
        'estimated_total' => (float)$trip['total_estimated_cost'],
        'budget_fit' => (float)$trip['total_estimated_cost'] <= (float)$trip['budget'],
        'budget' => (float)$trip['budget'],
        'match_score' => 85,
        'recommended_activities' => []
    ];
}

$pageTitle = 'Your Smart Trip Plan';
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';

function money($amount) {
    return '₹' . number_format((float)$amount, 0);
}
?>

<section class="py-5" style="background:#f6f8fb;min-height:80vh;">
    <div class="container">
        <div class="text-center mb-4">
            <span class="badge rounded-pill px-3 py-2 text-bg-light border"><i class="bi bi-stars"></i> SMART RECOMMENDATION</span>
            <h1 class="mt-3 mb-2">Your Smart Trip Plan</h1>
            <p class="text-muted mb-0">Based on your budget, interests, travelers and preferences.</p>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mb-4">
            <div class="card-body p-4 p-md-5">
                <div class="row align-items-center g-4">
                    <div class="col-md-8">
                        <h2 class="mb-1"><?php echo htmlspecialchars($resultData['destination']['name']); ?></h2>
                        <p class="text-muted mb-3"><?php echo htmlspecialchars($resultData['destination']['state'] ?? ''); ?></p>
                        <div class="d-flex flex-wrap gap-2">
                            <?php foreach ($resultData['interests'] as $interest): ?>
                                <span class="badge rounded-pill text-bg-light border"><?php echo htmlspecialchars($interest); ?></span>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <div class="col-md-4 text-md-end">
                        <div class="display-6 fw-bold"><?php echo (int)$resultData['match_score']; ?>%</div>
                        <div class="text-success fw-semibold">Best Match Score</div>
                        <small class="text-muted">Budget + Interests + Stay Preference</small>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <div class="text-primary fs-3 mb-2"><i class="bi bi-building"></i></div>
                        <h4>Recommended Stay</h4>
                        <h5 class="mb-1"><?php echo htmlspecialchars($resultData['stay_name']); ?></h5>
                        <p class="text-muted"><?php echo htmlspecialchars($resultData['stay_preference']); ?> preference</p>
                        <div class="fw-bold"><?php echo money($resultData['stay_price']); ?> / night</div>
                        <small class="text-muted">Estimated stay total: <?php echo money($resultData['stay_total']); ?></small>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <div class="text-primary fs-3 mb-2"><i class="bi bi-car-front"></i></div>
                        <h4>Transport Suggestion</h4>
                        <h5><?php echo htmlspecialchars($resultData['transport_name']); ?></h5>
                        <p class="text-muted">Selected automatically or from your preference.</p>
                        <div class="fw-bold"><?php echo money($resultData['transport_cost']); ?></div>
                        <small class="text-muted">Estimated transport cost for the group</small>
                    </div>
                </div>
            </div>

            <div class="col-lg-4">
                <div class="card h-100 border-0 shadow-sm rounded-4">
                    <div class="card-body p-4">
                        <div class="text-primary fs-3 mb-2"><i class="bi bi-wallet2"></i></div>
                        <h4>Budget Status</h4>
                        <h5 class="<?php echo $resultData['budget_fit'] ? 'text-success' : 'text-warning'; ?>">
                            <?php echo $resultData['budget_fit'] ? 'Within Your Budget' : 'Budget Needs Adjustment'; ?>
                        </h5>
                        <div class="fw-bold">Estimated: <?php echo money($resultData['estimated_total']); ?></div>
                        <small class="text-muted">Your budget: <?php echo money($resultData['budget']); ?></small>
                    </div>
                </div>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mt-4">
            <div class="card-body p-4 p-md-5">
                <div class="d-flex justify-content-between align-items-center flex-wrap gap-2 mb-4">
                    <div>
                        <h3 class="mb-1">Recommended Activities</h3>
                        <p class="text-muted mb-0">Matched with your selected interests.</p>
                    </div>
                    <span class="badge text-bg-light border">Smart Match</span>
                </div>

                <?php if (!empty($resultData['recommended_activities'])): ?>
                    <div class="row g-3">
                        <?php foreach ($resultData['recommended_activities'] as $activity): ?>
                            <div class="col-md-6 col-lg-3">
                                <div class="border rounded-4 p-3 h-100">
                                    <div class="fs-4 mb-2"><i class="bi bi-compass"></i></div>
                                    <h6><?php echo htmlspecialchars($activity['name']); ?></h6>
                                    <p class="small text-muted mb-2"><?php echo htmlspecialchars(mb_strimwidth($activity['description'] ?? '', 0, 100, '...')); ?></p>
                                    <span class="badge text-bg-light border"><?php echo (int)($activity['match_score'] ?? 70); ?>% match</span>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div class="alert alert-light border mb-0">
                        No activity records are available for this destination yet. Add activities under this destination from the existing destination data.
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="card border-0 shadow-sm rounded-4 mt-4">
            <div class="card-body p-4 p-md-5">
                <h3 class="mb-4">Estimated Trip Summary</h3>
                <div class="row g-3">
                    <div class="col-md-3"><div class="p-3 border rounded-3"><small class="text-muted">Stay</small><div class="fw-bold"><?php echo money($resultData['stay_total']); ?></div></div></div>
                    <div class="col-md-3"><div class="p-3 border rounded-3"><small class="text-muted">Transport</small><div class="fw-bold"><?php echo money($resultData['transport_cost']); ?></div></div></div>
                    <div class="col-md-3"><div class="p-3 border rounded-3"><small class="text-muted">Activities</small><div class="fw-bold"><?php echo money($resultData['activity_budget']); ?></div></div></div>
                    <div class="col-md-3"><div class="p-3 border rounded-3"><small class="text-muted">Estimated Total</small><div class="fw-bold"><?php echo money($resultData['estimated_total']); ?></div></div></div>
                </div>
            </div>
        </div>

        <div class="d-flex justify-content-center flex-wrap gap-3 mt-4">
            <a href="<?php echo BASE_URL; ?>ai-planner.php" class="btn btn-outline-secondary px-4">Plan Another Trip</a>
            <a href="<?php echo BASE_URL; ?>my-trips.php?trip_id=<?php echo (int)$resultData['trip_id']; ?>" class="btn btn-primary px-4">Save & View My Trip</a>
        </div>
    </div>
</section>

<?php require_once __DIR__ . '/includes/footer.php'; ?>
