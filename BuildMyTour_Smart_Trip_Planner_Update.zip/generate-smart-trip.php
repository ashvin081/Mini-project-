<?php
require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/db.php';
require_once __DIR__ . '/includes/session.php';

if (!isset($_SESSION['user_id']) || (int)$_SESSION['user_id'] <= 0) {
    header('Location: ' . BASE_URL . 'login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . BASE_URL . 'ai-planner.php');
    exit();
}

function fail($message) {
    http_response_code(422);
    echo '<!doctype html><html><body style="font-family:Arial;padding:40px">';
    echo '<h2>Smart Trip Planner</h2><p>' . htmlspecialchars($message) . '</p>';
    echo '<p><a href="' . htmlspecialchars(BASE_URL . 'ai-planner.php') . '">Go back</a></p></body></html>';
    exit();
}

$userId = (int)$_SESSION['user_id'];
$destinationId = (int)($_POST['destination_id'] ?? 0);
$tripDays = (int)($_POST['trip_days'] ?? 0);
$travelers = (int)($_POST['travelers'] ?? 0);
$budget = (float)($_POST['budget'] ?? 0);
$interests = $_POST['interests'] ?? [];
$stayPreference = trim($_POST['stay_preference'] ?? 'Standard');
$transportPreference = trim($_POST['transport_preference'] ?? 'Any');

if ($destinationId <= 0) fail('Please select a destination.');
if ($tripDays < 1 || $tripDays > 7) fail('Trip duration must be between 1 and 7 days.');
if ($travelers < 1 || $travelers > 20) fail('Travelers must be between 1 and 20.');
if ($budget < 1000) fail('Minimum trip budget is ₹1,000.');
if (!in_array($stayPreference, ['Budget', 'Standard', 'Premium'], true)) fail('Invalid stay preference.');
if (!in_array($transportPreference, ['Any', 'Bus', 'Train', 'Flight', 'Car'], true)) fail('Invalid transport preference.');

if (!is_array($interests)) $interests = [];
$interests = array_values(array_unique(array_filter(array_map('trim', $interests))));
if (count($interests) < 1 || count($interests) > 4) fail('Please select between 1 and 4 interests.');

$destinationStmt = $conn->prepare("
    SELECT destination_id, name, state
    FROM destinations
    WHERE destination_id = ? AND type = 'main_destination'
    LIMIT 1
");
if (!$destinationStmt) fail('Database error: ' . $conn->error);
$destinationStmt->bind_param('i', $destinationId);
$destinationStmt->execute();
$destination = $destinationStmt->get_result()->fetch_assoc();
$destinationStmt->close();
if (!$destination) fail('Selected destination is invalid.');

$stayPriceMap = ['Budget' => 1200, 'Standard' => 2200, 'Premium' => 4000];
$stayPrice = $stayPriceMap[$stayPreference];
$nights = max(1, $tripDays - 1);
$stayTotal = $stayPrice * $nights;

$transportPerPerson = ['Bus' => 800, 'Train' => 1500, 'Flight' => 3500, 'Car' => 2200];
if ($transportPreference === 'Any') {
    $perPersonPerDay = $budget / max(1, $travelers * $tripDays);
    $transportName = $perPersonPerDay < 1500 ? 'Bus' : ($perPersonPerDay < 3000 ? 'Train' : 'Car');
} else {
    $transportName = $transportPreference;
}
$transportCost = $transportPerPerson[$transportName] * $travelers;

$foodPerPersonPerDay = 350;
$foodTotal = $foodPerPersonPerDay * $travelers * $tripDays;
$localTravelCost = 250 * $travelers * $tripDays;

$activityBudget = max(800, min(
    $budget * 0.30,
    max(800, $budget - $stayTotal - $transportCost - $foodTotal - $localTravelCost)
));

$estimatedTotal = $stayTotal + $transportCost + $foodTotal + $localTravelCost + $activityBudget;
if ($estimatedTotal > $budget) {
    $activityBudget = max(0, $budget - $stayTotal - $transportCost - $foodTotal - $localTravelCost);
    $estimatedTotal = $stayTotal + $transportCost + $foodTotal + $localTravelCost + $activityBudget;
}

$resortName = $destination['name'] . ' ' . ($stayPreference === 'Budget' ? 'Value Stay' : ($stayPreference === 'Premium' ? 'Premium Stay' : 'Comfort Stay'));
$resortLocation = $destination['name'];
$interestsString = implode(',', $interests);
$status = 'planned';

/*
  Activity matching:
  The project keeps activities inside the existing destinations table.
  No extra database table is required.
*/
$activityStmt = $conn->prepare("
    SELECT destination_id, name, image_url, description
    FROM destinations
    WHERE parent_id = ? AND type = 'activity'
");
if (!$activityStmt) {
    fail('Database error: ' . $conn->error);
}
$activityStmt->bind_param('i', $destinationId);
$activityStmt->execute();
$activityRows = $activityStmt->get_result()->fetch_all(MYSQLI_ASSOC);
$activityStmt->close();

$keywords = [
    'Beach' => ['beach','sea','water','coast','island'],
    'Adventure' => ['adventure','trek','hike','ride','sport','camp'],
    'Nature' => ['nature','park','lake','waterfall','forest','hill','mountain'],
    'Historical' => ['heritage','history','fort','palace','museum','temple'],
    'Food' => ['food','cafe','restaurant','market','local'],
    'Shopping' => ['shopping','market','bazaar','mall'],
    'Photography' => ['photo','view','sunset','viewpoint','scenic'],
    'Spiritual' => ['temple','church','mosque','spiritual','shrine'],
    'Wildlife' => ['wildlife','safari','zoo','bird','forest']
];

foreach ($activityRows as &$activity) {
    $text = strtolower(($activity['name'] ?? '') . ' ' . ($activity['description'] ?? ''));
    $score = 20;
    foreach ($interests as $interest) {
        foreach ($keywords[$interest] ?? [] as $keyword) {
            if (strpos($text, $keyword) !== false) {
                $score += 20;
                break;
            }
        }
    }
    $activity['match_score'] = min(100, $score);
}
unset($activity);

usort($activityRows, function($a, $b) {
    return $b['match_score'] <=> $a['match_score'];
});

$recommendedActivities = array_slice($activityRows, 0, 4);

/* If a destination has no activity records, the result still works. */
$budgetFit = $estimatedTotal <= $budget;
$budgetScore = $budgetFit ? 100 : max(40, 100 - (int)(($estimatedTotal - $budget) / max(1, $budget) * 100));
$interestScore = min(100, 40 + count($recommendedActivities) * 15);
$stayScore = 90;
$matchScore = (int)round(($budgetScore * 0.40) + ($interestScore * 0.30) + ($stayScore * 0.30));

$conn->begin_transaction();
try {
    $insertSql = "
        INSERT INTO trip_plans
        (
            user_id,
            start_location,
            destination_id,
            trip_days,
            budget,
            travelers,
            interests,
            travel_style,
            food_preference,
            food_budget,
            transport_preference,
            transport_name,
            transport_image,
            transport_cost,
            resort_name,
            resort_location,
            resort_image,
            resort_price,
            total_estimated_cost,
            status,
            stay_preference
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '', ?, ?, ?, '', ?, ?, ?, ?)
    ";

    $startLocation = 'Not Required';
    $travelStyle = 'Smart Recommendation';
    $foodPreference = 'Flexible';
    $foodBudget = $foodPerPersonPerDay * $travelers;
    $transportImage = '';
    $resortImage = '';

    $stmt = $conn->prepare($insertSql);
    if (!$stmt) throw new Exception($conn->error);

    $stmt->bind_param(
        'isiidisssdssds ssdsss',
        $userId,
        $startLocation,
        $destinationId,
        $tripDays,
        $budget,
        $travelers,
        $interestsString,
        $travelStyle,
        $foodPreference,
        $foodBudget,
        $transportPreference,
        $transportName,
        $transportCost,
        $resortName,
        $resortLocation,
        $stayPrice,
        $estimatedTotal,
        $status,
        $stayPreference
    );

    // mysqli bind_param type string cannot contain spaces.
    $stmt->close();

    $stmt = $conn->prepare($insertSql);
    if (!$stmt) throw new Exception($conn->error);
    $types = 'isiidisssdssdssddss';
    $stmt->bind_param(
        $types,
        $userId,
        $startLocation,
        $destinationId,
        $tripDays,
        $budget,
        $travelers,
        $interestsString,
        $travelStyle,
        $foodPreference,
        $foodBudget,
        $transportPreference,
        $transportName,
        $transportCost,
        $resortName,
        $resortLocation,
        $stayPrice,
        $estimatedTotal,
        $status,
        $stayPreference
    );
    if (!$stmt->execute()) throw new Exception($stmt->error);
    $tripId = $conn->insert_id;
    $stmt->close();

    $conn->commit();

    $_SESSION['smart_trip_result'] = [
        'trip_id' => $tripId,
        'destination' => $destination,
        'interests' => $interests,
        'stay_preference' => $stayPreference,
        'transport_name' => $transportName,
        'transport_cost' => $transportCost,
        'stay_name' => $resortName,
        'stay_price' => $stayPrice,
        'stay_total' => $stayTotal,
        'activity_budget' => $activityBudget,
        'food_total' => $foodTotal,
        'local_travel_cost' => $localTravelCost,
        'estimated_total' => $estimatedTotal,
        'budget_fit' => $budgetFit,
        'budget' => $budget,
        'match_score' => $matchScore,
        'recommended_activities' => $recommendedActivities
    ];

    header('Location: ' . BASE_URL . 'smart-trip-result.php?trip_id=' . $tripId);
    exit();

} catch (Throwable $e) {
    $conn->rollback();
    fail('Trip generation failed: ' . $e->getMessage());
}
