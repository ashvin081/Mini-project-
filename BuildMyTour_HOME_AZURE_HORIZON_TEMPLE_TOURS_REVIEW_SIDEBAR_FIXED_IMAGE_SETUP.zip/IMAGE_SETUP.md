# BuildMyTour Local Image Setup

The project is already configured for local images. You do not need to change PHP code when replacing the placeholders.

## Package images
Put/replace images in:
`assets/images/packages/`

Exact filenames:
- `leh-ladakh.jpg`
- `rajasthan-royal.jpg`
- `ujjain-omkareshwar.jpg`
- `gir-wildlife.jpg`
- `kutch-white-desert.jpg`
- `rishikesh-adventure.jpg`

## Trip type images
Put/replace images in:
`assets/images/trip-types/`

Exact filenames:
- `adventure-nature.jpg`
- `culture-heritage.jpg`
- `adventure-spiritual.jpg`

## Current behavior
Placeholder images are included so there are no broken-image icons now. Simply overwrite a placeholder with your real image using the same filename.

The frontend uses the database image path, and the image cards also have a fallback to `assets/images/placeholder.jpg` if an image is missing.

## Recommended image format
- JPG or WebP
- Landscape orientation
- Approx. 1200x800 (or similar)
- Keep file sizes reasonably optimized for faster page loading
