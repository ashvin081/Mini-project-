BUILDMYTOUR - PACKAGE IMAGES

Replace the placeholder files in this folder with your real local images.
Keep the exact filenames below so the database/frontend automatically uses them:

1. leh-ladakh.jpg
2. rajasthan-royal.jpg
3. ujjain-omkareshwar.jpg
4. gir-wildlife.jpg
5. kutch-white-desert.jpg
6. rishikesh-adventure.jpg

Recommended: JPG or WebP, landscape 4:3 or 16:9, around 1200x800 or similar.
Do not change the filenames unless you also update the image path in the database.
