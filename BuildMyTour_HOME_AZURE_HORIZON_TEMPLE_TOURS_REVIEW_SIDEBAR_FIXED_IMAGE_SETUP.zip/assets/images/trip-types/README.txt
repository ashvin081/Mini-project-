BUILDMYTOUR - TRIP TYPE IMAGES

Replace the placeholder files in this folder with your real local images.
Keep the exact filenames below:

1. adventure-nature.jpg
2. culture-heritage.jpg
3. adventure-spiritual.jpg

Recommended: JPG or WebP, landscape 4:3 or 16:9, around 1200x800 or similar.
Do not change the filenames unless you also update the image path in the database.
