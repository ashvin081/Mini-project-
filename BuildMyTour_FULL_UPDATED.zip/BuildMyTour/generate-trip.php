<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ai-planner.php');
    exit;
}

$userId = (int) currentUserId();
$userCheck = $pdo->prepare('SELECT id FROM users WHERE id = ? LIMIT 1');
$userCheck->execute([$userId]);
if (!$userCheck->fetchColumn()) {
    unset($_SESSION['user_id'], $_SESSION['user_name'], $_SESSION['selection']);
    session_regenerate_id(true);
    flash('error', 'Your previous login session is no longer valid. Please login again.');
    header('Location: login.php');
    exit;
}

$destinationId = (int)($_POST['destination_id'] ?? 0);
$startDate = $_POST['start_date'] ?? '';
$days = (int)($_POST['trip_days'] ?? 0);
$travelers = (int)($_POST['travelers'] ?? 0);
$budget = (float)($_POST['budget'] ?? 0);
$interests = normalizeInterests($_POST['interests'] ?? []);
$stayPreference = $_POST['stay_preference'] ?? 'Standard';
$transportPreference = $_POST['transport_preference'] ?? 'Any';

if ($destinationId <= 0 || !$startDate || strtotime($startDate) === false || $days < 1 || $days > 10 || $travelers < 1 || $travelers > 20 || $budget < 1000 || count($interests) < 1 || count($interests) > 4) {
    flash('error', 'Please complete all required Smart Trip Planner details.');
    header('Location: ai-planner.php');
    exit;
}
if (!in_array($stayPreference, ['Budget','Standard','Premium'], true) || !in_array($transportPreference, ['Any','Bus','Train','Flight'], true)) {
    flash('error', 'Invalid travel preferences.');
    header('Location: ai-planner.php');
    exit;
}

$destinationStmt = $pdo->prepare('SELECT * FROM destinations WHERE id = ? AND status = \'active\' LIMIT 1');
$destinationStmt->execute([$destinationId]);
$destination = $destinationStmt->fetch();
if (!$destination) {
    flash('error', 'Selected destination is not available.');
    header('Location: ai-planner.php');
    exit;
}

$endDate = date('Y-m-d', strtotime($startDate . ' +' . max(0, $days - 1) . ' days'));
$travelStyle = $stayPreference === 'Premium' ? 'Luxury' : $stayPreference;
$estimatedDistance = 'Smart plan for ' . $destination['name'];

$pdo->beginTransaction();
try {
    $insert = $pdo->prepare(
        "INSERT INTO trips
        (user_id,start_location,destination,start_date,end_date,days,travelers,budget,travel_style,interests,transport_preference,estimated_distance,estimated_cost,status)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,'planned')"
    );
    $insert->execute([
        $userId,
        'Not specified',
        $destination['name'],
        $startDate,
        $endDate,
        $days,
        $travelers,
        $budget,
        $travelStyle,
        implode(', ', $interests),
        $transportPreference,
        $estimatedDistance,
        0
    ]);
    $tripId = (int)$pdo->lastInsertId();

    $selection =& $_SESSION['selection'][$tripId];
    $selection = [];

    $perTravelerBudget = $budget / max(1, $travelers);
    $nights = max(1, $days - 1);
    $perNightBudget = ($budget * 0.40) / $nights;

    // TRANSPORT: first try the selected destination, then safely fall back to any active option.
    if ($transportPreference === 'Any') {
        $transportStmt = $pdo->prepare('SELECT * FROM transport WHERE status = \'active\' AND seats >= ? AND to_location = ? ORDER BY price ASC');
        $transportStmt->execute([$travelers, $destination['name']]);
    } else {
        $transportStmt = $pdo->prepare('SELECT * FROM transport WHERE status = \'active\' AND seats >= ? AND to_location = ? AND type = ? ORDER BY price ASC');
        $transportStmt->execute([$travelers, $destination['name'], $transportPreference]);
    }
    $transportRows = $transportStmt->fetchAll();

    if (!$transportRows) {
        if ($transportPreference === 'Any') {
            $transportStmt = $pdo->prepare('SELECT * FROM transport WHERE status = \'active\' AND seats >= ? ORDER BY price ASC');
            $transportStmt->execute([$travelers]);
        } else {
            $transportStmt = $pdo->prepare('SELECT * FROM transport WHERE status = \'active\' AND seats >= ? AND type = ? ORDER BY price ASC');
            $transportStmt->execute([$travelers, $transportPreference]);
        }
        $transportRows = $transportStmt->fetchAll();
    }
    if (!$transportRows) throw new RuntimeException('No active transport options are available.');

    $bestTransport = null;
    $bestTransportScore = -1;
    foreach ($transportRows as $row) {
        $score = transportRecommendationScore($row, $travelStyle, $perTravelerBudget);
        if ($score > $bestTransportScore) { $bestTransport = $row; $bestTransportScore = $score; }
    }

    // HOTEL: only the selected destination is considered.
    $hotelStmt = $pdo->prepare('SELECT * FROM hotels WHERE destination_id = ? AND status = \'active\'');
    $hotelStmt->execute([$destinationId]);
    $hotelRows = $hotelStmt->fetchAll();
    if (!$hotelRows) throw new RuntimeException('No active hotel options are available for this destination.');

    $bestHotel = null;
    $bestHotelScore = -1;
    foreach ($hotelRows as $row) {
        $score = hotelRecommendationScore($row, $travelStyle, $perNightBudget);
        if ($score > $bestHotelScore) { $bestHotel = $row; $bestHotelScore = $score; }
    }

    // ACTIVITIES: rank the selected destination's activities by interest match and budget fit.
    $hasCategory = activityCategoryAvailable($pdo);
    $activityStmt = $pdo->prepare('SELECT * FROM activities WHERE destination_id = ? AND status = \'active\'');
    $activityStmt->execute([$destinationId]);
    $activityRows = $activityStmt->fetchAll();

    $scoredActivities = [];
    foreach ($activityRows as $activity) {
        $interestScore = activityInterestScore($activity, $interests);
        $price = (float)$activity['price'];
        $budgetScore = $price <= ($budget * 0.12) ? 30 : max(0, 30 - (($price / max(1, $budget)) * 120));
        $score = round($interestScore + $budgetScore + 20, 1);
        $scoredActivities[] = ['id' => (int)$activity['id'], 'score' => $score];
    }
    usort($scoredActivities, fn($a, $b) => $b['score'] <=> $a['score']);
    $activityLimit = $travelStyle === 'Budget' ? 3 : ($travelStyle === 'Luxury' ? 5 : 4);
    $selectedActivityIds = array_slice(array_column($scoredActivities, 'id'), 0, $activityLimit);
    $selectedScores = [];
    foreach ($scoredActivities as $item) $selectedScores[$item['id']] = $item['score'];

    $selection = [
        'transport_id' => (int)$bestTransport['id'],
        'transport_score' => $bestTransportScore,
        'hotel_id' => (int)$bestHotel['id'],
        'hotel_score' => $bestHotelScore,
        'activity_ids' => $selectedActivityIds,
        'activity_scores' => $selectedScores,
        'interests' => $interests,
        'stay_preference' => $stayPreference,
        'transport_preference' => $transportPreference,
        'recommendation_explanation' => [
            'transport' => 'Matched using your transport preference, budget fit and available seats.',
            'hotel' => 'Matched using your stay preference, rating and estimated nightly budget.',
            'activities' => 'Matched primarily with your selected interests and activity budget.'
        ],
        'system_generated' => true
    ];

    $persist = $pdo->prepare('UPDATE trips SET selected_transport_id = ?, selected_hotel_id = ?, selected_activity_ids = ? WHERE id = ? AND user_id = ?');
    $persist->execute([
        $selection['transport_id'],
        $selection['hotel_id'],
        implode(',', $selection['activity_ids']),
        $tripId,
        $userId
    ]);

    $pdo->commit();
    header("Location: trip-summary.php?trip_id=$tripId");
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    if (isset($tripId) && isset($_SESSION['selection'][$tripId])) unset($_SESSION['selection'][$tripId]);
    flash('error', 'Smart plan could not be generated: ' . $e->getMessage());
    header('Location: ai-planner.php');
    exit;
}
