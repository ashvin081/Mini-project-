-- BuildMyTour Review Feature Fix
-- Run this in phpMyAdmin if your existing buildmytour database was created before the review feature.

ALTER TABLE trips
    ADD COLUMN IF NOT EXISTS rating TINYINT NULL AFTER booking_status,
    ADD COLUMN IF NOT EXISTS review_comment TEXT NULL AFTER rating,
    ADD COLUMN IF NOT EXISTS review_status ENUM('not_reviewed','pending','approved','rejected') NOT NULL DEFAULT 'not_reviewed' AFTER review_comment,
    ADD COLUMN IF NOT EXISTS reviewed_at TIMESTAMP NULL DEFAULT NULL AFTER review_status;

UPDATE trips
SET review_status = 'not_reviewed'
WHERE review_status IS NULL OR review_status = '';

-- Review is allowed only after Admin marks the booking as Completed.
