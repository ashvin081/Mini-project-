<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Review Management';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tripId = (int)($_POST['trip_id'] ?? 0);
    $status = $_POST['review_status'] ?? '';
    $allowed = ['pending','approved','rejected'];
    if ($tripId > 0 && in_array($status, $allowed, true)) {
        $stmt = $pdo->prepare("UPDATE trips SET review_status = ? WHERE id = ? AND rating IS NOT NULL AND review_comment IS NOT NULL");
        $stmt->execute([$status, $tripId]);
        flash('success', 'Review status updated to ' . ucfirst($status) . '.');
    }
    header('Location: reviews.php');
    exit;
}

$reviews = $pdo->query("SELECT t.*, u.name AS user_name, u.email FROM trips t JOIN users u ON t.user_id=u.id WHERE t.rating IS NOT NULL AND TRIM(COALESCE(t.review_comment, '')) <> '' ORDER BY CASE COALESCE(t.review_status, 'pending') WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 WHEN 'rejected' THEN 2 ELSE 3 END, t.reviewed_at DESC, t.created_at DESC")->fetchAll();
$successMsg = flash('success');
include '../includes/admin-header.php';
?>
<div class="admin-page-header">
  <div><h1>Review Management</h1><p>Approve or reject traveler reviews before they are shown publicly.</p></div>
  <div class="admin-page-meta">Engagement</div>
</div>
<?php if ($successMsg): ?><div class="alert alert-success admin-alert"><?php echo e($successMsg); ?></div><?php endif; ?>
<div class="admin-table-card">
  <div class="admin-table-card-head"><h2>Submitted Reviews</h2><span><?php echo count($reviews); ?> total</span></div>
  <div class="admin-table-scroll"><table>
    <tr><th>Traveler</th><th>Trip</th><th>Rating</th><th>Review</th><th>Submitted</th><th>Status</th></tr>
    <?php if (!$reviews): ?><tr><td colspan="6" class="text-center py-4">No reviews submitted yet.</td></tr><?php endif; ?>
    <?php foreach ($reviews as $r): ?>
    <tr>
      <td><?php echo e($r['user_name']); ?><br><small><?php echo e($r['email']); ?></small></td>
      <td><?php echo e($r['destination']); ?><br><small><?php echo e($r['booking_reference'] ?: 'Trip #' . $r['id']); ?></small></td>
      <td><strong><?php echo str_repeat('★', max(0,(int)$r['rating'])); ?></strong><br><small><?php echo (int)$r['rating']; ?>/5</small></td>
      <td style="min-width:240px"><?php echo nl2br(e($r['review_comment'])); ?></td>
      <td><?php echo $r['reviewed_at'] ? date('d M Y', strtotime($r['reviewed_at'])) : '-'; ?></td>
      <td>
        <details class="booking-status-menu status-<?php echo e($r['review_status']); ?>">
          <summary><span class="status-label"><?php echo e(ucfirst($r['review_status'])); ?></span><span class="status-arrow">⌄</span></summary>
          <form method="POST" class="booking-status-options">
            <input type="hidden" name="trip_id" value="<?php echo (int)$r['id']; ?>">
            <button type="submit" name="review_status" value="pending" class="status-option <?php echo $r['review_status']==='pending'?'is-active':''; ?>">Pending</button>
            <button type="submit" name="review_status" value="approved" class="status-option <?php echo $r['review_status']==='approved'?'is-active':''; ?>">Approve</button>
            <button type="submit" name="review_status" value="rejected" class="status-option <?php echo $r['review_status']==='rejected'?'is-active':''; ?>">Reject</button>
          </form>
        </details>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include '../includes/admin-footer.php'; ?>
