<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Smart Trip Planner';

$destinations = $pdo->query("SELECT id, name, state FROM destinations WHERE status = 'active' ORDER BY name ASC")->fetchAll();
include 'includes/header.php';
?>

<section class="smart-planner-hero">
    <div class="container">
        <span class="smart-planner-eyebrow">✦ PREFERENCE-BASED SMART RECOMMENDATION</span>
        <h1>Plan Smarter. <span>Travel Better.</span></h1>
        <p>BuildMyTour matches your destination, budget, duration, interests, stay preference and transport preference with real data from the system.</p>
    </div>
</section>

<div class="container smart-planner-page py-4 py-md-5">
    <form id="plannerForm" method="POST" action="generate-trip.php">

        <section class="smart-planner-card card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5">
                <div class="smart-section-heading">
                    <div class="smart-step-icon">1</div>
                    <div><span>STEP 1</span><h2>Trip Details</h2><p>Choose where you want to go and basic trip information.</p></div>
                </div>

                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label">Destination</label>
                        <select name="destination_id" class="form-select" required>
                            <option value="">Select Destination</option>
                            <?php foreach ($destinations as $destination): ?>
                                <option value="<?php echo (int)$destination['id']; ?>"><?php echo e($destination['name'] . ', ' . $destination['state']); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Trip Start Date</label>
                        <input type="date" name="start_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" required>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label">Trip Duration</label>
                        <select name="trip_days" class="form-select" required>
                            <?php for ($day = 1; $day <= 10; $day++): ?>
                                <option value="<?php echo $day; ?>" <?php echo $day === 3 ? 'selected' : ''; ?>><?php echo $day; ?> Day<?php echo $day > 1 ? 's' : ''; ?></option>
                            <?php endfor; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Number of Travelers</label>
                        <input type="number" name="travelers" class="form-control" min="1" max="20" value="2" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label">Total Budget (₹)</label>
                        <input type="number" name="budget" class="form-control" min="1000" step="500" placeholder="Example: 20000" value="20000" required>
                    </div>
                </div>
            </div>
        </section>

        <section class="smart-planner-card card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5">
                <div class="smart-section-heading">
                    <div class="smart-step-icon">2</div>
                    <div><span>STEP 2</span><h2>Your Travel Interests</h2><p>Select up to 4 interests. Activities are ranked using these preferences.</p></div>
                </div>
                <div class="smart-interest-grid" id="interestOptions">
                    <?php foreach (['Historical','Nature','Adventure','Culture','Food','Shopping'] as $interest): ?>
                        <label class="smart-interest-option">
                            <input type="checkbox" name="interests[]" value="<?php echo e($interest); ?>">
                            <span><?php echo e($interest); ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
                <small class="text-muted d-block mt-3">Choose at least 1 and maximum 4 interests.</small>
            </div>
        </section>

        <section class="smart-planner-card card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5">
                <div class="smart-section-heading">
                    <div class="smart-step-icon">3</div>
                    <div><span>STEP 3</span><h2>Stay Preference</h2><p>The system recommends the best hotel according to your preference and budget.</p></div>
                </div>
                <div class="smart-choice-grid">
                    <?php foreach (['Budget','Standard','Premium'] as $stay): ?>
                        <label class="smart-choice <?php echo $stay === 'Standard' ? 'is-selected' : ''; ?>">
                            <input type="radio" name="stay_preference" value="<?php echo $stay; ?>" <?php echo $stay === 'Standard' ? 'checked' : ''; ?>>
                            <span class="smart-choice-title"><?php echo $stay; ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <section class="smart-planner-card card border-0 shadow-sm mb-4">
            <div class="card-body p-4 p-md-5">
                <div class="smart-section-heading">
                    <div class="smart-step-icon">4</div>
                    <div><span>STEP 4</span><h2>Transport Preference</h2><p>Select a preferred mode or let the system choose the best available option.</p></div>
                </div>
                <div class="smart-choice-grid">
                    <?php foreach (['Any','Bus','Train','Flight'] as $mode): ?>
                        <label class="smart-choice <?php echo $mode === 'Any' ? 'is-selected' : ''; ?>">
                            <input type="radio" name="transport_preference" value="<?php echo $mode; ?>" <?php echo $mode === 'Any' ? 'checked' : ''; ?>>
                            <span class="smart-choice-title"><?php echo $mode; ?></span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>

        <div class="smart-planner-submit text-center">
            <button type="submit" class="btn btn-primary btn-lg px-5">✦ Generate Smart Plan →</button>
            <p>Recommendation = destination match + budget fit + interests + stay preference + transport availability.</p>
        </div>
    </form>
</div>

<script>
document.querySelectorAll('#interestOptions input[type="checkbox"]').forEach(function (input) {
    input.addEventListener('change', function () {
        const checked = document.querySelectorAll('#interestOptions input[type="checkbox"]:checked');
        if (checked.length > 4) { this.checked = false; alert('You can select a maximum of 4 interests.'); }
    });
});

document.querySelectorAll('.smart-choice input[type="radio"]').forEach(function (input) {
    input.addEventListener('change', function () {
        const group = this.closest('.smart-choice-grid');
        group.querySelectorAll('.smart-choice').forEach(function (item) { item.classList.remove('is-selected'); });
        this.closest('.smart-choice').classList.add('is-selected');
    });
});
</script>

<?php include 'includes/footer.php'; ?>
