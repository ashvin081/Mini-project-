<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

$pageTitle = 'My Bookings';
$userId = (int) currentUserId();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';
    $tripId = (int) ($_POST['trip_id'] ?? 0);

    if ($action === 'cancel') {
        $stmt = $pdo->prepare("UPDATE trips SET booking_status='cancelled', status='planned' WHERE id=? AND user_id=? AND booking_status='pending'");
        $stmt->execute([$tripId, $userId]);
        flash('success', 'Booking cancelled successfully.');
    }

    if ($action === 'review') {
        $rating = (int) ($_POST['rating'] ?? 0);
        $comment = trim($_POST['review_comment'] ?? '');
        if ($rating < 1 || $rating > 5 || $comment === '') {
            flash('error', 'Please select a rating and write your review.');
        } else {
            $stmt = $pdo->prepare("UPDATE trips SET rating=?, review_comment=?, review_status='pending', reviewed_at=NOW() WHERE id=? AND user_id=? AND booking_status='completed' AND COALESCE(review_status, 'not_reviewed') IN ('not_reviewed', 'rejected')");
            $stmt->execute([$rating, $comment, $tripId, $userId]);
            flash('success', $stmt->rowCount() ? 'Review submitted for admin approval.' : 'This review is no longer available to submit.');
        }
    }

    header('Location: my-bookings.php');
    exit;
}

$stmt = $pdo->prepare("SELECT *, COALESCE(review_status, 'not_reviewed') AS current_review_status FROM trips WHERE user_id=? AND booking_status!='not_booked' ORDER BY created_at DESC");
$stmt->execute([$userId]);
$bookings = $stmt->fetchAll();
$successMsg = flash('success');
$errorMsg = flash('error');
include 'includes/header.php';
?>
<div class="container">
    <div class="page-header">
        <h1>My Bookings</h1>
        <p>View your trip bookings, booking status and completed-trip reviews.</p>
    </div>

    <?php if ($successMsg): ?><div class="alert alert-success"><?php echo e($successMsg); ?></div><?php endif; ?>
    <?php if ($errorMsg): ?><div class="alert alert-danger"><?php echo e($errorMsg); ?></div><?php endif; ?>

    <?php if (empty($bookings)): ?>
        <div class="empty-state"><p>You don't have any bookings yet.</p><a href="ai-planner.php" class="btn btn-primary">Plan a Trip</a></div>
    <?php else: ?>
        <div class="booking-list">
        <?php foreach ($bookings as $b): ?>
            <div class="booking-card">
                <h3><?php echo e($b['destination']); ?></h3>
                <p><?php echo date('d M Y', strtotime($b['start_date'])); ?> – <?php echo date('d M Y', strtotime($b['end_date'])); ?></p>
                <p>Reference: <strong><?php echo e($b['booking_reference']); ?></strong></p>
                <p>Status: <span class="status-<?php echo e($b['booking_status']); ?>"><?php echo e(ucfirst($b['booking_status'])); ?></span></p>
                <p>Total: <?php echo formatMoney($b['total_amount']); ?></p>
                <a class="btn btn-secondary" href="booking-details.php?trip_id=<?php echo (int) $b['id']; ?>">View Details</a>

                <?php if ($b['booking_status'] === 'pending'): ?>
                    <form method="POST" class="d-inline">
                        <input type="hidden" name="trip_id" value="<?php echo (int) $b['id']; ?>">
                        <button class="btn btn-outline-danger" name="action" value="cancel">Cancel</button>
                    </form>
                <?php endif; ?>

                <?php if ($b['booking_status'] === 'completed' && $b['current_review_status'] === 'not_reviewed'): ?>
                    <hr>
                    <h4 class="h6">Rate Your Trip</h4>
                    <form method="POST">
                        <input type="hidden" name="action" value="review">
                        <input type="hidden" name="trip_id" value="<?php echo (int) $b['id']; ?>">
                        <div class="mb-2">
                            <select name="rating" class="form-select" required>
                                <option value="">Select rating</option>
                                <option value="5">★★★★★ Excellent</option>
                                <option value="4">★★★★ Very Good</option>
                                <option value="3">★★★ Good</option>
                                <option value="2">★★ Fair</option>
                                <option value="1">★ Poor</option>
                            </select>
                        </div>
                        <textarea name="review_comment" class="form-control mb-2" rows="3" maxlength="1000" placeholder="Write your travel experience..." required></textarea>
                        <button class="btn btn-primary btn-sm" type="submit">Submit Review</button>
                    </form>
                <?php elseif ($b['current_review_status'] === 'pending'): ?>
                    <p class="mt-3 mb-0"><strong>Your Review:</strong> Submitted and waiting for admin approval.</p>
                <?php elseif ($b['current_review_status'] === 'approved'): ?>
                    <p class="mt-3 mb-0"><strong>Your Review:</strong> Approved. Thank you for your feedback!</p>
                <?php endif; ?>
            </div>
        <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>
<?php include 'includes/footer.php'; ?>
