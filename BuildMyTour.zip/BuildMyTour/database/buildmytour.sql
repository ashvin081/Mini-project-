CREATE DATABASE IF NOT EXISTS buildmytour CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE buildmytour;

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS trips;
DROP TABLE IF EXISTS tour_packages;
DROP TABLE IF EXISTS destinations;
DROP TABLE IF EXISTS trip_categories;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS admins;
SET FOREIGN_KEY_CHECKS=1;

CREATE TABLE admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE trip_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    description VARCHAR(255) DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE destinations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    state VARCHAR(120) DEFAULT NULL,
    description TEXT,
    image VARCHAR(255) DEFAULT NULL,
    category VARCHAR(80) DEFAULT NULL,
    distance_info VARCHAR(120) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    UNIQUE KEY uq_destination (name, state)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE tour_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT NOT NULL,
    name VARCHAR(180) NOT NULL UNIQUE,
    description TEXT,
    duration VARCHAR(60) DEFAULT NULL,
    days INT NOT NULL DEFAULT 1,
    route VARCHAR(500) DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    offer_percentage DECIMAL(5,2) NOT NULL DEFAULT 0,
    offer_start_date DATE DEFAULT NULL,
    offer_end_date DATE DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES trip_categories(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    start_location VARCHAR(150) DEFAULT 'Package Planner',
    destination VARCHAR(180) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT NOT NULL DEFAULT 1,
    travelers INT NOT NULL DEFAULT 1,
    budget DECIMAL(10,2) NOT NULL DEFAULT 0,
    travel_with VARCHAR(50) DEFAULT NULL,
    interests VARCHAR(255) DEFAULT NULL,
    customization_json LONGTEXT DEFAULT NULL,
    selected_transport_id INT DEFAULT NULL,
    selected_hotel_id INT DEFAULT NULL,
    selected_activity_ids VARCHAR(255) DEFAULT NULL,
    booking_reference VARCHAR(50) DEFAULT NULL UNIQUE,
    total_amount DECIMAL(10,2) DEFAULT NULL,
    payment_method ENUM('UPI','Card','Net Banking') DEFAULT NULL,
    transaction_id VARCHAR(100) DEFAULT NULL,
    payment_status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
    booking_status ENUM('not_booked','pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'not_booked',
    status ENUM('planned','booked','completed','cancelled') NOT NULL DEFAULT 'planned',
    estimated_cost DECIMAL(10,2) DEFAULT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES tour_packages(id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trip_id INT NOT NULL,
    user_id INT NOT NULL,
    booking_reference VARCHAR(50) NOT NULL UNIQUE,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,
    booking_status ENUM('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
    payment_method ENUM('UPI','Card','Net Banking') DEFAULT NULL,
    payment_status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
    payment_reference VARCHAR(100) DEFAULT NULL,
    FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trip_id INT NOT NULL,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    rating TINYINT NOT NULL,
    comment TEXT,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES tour_packages(id) ON DELETE CASCADE,
    UNIQUE KEY uq_trip_review (trip_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Demo admin: admin@buildmytour.com / admin123
INSERT INTO admins (name,email,password,status) VALUES
('Admin','admin@buildmytour.com','$2y$12$03m3wAMfw2dorevPiyy4gOFXGOE0r218QE6GQVe2HrfH7UkEQDxG6','active');

INSERT INTO trip_categories (name,description,image,status) VALUES
('Explore & Adventure','Explore nature, wildlife and thrilling adventures','assets/images/trip-types/adventure-nature.jpg','active'),
('Culture & Heritage','Discover India''s culture, history and iconic destinations','assets/images/trip-types/culture-heritage.jpg','active'),
('Temple Tours','Discover sacred temples, ancient traditions and meaningful journeys','assets/images/trip-types/adventure-spiritual.jpg','active');

INSERT INTO destinations (name,state,description,image,category,distance_info,status) VALUES
('Leh','Ladakh','High-altitude Himalayan capital and gateway to Ladakh.','assets/images/destinations/leh.jpg','Adventure','Package route destination','active'),
('Nubra Valley','Ladakh','Scenic valley with mountains and desert landscapes.','assets/images/destinations/nubra-valley.jpg','Adventure','Package route destination','active'),
('Pangong Lake','Ladakh','Famous high-altitude lake with dramatic mountain views.','assets/images/destinations/leh.jpg','Nature','Package route destination','active'),
('Jaipur','Rajasthan','Pink City known for forts and royal heritage.','assets/images/destinations/jaipur.jpg','Heritage','Package route destination','active'),
('Udaipur','Rajasthan','City of Lakes with palaces and scenic views.','assets/images/destinations/udaipur.jpg','Heritage','Package route destination','active'),
('Jaisalmer','Rajasthan','Golden desert city with forts and dunes.','assets/images/destinations/jaipur.jpg','Culture','Package route destination','active'),
('Ujjain','Madhya Pradesh','Ancient city known for Mahakaleshwar Temple.','assets/images/destinations/dwarka.jpg','Temple','Package route destination','active'),
('Omkareshwar','Madhya Pradesh','Sacred island town and Jyotirlinga destination.','assets/images/destinations/dwarka.jpg','Temple','Package route destination','active'),
('Gir','Gujarat','Wildlife destination famous for Asiatic lions.','assets/images/destinations/ahmedabad.jpg','Wildlife','Package route destination','active'),
('Bhuj','Gujarat','Cultural gateway to Kutch.','assets/images/destinations/ahmedabad.jpg','Culture','Package route destination','active'),
('Dhordo','Gujarat','Gateway village to the White Rann.','assets/images/destinations/ahmedabad.jpg','Culture','Package route destination','active'),
('White Rann','Gujarat','Unique white salt desert landscape.','assets/images/destinations/ahmedabad.jpg','Nature','Package route destination','active'),
('Rishikesh','Uttarakhand','Adventure and spiritual destination on the Ganga.','assets/images/destinations/srinagar.jpg','Temple','Package route destination','active');

INSERT INTO tour_packages (category_id,name,description,duration,days,route,price,image,offer_percentage,status) VALUES
(1,'Leh–Ladakh Adventure Expedition','Leh, Nubra Valley and Pangong Lake adventure journey.','7 Days / 6 Nights',7,'Leh → Nubra Valley → Pangong Lake',52000,'assets/images/packages/leh-ladakh.jpg',10,'active'),
(2,'Rajasthan Royal Heritage Journey','Jaipur, Udaipur and Jaisalmer royal heritage journey.','7 Days / 6 Nights',7,'Jaipur → Udaipur → Jaisalmer',38000,'assets/images/packages/rajasthan-royal.jpg',15,'active'),
(3,'Ujjain–Omkareshwar Temple Tour','Sacred temple journey across Ujjain and Omkareshwar.','4 Days / 3 Nights',4,'Ujjain → Omkareshwar',12000,'assets/images/packages/ujjain-omkareshwar.jpg',5,'active'),
(1,'Gir Wildlife Safari Adventure','Wildlife and safari experience in Gir.','3 Days / 2 Nights',3,'Gir',15000,'assets/images/packages/gir-wildlife.jpg',10,'active'),
(2,'Kutch White Desert & Cultural Escape','White Rann, Dhordo and Kutch culture.','4 Days / 3 Nights',4,'Bhuj → Dhordo → White Rann',18000,'assets/images/packages/kutch-white-desert.jpg',12,'active'),
(3,'Rishikesh Adventure & Spiritual Escape','River adventure, temples and peaceful Ganga experiences.','4 Days / 3 Nights',4,'Rishikesh',14000,'assets/images/packages/rishikesh-adventure.jpg',8,'active');

-- No package variants/recommendation tables. Transport, hotel and activity options are application-level choices.
