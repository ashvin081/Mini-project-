# BuildMyTour

Smart Travel Planning and Booking System — college mini project.

## Final Smart Trip Planner Flow
Trip Type → Tour Package → Trip Details → Customize → Trip Summary → Checkout → Demo Payment → Booking → Review.

## Database — exactly 8 tables
1. admins
2. users
3. trip_categories
4. destinations
5. tour_packages
6. trips
7. bookings
8. reviews

There is no package-variant/recommendation table. Every tour package has one base price and optional offer. Transport, hotel and activity choices are application-level customization options so the database stays compact.

## Tour Packages
- Leh–Ladakh Adventure Expedition
- Rajasthan Royal Heritage Journey
- Ujjain–Omkareshwar Temple Tour
- Gir Wildlife Safari Adventure
- Kutch White Desert & Cultural Escape
- Rishikesh Adventure & Spiritual Escape

## Customization
- 2 transport options per package (12 total)
- 2 hotel options per package (12 total)
- Optional activities
- Local replaceable images
- Live price summary and budget check

## Admin
Separate `admins` table with admin login. Admin manages trip types, destinations, tour packages/offers, bookings and reviews.

Demo admin: `admin@buildmytour.com` / `admin123`

## Fresh database reset
Import `database/buildmytour.sql`. It creates/uses `buildmytour`, drops the old project tables, and creates the clean 8-table schema with fresh demo data.
