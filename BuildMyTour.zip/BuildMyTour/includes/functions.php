<?php
/** Shared helpers for BuildMyTour. */
function e($str){ return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8'); }
function flash($key,$message=null){
    if($message!==null){ $_SESSION['flash'][$key]=$message; return null; }
    if(!empty($_SESSION['flash'][$key])){ $m=$_SESSION['flash'][$key]; unset($_SESSION['flash'][$key]); return $m; }
    return null;
}
function formatMoney($amount){ return '₹'.number_format((float)$amount,0); }
function packageOfferActive(array $package){
    $pct=(float)($package['offer_percentage']??0); if($pct<=0)return false;
    $today=date('Y-m-d');
    if(!empty($package['offer_start_date']) && $package['offer_start_date']>$today)return false;
    if(!empty($package['offer_end_date']) && $package['offer_end_date']<$today)return false;
    return true;
}
function packageOfferPrice(array $package){
    $price=(float)($package['price']??0);
    return packageOfferActive($package) ? round($price*(1-(float)$package['offer_percentage']/100),2) : $price;
}
function packageOfferLabel(array $package){
    return packageOfferActive($package) ? rtrim(rtrim(number_format((float)$package['offer_percentage'],2),'0'),'.').'% OFF' : '';
}
function getPackageReviews(PDO $pdo,$packageName){
    $s=$pdo->prepare("SELECT r.rating,r.comment AS review_comment,r.created_at FROM reviews r JOIN tour_packages p ON p.id=r.package_id WHERE p.name=? AND r.status='approved' AND TRIM(COALESCE(r.comment,''))<>'' ORDER BY r.created_at DESC LIMIT 6");
    $s->execute([$packageName]); return $s->fetchAll();
}
function getPackageReviewStats(PDO $pdo,$packageNames=[]){
    if(!$packageNames)return [];
    $ph=implode(',',array_fill(0,count($packageNames),'?'));
    $s=$pdo->prepare("SELECT p.name AS destination,COUNT(r.id) AS review_count,ROUND(AVG(r.rating),1) AS avg_rating FROM reviews r JOIN tour_packages p ON p.id=r.package_id WHERE p.name IN ($ph) AND r.status='approved' GROUP BY p.id,p.name");
    $s->execute(array_values($packageNames)); $out=[]; foreach($s->fetchAll() as $r)$out[$r['destination']]=$r; return $out;
}
function getTourPackages(PDO $pdo,$onlyActive=true){
    $where=$onlyActive?"WHERE p.status='active' AND (c.status='active' OR c.status IS NULL)":'';
    $rows=$pdo->query("SELECT p.*,c.name AS category FROM tour_packages p LEFT JOIN trip_categories c ON c.id=p.category_id $where ORDER BY p.id ASC")->fetchAll();
    $out=[];
    foreach($rows as $r){
        $r['id']=(int)$r['id']; $r['days']=(int)($r['days']?:1); $r['price']=(float)$r['price'];
        $r['cities']=array_values(array_filter(array_map('trim',preg_split('/\s*→\s*/u',trim((string)$r['route'])))));
        $r['offer_active']=packageOfferActive($r); $out[$r['name']]=$r;
    }
    return $out;
}
function getTripCategories(PDO $pdo,$onlyActive=true){
    $rows=$pdo->query("SELECT * FROM trip_categories ".($onlyActive?"WHERE status='active' ":'')."ORDER BY id ASC")->fetchAll();
    $out=[]; foreach($rows as $r)$out[$r['name']]=['id'=>(int)$r['id'],'description'=>$r['description']?:'','image'=>$r['image']?:'assets/images/placeholder.jpg','status'=>$r['status']]; return $out;
}
function getTourPackage(PDO $pdo,$nameOrId){
    $packages=getTourPackages($pdo,true);
    if(is_numeric($nameOrId)){ foreach($packages as $p)if((int)$p['id']===(int)$nameOrId)return $p; return null; }
    return $packages[$nameOrId]??null;
}
function getTourPackageById(PDO $pdo,int $id){ return getTourPackage($pdo,$id); }
function normalizeInterests($interests){
    if(is_array($interests))return array_values(array_unique(array_filter(array_map('trim',$interests))));
    return array_values(array_unique(array_filter(array_map('trim',explode(',',(string)$interests)))));
}
function getCustomizationOptions(array $cities=[]){
    $destination=$cities[0]??'Your Destination'; $key=strtolower(trim($destination));
    $transportMap=[
      'leh'=>[['id'=>1,'type'=>'Train/Coach','provider'=>'Ladakh Express Coach','from_location'=>'Your City','to_location'=>'Leh','price'=>2200,'image'=>'assets/images/transport/ladakh-express-coach.png'],['id'=>2,'type'=>'Private Cab','provider'=>'Ladakh Private Cab','from_location'=>'Leh','to_location'=>'Ladakh Route','price'=>3200,'image'=>'assets/images/transport/ladakh-private-cab.png']],
      'jaipur'=>[['id'=>3,'type'=>'Train','provider'=>'Rajasthan Express Train','from_location'=>'Your City','to_location'=>'Jaipur','price'=>1800,'image'=>'assets/images/transport/rajasthan-express-train.png'],['id'=>4,'type'=>'Private Cab','provider'=>'Rajasthan Private Cab','from_location'=>'Jaipur','to_location'=>'Rajasthan Route','price'=>2800,'image'=>'assets/images/transport/rajasthan-private-cab.png']],
      'ujjain'=>[['id'=>5,'type'=>'Train','provider'=>'Ujjain Express Train','from_location'=>'Your City','to_location'=>'Ujjain','price'=>1500,'image'=>'assets/images/transport/ujjain-express-train.png'],['id'=>6,'type'=>'Private Cab','provider'=>'Ujjain Private Cab','from_location'=>'Ujjain','to_location'=>'Omkareshwar','price'=>2400,'image'=>'assets/images/transport/ujjain-private-cab.png']],
      'gir'=>[['id'=>7,'type'=>'Train','provider'=>'Gir Express Train','from_location'=>'Your City','to_location'=>'Gir','price'=>2200,'image'=>'assets/images/transport/gir-express-train.png'],['id'=>8,'type'=>'Private Cab','provider'=>'Gir Safari Cab','from_location'=>'Gir','to_location'=>'Sasan Gir','price'=>3800,'image'=>'assets/images/transport/gir-safari-cab.png']],
      'bhuj'=>[['id'=>9,'type'=>'Train','provider'=>'Kutch Express Train','from_location'=>'Your City','to_location'=>'Bhuj','price'=>1900,'image'=>'assets/images/transport/kutch-express-train.png'],['id'=>10,'type'=>'Private Cab','provider'=>'Kutch Private Cab','from_location'=>'Bhuj','to_location'=>'White Rann','price'=>3000,'image'=>'assets/images/transport/kutch-private-cab.png']],
      'rishikesh'=>[['id'=>11,'type'=>'Train','provider'=>'Rishikesh Express Train','from_location'=>'Your City','to_location'=>'Rishikesh','price'=>1700,'image'=>'assets/images/transport/rishikesh-express-train.png'],['id'=>12,'type'=>'Private Cab','provider'=>'Rishikesh Private Cab','from_location'=>'Rishikesh','to_location'=>'Ganga Route','price'=>2200,'image'=>'assets/images/transport/rishikesh-private-cab.png']]
    ];
    $transport=$transportMap[$key]??[['id'=>101,'type'=>'Train','provider'=>$destination.' Express Train','from_location'=>'Your City','to_location'=>$destination,'price'=>1200,'image'=>'assets/images/transport/train.png'],['id'=>102,'type'=>'Private Cab','provider'=>$destination.' Private Cab','from_location'=>$destination,'to_location'=>$destination.' Route','price'=>2200,'image'=>'assets/images/transport/bus.png']];
    $hotelMap=[
      'leh'=>[['id'=>1,'dest_name'=>'Leh','name'=>'Ladakh Mountain View Hotel','rating'=>4.2,'room_type'=>'Deluxe Room','price_per_night'=>2800,'image'=>'assets/images/hotels/ladakh-mountain-view-hotel.jpg'],['id'=>2,'dest_name'=>'Leh','name'=>'Leh Himalayan Grand Hotel','rating'=>4.7,'room_type'=>'Premium Room','price_per_night'=>4200,'image'=>'assets/images/hotels/leh-himalayan-grand-hotel.webp']],
      'jaipur'=>[['id'=>3,'dest_name'=>'Jaipur','name'=>'Jaipur Heritage Palace Hotel','rating'=>4.3,'room_type'=>'Heritage Room','price_per_night'=>2600,'image'=>'assets/images/hotels/jaipur-heritage-palace-hotel.jpg'],['id'=>4,'dest_name'=>'Jaipur','name'=>'Rajputana Royal Residency Hotel','rating'=>4.7,'room_type'=>'Royal Deluxe Room','price_per_night'=>3900,'image'=>'assets/images/hotels/rajputana-royal-residency-hotel.jpg']],
      'ujjain'=>[['id'=>5,'dest_name'=>'Ujjain','name'=>'Ujjain Sacred Stay Hotel','rating'=>4.2,'room_type'=>'Comfort Room','price_per_night'=>1800,'image'=>'assets/images/hotels/ujjain-sacred-stay-hotel.jpg'],['id'=>6,'dest_name'=>'Ujjain','name'=>'Mahakal Heritage Hotel','rating'=>4.6,'room_type'=>'Deluxe Room','price_per_night'=>2800,'image'=>'assets/images/hotels/mahakal-heritage-hotel.webp']],
      'gir'=>[['id'=>7,'dest_name'=>'Gir','name'=>'Gir Forest View Hotel','rating'=>4.2,'room_type'=>'Forest View Room','price_per_night'=>2200,'image'=>'assets/images/hotels/gir-forest-view-hotel.webp'],['id'=>8,'dest_name'=>'Gir','name'=>'Gir Safari Retreat Hotel','rating'=>4.6,'room_type'=>'Safari Deluxe Room','price_per_night'=>3400,'image'=>'assets/images/hotels/gir-safari-retreat-hotel.jpg']],
      'bhuj'=>[['id'=>9,'dest_name'=>'Bhuj','name'=>'Kutch Desert View Hotel','rating'=>4.1,'room_type'=>'Desert View Room','price_per_night'=>2000,'image'=>'assets/images/hotels/kutch-desert-view-hotel.jpg'],['id'=>10,'dest_name'=>'Bhuj','name'=>'Rann Heritage Hotel','rating'=>4.6,'room_type'=>'Heritage Deluxe Room','price_per_night'=>3200,'image'=>'assets/images/hotels/rann-heritage-hotel.webp']],
      'rishikesh'=>[['id'=>11,'dest_name'=>'Rishikesh','name'=>'Ganga Riverside Hotel','rating'=>4.3,'room_type'=>'River View Room','price_per_night'=>2200,'image'=>'assets/images/hotels/ganga-riverside-hotel.jpg'],['id'=>12,'dest_name'=>'Rishikesh','name'=>'Himalayan Adventure Retreat Hotel','rating'=>4.7,'room_type'=>'Premium Valley Room','price_per_night'=>3500,'image'=>'assets/images/hotels/himalayan-adventure-retreat-hotel.avif']]
    ];
    $hotels=$hotelMap[$key]??[['id'=>201,'dest_name'=>$destination,'name'=>$destination.' Comfort Hotel','rating'=>4.0,'room_type'=>'Comfort Room','price_per_night'=>1800,'image'=>'assets/images/hotels/ahmedabad-comfort-inn.jpg'],['id'=>202,'dest_name'=>$destination,'name'=>$destination.' Premium Hotel','rating'=>4.6,'room_type'=>'Deluxe Room','price_per_night'=>3000,'image'=>'assets/images/hotels/jaipur-heritage-stay.jpg']];
    return ['transport'=>$transport,'hotels'=>$hotels,'activities'=>[['id'=>1,'dest_name'=>$destination,'name'=>'Local Sightseeing','description'=>'Guided local highlights and sightseeing.','price'=>500],['id'=>2,'dest_name'=>$destination,'name'=>'Adventure Experience','description'=>'Optional adventure experience for your trip.','price'=>900],['id'=>3,'dest_name'=>$destination,'name'=>'Cultural Experience','description'=>'Discover local culture and traditions.','price'=>700]]];
}
function getTripRoute(array $trip, PDO $pdo=null){
    if($pdo){$package=getTourPackage($pdo,(int)($trip['package_id']??0)); if($package&&!empty($package['cities']))return $package['cities'];}
    $route=(string)($trip['estimated_distance']??''); if(stripos($route,'Package route:')===0){$route=trim(substr($route,14)); return array_values(array_filter(array_map('trim',preg_split('/\s*→\s*/u',$route))));}
    return [];
}
function generateBookingReference(){ return 'BMT'.date('Y').strtoupper(substr(uniqid(),-6)); }
function generateTransactionId(){ return 'TXN'.strtoupper(substr(uniqid(),-10)); }
function getRouteDistance($from,$to){ return ['distance'=>'Approx. 200 km','time'=>'Approx. 4-5 hours']; }
