# BuildMyTour Local Image Setup

Replace the existing local placeholder/demo images with your own files using the same filenames. No PHP or database change is required.

## Trip types
`assets/images/trip-types/`
- adventure-nature.jpg
- culture-heritage.jpg
- adventure-spiritual.jpg

## Tour packages
`assets/images/packages/`
- leh-ladakh.jpg
- rajasthan-royal.jpg
- ujjain-omkareshwar.jpg
- gir-wildlife.jpg
- kutch-white-desert.jpg
- rishikesh-adventure.jpg

## Transport
`assets/images/transport/`
- train.png
- bus.png

Flight is not used in the final customization flow.

## Hotels
`assets/images/hotels/` contains the local hotel images used by the 12 hotel options.

Recommended: JPG or WebP, landscape, around 1200×800 for large cards.
