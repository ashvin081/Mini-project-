<?php
require_once 'includes/auth.php'; require_once 'includes/functions.php'; require_once __DIR__.'/config/database.php'; requireLogin();
if($_SERVER['REQUEST_METHOD']!=='POST'){header('Location: ai-planner.php');exit;}
$userId=(int)currentUserId();
$packageName=trim($_POST['package_name']??''); $category=trim($_POST['category']??'');
$startDate=$_POST['start_date']??''; $travelers=(int)($_POST['travelers']??0);
$travelWith=trim($_POST['travel_with']??''); $interests=normalizeInterests($_POST['interests']??[]);
$package=getTourPackage($pdo,$packageName);
if(!$package || $package['category']!==$category || !$startDate || strtotime($startDate)===false || $startDate<date('Y-m-d') || $travelers<1 || $travelers>20){
    flash('error','Please complete all trip details.'); header('Location: ai-planner.php'); exit;
}
$days=max(1,(int)$package['days']); $endDate=date('Y-m-d',strtotime($startDate.' +'.($days-1).' days'));
$packagePrice=packageOfferPrice($package); $packageTotal=$packagePrice*$travelers;
$originalTotal=(float)$package['price']*$travelers; $discount=max(0,$originalTotal-$packageTotal);
$pdo->beginTransaction();
try{
    $s=$pdo->prepare("INSERT INTO trips (user_id,package_id,start_location,destination,start_date,end_date,days,travelers,budget,travel_with,interests,estimated_cost,status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?, 'planned')");
    $s->execute([$userId,$package['id'],'Package Planner',$packageName,$startDate,$endDate,$days,$travelers,$packageTotal,$travelWith,implode(', ',$interests),$packageTotal]);
    $tripId=(int)$pdo->lastInsertId();
    $options=getCustomizationOptions($package['cities']); $transport=$options['transport'][0]; $hotel=$options['hotels'][0]; $coreActivityIds=array_map('intval',array_column(array_slice($options['activities'],0,1),'id'));
    $_SESSION['selection'][$tripId]=[
      'package_name'=>$packageName,'package_category'=>$category,'package_total'=>$packageTotal,'base_package_total'=>$packageTotal,
      'base_package_original_total'=>$originalTotal,'offer_discount'=>$discount,'offer_percentage'=>(float)$package['offer_percentage'],
      'transport_id'=>(int)$transport['id'],'hotel_id'=>(int)$hotel['id'],'activity_ids'=>$coreActivityIds,'core_activity_ids'=>$coreActivityIds,'extra_activity_ids'=>[],'travel_with'=>$travelWith,'interests'=>$interests,'customized'=>false,'transport_total'=>0,'hotel_total'=>0,'activity_total'=>0,'total_cost'=>$packageTotal
    ];
    $pdo->commit(); header("Location: customize-trip.php?trip_id=$tripId"); exit;
}catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash('error','Trip could not be created.');header('Location: ai-planner.php');exit;}
