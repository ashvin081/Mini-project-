<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
requireLogin();
$pageTitle = 'Contact';

$success = false;
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $message = trim($_POST['message'] ?? '');

    if ($name === '' || $email === '' || $message === '') {
        $errors[] = 'Please fill in all fields.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    } else {
        $success = true;
        $_POST = [];
    }
}

include 'includes/header.php';
?>

<section class="simple-page">
    <div class="container simple-page-inner">
        <div class="simple-page-card contact-card">
            <span class="simple-eyebrow">CONTACT US</span>
            <h1>We'd love to hear from you</h1>
            <p>Have a question or feedback about BuildMyTour? Send us a message.</p>

            <?php if ($success): ?>
                <div class="alert alert-success">Your message has been sent successfully.</div>
            <?php endif; ?>
            <?php foreach ($errors as $err): ?>
                <div class="alert alert-error"><?php echo e($err); ?></div>
            <?php endforeach; ?>

            <form method="POST" action="contact.php" class="simple-contact-form">
                <div class="form-group">
                    <label for="name">Name</label>
                    <input id="name" type="text" name="name" class="form-control" value="<?php echo e($_POST['name'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input id="email" type="email" name="email" class="form-control" value="<?php echo e($_POST['email'] ?? ''); ?>" required>
                </div>
                <div class="form-group">
                    <label for="message">Message</label>
                    <textarea id="message" name="message" class="form-control" rows="5" required><?php echo e($_POST['message'] ?? ''); ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Send Message</button>
            </form>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
