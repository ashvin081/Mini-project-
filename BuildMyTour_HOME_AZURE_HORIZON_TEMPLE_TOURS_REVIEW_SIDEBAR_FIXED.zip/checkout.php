<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Checkout';

$tripId = (int)($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0);
$stmt = $pdo->prepare("SELECT * FROM trips WHERE id = ? AND user_id = ?");
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header("Location: ai-planner.php"); exit; }

$sel = $_SESSION['selection'][$tripId] ?? null;
if (!$sel || empty($sel['total_cost'])) {
    header("Location: trip-summary.php?trip_id=$tripId");
    exit;
}
if ((float)$sel['total_cost'] > (float)$trip['budget']) {
    flash('error', 'Your customized trip is over budget. Please customize it again before booking.');
    header("Location: trip-summary.php?trip_id=$tripId");
    exit;
}

$stmt = $pdo->prepare("SELECT name, email, phone FROM users WHERE id = ?");
$stmt->execute([currentUserId()]);
$user = $stmt->fetch();

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = trim($_POST['traveler_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $agree = isset($_POST['agree']);

    if ($name === '' || $email === '' || $phone === '') {
        $errors[] = "Please fill all required fields.";
    }
    if (!$agree) {
        $errors[] = "You must agree to the booking terms to continue.";
    }

    if (empty($errors)) {
        $_SESSION['checkout'][$tripId] = compact('name', 'email', 'phone');
        header("Location: payment.php?trip_id=$tripId");
        exit;
    }
}

include 'includes/header.php';
?>

<div class="container">
    <div class="page-header">
        <h1>Checkout</h1>
        <p>Confirm your traveler details before payment.</p>
    </div>

    <?php foreach ($errors as $err): ?><div class="alert alert-error"><?php echo e($err); ?></div><?php endforeach; ?>

    <div class="summary-box" style="max-width:600px;">
        <form method="POST" action="checkout.php?trip_id=<?php echo $tripId; ?>">
            <input type="hidden" name="trip_id" value="<?php echo $tripId; ?>">
            <div class="form-group">
                <label>Traveler Name</label>
                <input type="text" name="traveler_name" class="form-control" value="<?php echo e($user['name']); ?>" required>
            </div>
            <div class="form-row">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" class="form-control" value="<?php echo e($user['email']); ?>" required>
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" class="form-control" value="<?php echo e($user['phone']); ?>" required>
                </div>
            </div>
            <div class="form-group">
                <label>Number of Travelers</label>
                <input type="text" class="form-control" value="<?php echo (int)$trip['travelers']; ?>" disabled>
            </div>
            <div class="summary-row total">
                <span>Total Amount</span><span><?php echo formatMoney($sel['total_cost']); ?></span>
            </div>
            <div class="checkbox-row" style="margin:16px 0;">
                <input type="checkbox" name="agree" id="agree" required>
                <label for="agree" style="margin:0;font-weight:400;">I agree to the booking terms.</label>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Proceed to Payment</button>
        </form>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
