<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Customize Your Trip';

$tripId = (int)($_GET['trip_id'] ?? $_POST['trip_id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM trips WHERE id = ? AND user_id = ?');
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header('Location: ai-planner.php'); exit; }

$sel = $_SESSION['selection'][$tripId] ?? [];
$package = getTourPackage($pdo, $sel['package_name'] ?? $trip['destination']);
if (!$package) { header('Location: ai-planner.php'); exit; }
$variant = $sel['package_variant'] ?? 'Recommended';
$optionMeta = getSmartOptionMeta($variant);
$variantLabel = $optionMeta['label'];
$variantData = $package['variants'][$variant] ?? reset($package['variants']);
$travelers = max(1, (int)$trip['travelers']);
$days = max(1, (int)$trip['days']);
$baseTotal = variantOfferPrice($variantData, $package) * $travelers;
$baseOriginalTotal = (float)$variantData['price_per_person'] * $travelers;
$offerDiscount = max(0, $baseOriginalTotal - $baseTotal);

$cities = getTripRoute($trip, $pdo);
$options = getCustomizationOptions($cities);
$hotelList = $options['hotels'];
$activityList = $options['activities'];
$transportList = $options['transport'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $transportId = (int)($_POST['transport_id'] ?? 0);
    $hotelId = (int)($_POST['hotel_id'] ?? 0);
    $activityIds = array_values(array_unique(array_filter(array_map('intval', $_POST['activity_ids'] ?? []))));

    $transport = null;
    foreach ($transportList as $row) if ((int)$row['id'] === $transportId) { $transport = $row; break; }
    $hotel = null;
    foreach ($hotelList as $row) if ((int)$row['id'] === $hotelId) { $hotel = $row; break; }

    if (!$transport || !$hotel) {
        flash('error', 'Please select a valid transport and hotel.');
        header("Location: customize-trip.php?trip_id=$tripId"); exit;
    }

    $validActivityIds = [];
    $activityMap = [];
    foreach ($activityList as $row) {
        $activityMap[(int)$row['id']] = $row;
        if (in_array((int)$row['id'], $activityIds, true)) $validActivityIds[] = (int)$row['id'];
    }
    $activityIds = $validActivityIds;

    // Package price is the selected Smart Saver / Best Balance / Premium Experience base. Custom choices
    // are added transparently so the user can see exactly what changed.
    $transportTotal = (float)$transport['price'] * $travelers;
    $hotelTotal = (float)$hotel['price_per_night'] * max(1, (int)ceil($travelers / 2)) * max(1, $days - 1);
    $activityTotal = 0.0;
    foreach ($activityIds as $id) $activityTotal += (float)$activityMap[$id]['price'] * $travelers;
    $totalCost = $baseTotal + $transportTotal + $hotelTotal + $activityTotal;
    $budget = (float)$trip['budget'];

    $_SESSION['selection'][$tripId]['transport_id'] = $transportId;
    $_SESSION['selection'][$tripId]['hotel_id'] = $hotelId;
    $_SESSION['selection'][$tripId]['activity_ids'] = $activityIds;
    $_SESSION['selection'][$tripId]['base_package_total'] = $baseTotal;
    $_SESSION['selection'][$tripId]['transport_total'] = $transportTotal;
    $_SESSION['selection'][$tripId]['hotel_total'] = $hotelTotal;
    $_SESSION['selection'][$tripId]['activity_total'] = $activityTotal;
    $_SESSION['selection'][$tripId]['total_cost'] = $totalCost;
    $_SESSION['selection'][$tripId]['customized'] = true;
    $_SESSION['selection'][$tripId]['budget_status'] = $totalCost <= $budget ? 'within_budget' : 'over_budget';

    $pdo->prepare('UPDATE trips SET customization_json=?, estimated_cost=? WHERE id=? AND user_id=?')
        ->execute([json_encode(['transport_id'=>$transportId,'hotel_id'=>$hotelId,'activity_ids'=>$activityIds,'transport'=>$transport,'hotel'=>$hotel,'activities'=>array_values(array_filter($activityList, fn($x)=>in_array((int)$x['id'],$activityIds,true)))], JSON_UNESCAPED_UNICODE), $totalCost, $tripId, currentUserId()]);

    header("Location: trip-summary.php?trip_id=$tripId"); exit;
}

$selectedTransportId = (int)($sel['transport_id'] ?? ($transportList[0]['id'] ?? 0));
$selectedHotelId = (int)($sel['hotel_id'] ?? ($hotelList[0]['id'] ?? 0));
$selectedActivityIds = array_map('intval', $sel['activity_ids'] ?? []);


$alternatives = getCheaperAlternatives($transportList, $hotelList, $selectedTransportId, $selectedHotelId, $activityList, $selectedActivityIds, $travelers, $days);
$selectedTransportPrice = 0.0; foreach ($transportList as $tr) { if ((int)$tr['id'] === $selectedTransportId) { $selectedTransportPrice = (float)$tr['price']; break; } }
include 'includes/header.php';
?>
<div class="container py-4 py-md-5">
  <div class="page-header">
    <span class="summary-eyebrow">SMART TRIP PLANNER</span>
    <h1>Customize Your Trip ✨</h1>
    <p>Your package is selected. Make only the changes you want, then review one final summary.</p>
  </div>

  <div class="alert alert-info border-0 shadow-sm mb-4">
    <strong><?php echo e($package['icon'].' '.$sel['package_name']); ?></strong>
    &nbsp;•&nbsp; <?php echo e($variant); ?> &nbsp;•&nbsp; Base package for <?php echo $travelers; ?> traveler(s): <strong><?php if($offerDiscount>0): ?><del class="old-price"><?php echo formatMoney($baseOriginalTotal); ?></del> <?php endif; ?><?php echo formatMoney($baseTotal); ?></strong><?php if($offerDiscount>0): ?> <span class="offer-badge ms-2">🔥 <?php echo (int)$package['offer_percentage']; ?>% OFF</span><?php endif; ?>
    <span class="float-end">Your budget: <strong><?php echo formatMoney($trip['budget']); ?></strong></span>
  </div>

  <form method="POST" action="customize-trip.php?trip_id=<?php echo $tripId; ?>" id="customizeForm">
    <input type="hidden" name="trip_id" value="<?php echo $tripId; ?>">

    <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
      <div class="smart-section-heading"><div class="smart-step-icon">1</div><div><span>TRAVEL</span><h2>Choose transport</h2><p>The selected transport is added transparently to your final amount.</p></div></div>
      <div class="row g-3">
      <?php foreach ($transportList as $t): ?>
        <div class="col-md-6 col-lg-4"><div class="select-card w-100 h-100 <?php echo $selectedTransportId === (int)$t['id'] ? 'selected' : ''; ?>" data-select-card>
          <div class="select-card-body">
            <span class="badge"><?php echo e($t['type']); ?></span>
            <h3><?php echo e($t['provider']); ?></h3>
            <div class="meta"><?php echo e($t['from_location']); ?> → <?php echo e($t['to_location']); ?></div>
            <div class="price">+ <?php echo formatMoney($t['price'] * $travelers); ?> total</div>
            <label><input type="radio" name="transport_id" value="<?php echo (int)$t['id']; ?>" data-price="<?php echo (float)$t['price'] * $travelers; ?>" <?php echo $selectedTransportId === (int)$t['id'] ? 'checked' : ''; ?> required> Select</label>
          </div>
        </div></div>
      <?php endforeach; ?>
      </div>
    </div></section>

    <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
      <div class="smart-section-heading"><div class="smart-step-icon">2</div><div><span>STAY</span><h2>Choose hotel</h2><p>Hotel cost is calculated for the stay duration and shared occupancy.</p></div></div>
      <div class="row g-3">
      <?php foreach ($hotelList as $h): $rooms=max(1,(int)ceil($travelers/2)); $hotelCost=(float)$h['price_per_night']*$rooms*max(1,$days-1); ?>
        <div class="col-md-6 col-lg-4"><div class="select-card w-100 h-100 <?php echo $selectedHotelId === (int)$h['id'] ? 'selected' : ''; ?>" data-select-card>
          <div class="select-card-body">
            <span class="badge"><?php echo e($h['dest_name']); ?></span>
            <h3><?php echo e($h['name']); ?></h3>
            <div class="meta">⭐ <?php echo e($h['rating']); ?> · <?php echo e($h['room_type']); ?></div>
            <div class="price">+ <?php echo formatMoney($hotelCost); ?> total stay</div>
            <label><input type="radio" name="hotel_id" value="<?php echo (int)$h['id']; ?>" data-price="<?php echo $hotelCost; ?>" <?php echo $selectedHotelId === (int)$h['id'] ? 'checked' : ''; ?> required> Select</label>
          </div>
        </div></div>
      <?php endforeach; ?>
      </div>
    </div></section>

    <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
      <div class="smart-section-heading"><div class="smart-step-icon">3</div><div><span>EXPERIENCES</span><h2>Add activities</h2><p>Only activities you select will be added to your trip and final price.</p></div></div>
      <div class="row g-3">
      <?php foreach ($activityList as $a): ?>
        <div class="col-md-6 col-lg-4"><div class="select-card w-100 h-100 <?php echo in_array((int)$a['id'], $selectedActivityIds, true) ? 'selected' : ''; ?>" data-select-card>
          <div class="select-card-body">
            <span class="badge"><?php echo e($a['dest_name']); ?></span>
            <h3><?php echo e($a['name']); ?></h3>
            <div class="meta"><?php echo e($a['description']); ?></div>
            <div class="price"><?php echo $a['price'] > 0 ? '+ '.formatMoney((float)$a['price'] * $travelers).' total' : 'Free'; ?></div>
            <label><input type="checkbox" name="activity_ids[]" value="<?php echo (int)$a['id']; ?>" data-price="<?php echo (float)$a['price'] * $travelers; ?>" <?php echo in_array((int)$a['id'], $selectedActivityIds, true) ? 'checked' : ''; ?>> Add to trip</label>
          </div>
        </div></div>
      <?php endforeach; ?>
      </div>
    </div></section>

    <section id="budgetTips" class="card border-0 shadow-sm mb-4 budget-tips-card">
      <div class="card-body p-4 p-md-5">
        <div class="text-muted small">SMART BUDGET ALTERNATIVE</div>
        <h3 class="mb-2">Need to reduce the trip cost?</h3>
        <p class="text-muted">BuildMyTour can help you stay closer to your budget without changing the destination.</p>
        <div class="row g-3">
          <?php if($alternatives['transport']): ?><div class="col-md-4"><div class="budget-tip"><strong>🚆 Cheaper transport</strong><span><?php echo e($alternatives['transport']['type'].' · '.$alternatives['transport']['provider']); ?></span><small>Save about <?php echo formatMoney(($selectedTransportPrice - (float)$alternatives['transport']['price']) * $travelers); ?></small></div></div><?php endif; ?>
          <?php if($alternatives['hotel']): ?><div class="col-md-4"><div class="budget-tip"><strong>🏨 Cheaper hotel</strong><span><?php echo e($alternatives['hotel']['name']); ?></span><small>Lower nightly rate</small></div></div><?php endif; ?>
          <?php if($alternatives['remove_activity']): ?><div class="col-md-4"><div class="budget-tip"><strong>🎯 Remove one activity</strong><span><?php echo e($alternatives['remove_activity']['name']); ?></span><small>Save about <?php echo formatMoney($alternatives['activity_savings']); ?></small></div></div><?php endif; ?>
        </div>
      </div>
    </section>

    <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
      <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
        <div>
          <div class="text-muted small">LIVE CUSTOMIZED TOTAL</div>
          <h2 id="liveTotal" class="mb-1"><?php echo formatMoney($baseTotal); ?></h2>
          <div id="budgetMessage" class="small text-muted">Select your transport, hotel and optional activities.</div>
        </div>
        <div class="d-flex gap-2">
          <a href="ai-planner.php" class="btn btn-outline-secondary">← Start Over</a>
          <button type="submit" class="btn btn-primary px-4">Save & View Summary →</button>
        </div>
      </div>
    </div></section>
  </form>
</div>
<script>
(function(){
  const base = <?php echo json_encode($baseTotal); ?>;
  const budget = <?php echo json_encode((float)$trip['budget']); ?>;
  const totalEl = document.getElementById('liveTotal');
  const msg = document.getElementById('budgetMessage');
  const money = n => '₹' + Math.round(n).toLocaleString('en-IN');
  function update(){
    let total=base;
    const transport=document.querySelector('input[name="transport_id"]:checked');
    const hotel=document.querySelector('input[name="hotel_id"]:checked');
    if(transport) total += Number(transport.dataset.price||0);
    if(hotel) total += Number(hotel.dataset.price||0);
    document.querySelectorAll('input[name="activity_ids[]"]:checked').forEach(x=>total += Number(x.dataset.price||0));
    totalEl.textContent=money(total);
    if(total <= budget){
      msg.innerHTML = '✅ Within your budget by <strong>' + money(budget-total) + '</strong>.';
      msg.className = 'small text-success';
    } else {
      const gap=total-budget;
      msg.innerHTML = '⚠️ Over your budget by <strong>' + money(gap) + '</strong>. <a href="#budgetTips" class="budget-tip-link">See smart ways to reduce it ↓</a>';
      msg.className = 'small text-danger';
    }
  }
  function syncSelectedCards(){
    document.querySelectorAll('[data-select-card]').forEach(card=>{
      const input = card.querySelector('input[type=radio], input[type=checkbox]');
      card.classList.toggle('selected', !!input && input.checked);
    });
  }
  document.querySelectorAll('[data-select-card]').forEach(card=>{
    card.addEventListener('click', function(e){
      if (e.target.closest('input, label, a, button')) return;
      const input = card.querySelector('input[type=radio], input[type=checkbox]');
      if (!input) return;
      if (input.type === 'radio') {
        input.checked = true;
      } else {
        input.checked = !input.checked;
      }
      input.dispatchEvent(new Event('change', {bubbles:true}));
    });
  });
  document.querySelectorAll('#customizeForm input').forEach(x=>x.addEventListener('change',()=>{ syncSelectedCards(); update(); }));
  syncSelectedCards();
  update();
})();
</script>
<?php include 'includes/footer.php'; ?>
