// BuildMyTour - main.js

document.addEventListener('DOMContentLoaded', function () {
    // Mobile nav toggle
    var toggle = document.getElementById('navToggle');
    var nav = document.getElementById('mainNav');
    if (toggle && nav) {
        toggle.addEventListener('click', function () {
            nav.classList.toggle('open');
        });
    }

    // Interest / chip selection toggle
    document.querySelectorAll('.chip').forEach(function (chip) {
        chip.addEventListener('click', function () {
            var input = chip.querySelector('input');
            if (input && (input.type === 'checkbox' || input.type === 'radio')) {
                if (input.type === 'radio') {
                    document.querySelectorAll('input[name="' + input.name + '"]').forEach(function (r) {
                        r.closest('.chip').classList.remove('selected');
                    });
                }
                input.checked = input.type === 'checkbox' ? !input.checked : true;
                chip.classList.toggle('selected', input.checked);
            }
        });
    });

    // Transport tabs
    document.querySelectorAll('.transport-tab').forEach(function (tab) {
        tab.addEventListener('click', function () {
            document.querySelectorAll('.transport-tab').forEach(function (t) { t.classList.remove('active'); });
            tab.classList.add('active');
            var type = tab.getAttribute('data-type');
            document.querySelectorAll('.transport-option').forEach(function (opt) {
                opt.style.display = (opt.getAttribute('data-type') === type) ? '' : 'none';
            });
        });
    });

    // Payment method selection
    document.querySelectorAll('.payment-method').forEach(function (m) {
        m.addEventListener('click', function () {
            document.querySelectorAll('.payment-method').forEach(function (x) { x.classList.remove('active'); });
            m.classList.add('active');
            var input = m.querySelector('input');
            if (input) input.checked = true;
        });
    });

    // Basic client-side confirm date validation on planner form
    var plannerForm = document.getElementById('plannerForm');
    if (plannerForm) {
        plannerForm.addEventListener('submit', function (e) {
            var start = document.getElementById('start_date');
            var end = document.getElementById('end_date');
            if (start && end && start.value && end.value) {
                if (new Date(end.value) <= new Date(start.value)) {
                    e.preventDefault();
                    alert('End date must be after the start date.');
                }
            }
        });
    }
});
