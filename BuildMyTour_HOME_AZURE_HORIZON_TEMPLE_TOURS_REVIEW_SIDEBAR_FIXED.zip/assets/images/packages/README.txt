Add the 6 package main images here using these exact filenames:

1. leh-ladakh.jpg
2. rajasthan-royal.jpg
3. ujjain-omkareshwar.jpg
4. gir-wildlife.jpg
5. kutch-white-desert.jpg
6. rishikesh-adventure.jpg

Recommended: landscape images, minimum 1200x700 pixels. The Smart Trip Planner will automatically display them when added.
