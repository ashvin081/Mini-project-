Add the 3 Trip Type images here using these exact filenames:

1. adventure-nature.jpg
2. culture-heritage.jpg
3. adventure-spiritual.jpg

Recommended: landscape images, minimum 1200x600 pixels. The cards have a built-in fallback icon until images are added.
