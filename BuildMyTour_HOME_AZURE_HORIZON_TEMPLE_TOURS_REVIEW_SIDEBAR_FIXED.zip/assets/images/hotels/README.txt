Add exactly these 10 hotel images to this folder:
jaipur-heritage-stay.jpg
udaipur-lake-view.jpg
ahmedabad-comfort-inn.jpg
dwarka-sea-view.jpg
srinagar-lake-retreat.jpg
gulmarg-mountain-resort.jpg
kochi-harbour-hotel.jpg
munnar-tea-valley.jpg
leh-mountain-lodge.jpg
nubra-desert-camp.jpg
