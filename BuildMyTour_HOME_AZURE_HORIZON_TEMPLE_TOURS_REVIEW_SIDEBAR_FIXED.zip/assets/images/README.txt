Image files are applied using these database paths:
- destinations/jaipur.jpg through destinations/nubra-valley.jpg
- hotels/jaipur-heritage-stay.jpg through hotels/nubra-desert-camp.jpg
- transport/flight.png, train.png, bus.png
Activity images are not used anywhere in the website.
