Add exactly these 10 destination images to this folder:
jaipur.jpg
udaipur.jpg
ahmedabad.jpg
dwarka.jpg
srinagar.jpg
gulmarg.jpg
kochi.jpg
munnar.jpg
leh.jpg
nubra-valley.jpg
