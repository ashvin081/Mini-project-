</main>

<footer class="site-footer mt-5">
    <div class="container py-4">
        <div class="row align-items-center g-3">
            <div class="col-md-7">
                <a href="home.php" class="footer-logo-link footer-brand-surface d-inline-flex align-items-center mb-3" aria-label="BuildMyTour Home">
                    <img src="assets/images/logo/buildmytour-logo.png" alt="BuildMyTour" class="footer-logo-img">
                </a>
                <p class="footer-tag mb-0">Smart Travel Planning &amp; Booking System</p>
            </div>
            <div class="col-md-5">
                <div class="footer-links d-flex flex-wrap justify-content-md-end gap-3">
                    <a href="about.php">About</a>
                    <a href="contact.php">Contact</a>
                    <a href="my-bookings.php">My Bookings</a>
                </div>
            </div>
        </div>
        <p class="footer-copy text-center mb-0 mt-4 pt-3">&copy; <?php echo date('Y'); ?> BuildMyTour — A College Mini Project</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/main.js"></script>
</body>
</html>
