<?php
// Expects auth.php + functions.php already included by the calling page
$currentPage = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?php echo isset($pageTitle) ? e($pageTitle) . ' - BuildMyTour' : 'BuildMyTour - Plan Smarter. Travel Better.'; ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="assets/css/style.css">
</head>
<body>

<header class="site-header">
    <nav class="navbar navbar-expand-lg py-3">
        <div class="container">
            <a href="home.php" class="navbar-brand logo brand-logo-link" aria-label="BuildMyTour Home">
    <img src="assets/images/logo/buildmytour-logo.png" alt="BuildMyTour - Plan, Explore, Travel Better" class="brand-logo-img">
</a>

            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav mx-auto gap-lg-2">
                    <li class="nav-item"><a href="home.php" class="nav-link <?php echo $currentPage === 'home.php' ? 'active' : ''; ?>">Home</a></li>
                    <li class="nav-item"><a href="ai-planner.php" class="nav-link <?php echo $currentPage === 'ai-planner.php' ? 'active' : ''; ?>">Smart Trip Planner</a></li>
                    <li class="nav-item"><a href="my-bookings.php" class="nav-link <?php echo $currentPage === 'my-bookings.php' ? 'active' : ''; ?>">My Bookings</a></li>
                    <li class="nav-item"><a href="about.php" class="nav-link <?php echo $currentPage === 'about.php' ? 'active' : ''; ?>">About</a></li>
                    <li class="nav-item"><a href="contact.php" class="nav-link <?php echo $currentPage === 'contact.php' ? 'active' : ''; ?>">Contact</a></li>
                </ul>
                <div class="account-actions pt-3 pt-lg-0">
                    <div class="user-chip" title="Signed in user">
                        <span class="user-avatar" aria-hidden="true"><?php echo strtoupper(substr(currentUserName(), 0, 1)); ?></span>
                        <span class="user-name"><?php echo e(currentUserName()); ?></span>
                    </div>
                    <a href="logout.php" class="btn-logout" aria-label="Logout">
                        <span aria-hidden="true">↪</span>
                        <span>Logout</span>
                    </a>
                </div>
            </div>
        </div>
    </nav>
</header>

<main class="site-main">
