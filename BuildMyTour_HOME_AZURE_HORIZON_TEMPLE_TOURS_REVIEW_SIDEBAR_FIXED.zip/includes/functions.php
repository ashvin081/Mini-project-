<?php

function getSmartOptionMeta(string $key): array {
    $map = [
        'Budget' => ['key'=>'Budget','label'=>'Smart Saver','tag'=>'💰','description'=>'Save more, explore more'],
        'Recommended' => ['key'=>'Recommended','label'=>'Best Balance','tag'=>'⚖️','description'=>'Great comfort at the right price'],
        'Premium' => ['key'=>'Premium','label'=>'Premium Experience','tag'=>'👑','description'=>'Enhanced comfort and exclusive experiences'],
    ];
    return $map[$key] ?? $map['Recommended'];
}

/**
 * Shared helper functions
 * BuildMyTour - College Mini Project
 */

function e($str) {
    return htmlspecialchars($str ?? '', ENT_QUOTES, 'UTF-8');
}

function flash($key, $message = null) {
    if ($message !== null) {
        $_SESSION['flash'][$key] = $message;
        return;
    }
    if (!empty($_SESSION['flash'][$key])) {
        $msg = $_SESSION['flash'][$key];
        unset($_SESSION['flash'][$key]);
        return $msg;
    }
    return null;
}

function formatMoney($amount) {
    return '₹' . number_format((float)$amount, 0);
}


function packageOfferActive(array $package) {
    $percent = (float)($package['offer_percentage'] ?? 0);
    if ($percent <= 0) return false;
    $today = date('Y-m-d');
    if (!empty($package['offer_start_date']) && $package['offer_start_date'] > $today) return false;
    if (!empty($package['offer_end_date']) && $package['offer_end_date'] < $today) return false;
    return true;
}

function packageOfferPrice(array $package) {
    $price = (float)($package['price'] ?? 0);
    if (!packageOfferActive($package)) return $price;
    return round($price * (1 - ((float)$package['offer_percentage'] / 100)), 2);
}

function packageOfferLabel(array $package) {
    return packageOfferActive($package) ? rtrim(rtrim(number_format((float)$package['offer_percentage'], 2), '0'), '.') . '% OFF' : '';
}

function variantOfferPrice(array $variant, array $package) {
    $price = (float)($variant['price_per_person'] ?? 0);
    if (packageOfferActive($package)) {
        return round($price * (1 - ((float)$package['offer_percentage'] / 100)), 2);
    }
    return $price;
}

function variantOfferLabel(array $package) {
    $percent = (float)($package['offer_percentage'] ?? 0);
    return $percent > 0 ? rtrim(rtrim(number_format($percent, 2), '0'), '.') . '% OFF' : '';
}

function getPackageReviews(PDO $pdo, $packageName) {
    $stmt = $pdo->prepare("SELECT r.rating, r.comment AS review_comment, r.created_at FROM reviews r JOIN tour_packages p ON p.id=r.package_id WHERE p.name=? AND r.status='approved' AND TRIM(COALESCE(r.comment,''))<>'' ORDER BY r.created_at DESC LIMIT 6");
    $stmt->execute([$packageName]);
    return $stmt->fetchAll();
}

function getPackageReviewStats(PDO $pdo, $packageNames = []) {
    if (!$packageNames) return [];
    $ph = implode(',', array_fill(0, count($packageNames), '?'));
    $sql = "SELECT p.name AS destination, COUNT(r.id) AS review_count, ROUND(AVG(r.rating),1) AS avg_rating FROM reviews r JOIN tour_packages p ON p.id=r.package_id WHERE p.name IN ($ph) AND r.status='approved' AND r.rating IS NOT NULL GROUP BY p.id, p.name";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(array_values($packageNames));
    $out=[]; foreach($stmt->fetchAll() as $row){$out[$row['destination']]=$row;} return $out;
}

function getTourPackages(PDO $pdo, $onlyActive = true) {
    $where = $onlyActive ? "WHERE p.status='active' AND (c.status='active' OR c.status IS NULL)" : "";
    $rows = $pdo->query("SELECT p.*, c.name AS category, c.icon AS category_icon
        FROM tour_packages p
        LEFT JOIN trip_categories c ON c.id=p.category_id
        $where
        ORDER BY p.id ASC")->fetchAll();

    if (!$rows) return [];
    $ids = array_column($rows, 'id');
    $ph = implode(',', array_fill(0, count($ids), '?'));

    $vStmt = $pdo->prepare("SELECT * FROM package_variants WHERE package_id IN ($ph) ".($onlyActive ? "AND status='active' " : "")."ORDER BY FIELD(variant_key,'Budget','Recommended','Premium')");
    $vStmt->execute($ids);
    $variantsByPackage = [];
    foreach ($vStmt->fetchAll() as $v) {
        $variantsByPackage[(int)$v['package_id']][$v['variant_key']] = [
            'id'=>(int)$v['id'],
            'name'=>$v['name'],
            'price_per_person'=>(float)$v['price_per_person'],
            'tag'=>$v['tag'] ?: ($v['variant_key']==='Budget'?'🥉':($v['variant_key']==='Recommended'?'⭐':'👑')),
        ];
    }

    $citiesByPackage = [];
    foreach ($rows as $row) {
        $routeText = trim((string)($row['route'] ?? ''));
        if ($routeText !== '') $citiesByPackage[(int)$row['id']] = array_values(array_filter(array_map('trim', preg_split('/\s*→\s*/u', $routeText))));
    }

    $out=[];
    foreach ($rows as $r) {
        $r['id']=(int)$r['id'];
        $r['days']=(int)($r['days'] ?: 1);
        $r['icon']=$r['icon'] ?: ($r['category_icon'] ?: '✈️');
        $r['cities']=$citiesByPackage[$r['id']] ?? [];
        $r['variants']=$variantsByPackage[$r['id']] ?? [];
        $r['offer_active']=packageOfferActive($r);
        $out[$r['name']]=$r;
    }
    return $out;
}

function getTripCategories(PDO $pdo, $onlyActive = true) {
    $sql="SELECT * FROM trip_categories ".($onlyActive ? "WHERE status='active' " : "")."ORDER BY id ASC";
    $rows=$pdo->query($sql)->fetchAll();
    $out=[];
    foreach($rows as $r) {
        $out[$r['name']] = [
            'id'=>(int)$r['id'],
            'icon'=>$r['icon'] ?: '✈️',
            'description'=>$r['description'] ?: '',
            'image'=>$r['image'] ?: 'assets/images/placeholder.jpg',
            'status'=>$r['status']
        ];
    }
    return $out;
}

function getTourPackage(PDO $pdo, $nameOrId) {
    $packages = getTourPackages($pdo, true);
    if (is_numeric($nameOrId)) {
        foreach($packages as $p) if((int)$p['id']===(int)$nameOrId) return $p;
        return null;
    }
    return $packages[$nameOrId] ?? null;
}

function getTourPackageById(PDO $pdo, int $id) {
    return getTourPackage($pdo, $id);
}


function packageInterestScore(array $package, array $interests) {
    if (!$interests) return 10;
    $text = strtolower(($package['category'] ?? '') . ' ' . ($package['description'] ?? '') . ' ' . implode(' ', $package['cities'] ?? []));
    $map = [
        'Adventure' => ['adventure','mountain','wildlife','safari','rafting','road'],
        'Nature' => ['nature','lake','valley','desert','wildlife','scenic'],
        'Culture' => ['culture','heritage','royal','desert','craft'],
        'Historical' => ['heritage','history','fort','palace','temple','jyotirlinga'],
        'Food' => ['food','cuisine','market'],
        'Shopping' => ['market','craft','shopping'],
    ];
    $score=0;
    foreach($interests as $interest){
        $i=strtolower(trim($interest));
        if (strpos(strtolower($package['category'] ?? ''), $i) !== false) $score += 30;
        foreach($map[$interest] ?? [] as $kw){ if(strpos($text,$kw)!==false){$score+=15;break;} }
    }
    return min(60,$score);
}

function smartPackageMatchScore(array $package, $variantTotal, $budget, $days, array $interests, $travelers) {
    $budget = max(1,(float)$budget);
    $variantTotal = max(0,(float)$variantTotal);
    $budgetScore = $variantTotal <= $budget ? 40 : max(0, 40 - (($variantTotal-$budget)/$budget)*40);
    $daysScore = 20 - min(20, abs((int)$package['days']-(int)$days)*10);
    $interestScore = packageInterestScore($package,$interests) * (20/60);
    $travelerScore = ($travelers >= 1 && $travelers <= 20) ? 10 : 0;
    return (int)round(min(100,$budgetScore+$daysScore+$interestScore+$travelerScore));
}

function getCheaperAlternatives($transportList, $hotelList, $currentTransportId, $currentHotelId, $activityRows, $selectedActivityIds, $travelers, $days) {
    $out=['transport'=>null,'hotel'=>null,'activity_savings'=>0,'remove_activity'=>null];
    $currentTransport=null; foreach($transportList as $r){if((int)$r['id']===(int)$currentTransportId){$currentTransport=$r;break;}}
    $currentHotel=null; foreach($hotelList as $r){if((int)$r['id']===(int)$currentHotelId){$currentHotel=$r;break;}}
    if($currentTransport){ foreach($transportList as $r){ if((float)$r['price'] < (float)$currentTransport['price']) {$out['transport']=$r;break;} } }
    if($currentHotel){ foreach($hotelList as $r){ if((float)$r['price_per_night'] < (float)$currentHotel['price_per_night']) {$out['hotel']=$r;break;} } }
    $map=[]; foreach($activityRows as $r){$map[(int)$r['id']]=$r;}
    $chosen=[]; foreach((array)$selectedActivityIds as $id){ if(isset($map[(int)$id])) $chosen[]=$map[(int)$id]; }
    if($chosen){ usort($chosen,fn($a,$b)=>((float)$b['price']<=> (float)$a['price'])); $a=$chosen[0]; $out['remove_activity']=$a; $out['activity_savings']=(float)$a['price']*$travelers; }
    return $out;
}


function getCustomizationOptions(array $cities = []) {
    $destination = $cities[0] ?? 'Your Destination';
    return [
        'transport' => [
            ['id'=>1,'type'=>'Standard','provider'=>'Comfort Travel','from_location'=>'Your City','to_location'=>$destination,'price'=>900],
            ['id'=>2,'type'=>'Comfort','provider'=>'Premium Coach','from_location'=>'Your City','to_location'=>$destination,'price'=>1500],
            ['id'=>3,'type'=>'Premium','provider'=>'Private Transfer','from_location'=>'Your City','to_location'=>$destination,'price'=>2400],
        ],
        'hotels' => [
            ['id'=>1,'dest_name'=>$destination,'name'=>'Standard Stay','rating'=>3.5,'room_type'=>'Comfort Room','price_per_night'=>1800],
            ['id'=>2,'dest_name'=>$destination,'name'=>'Comfort Stay','rating'=>4.2,'room_type'=>'Deluxe Room','price_per_night'=>2800],
            ['id'=>3,'dest_name'=>$destination,'name'=>'Premium Stay','rating'=>4.7,'room_type'=>'Premium Room','price_per_night'=>4500],
        ],
        'activities' => [
            ['id'=>1,'dest_name'=>$destination,'name'=>'Local Sightseeing','description'=>'Guided local highlights and sightseeing.','price'=>500],
            ['id'=>2,'dest_name'=>$destination,'name'=>'Adventure Experience','description'=>'Optional adventure experience for your trip.','price'=>900],
            ['id'=>3,'dest_name'=>$destination,'name'=>'Cultural Experience','description'=>'Discover local culture and traditions.','price'=>700],
        ]
    ];
}

function getTripRoute(array $trip, PDO $pdo = null) {
    $packageName = trim((string)($trip['destination'] ?? ''));
    if ($pdo) {
        $package = getTourPackage($pdo, $packageName);
        if ($package && !empty($package['cities'])) return array_values($package['cities']);
    }
    $route = (string)($trip['estimated_distance'] ?? '');
    if (stripos($route, 'Package route:') === 0) {
        $route = trim(substr($route, strlen('Package route:')));
        if ($route !== '') return array_values(array_filter(array_map('trim', preg_split('/\s*→\s*/u', $route))));
    }
    return [];
}

/**
 * Returns the destination cities configured for a saved Smart Trip Planner package.
 * Trips store the package name in the destination column, so this helper maps it
 * back to the package route for hotel/activity filtering.
 */
function generateBookingReference() {
    return 'BMT' . date('Y') . strtoupper(substr(uniqid(), -6));
}

function generateTransactionId() {
    return 'TXN' . strtoupper(substr(uniqid(), -10));
}

// Small static route table used only by the college-project demo.
function getRouteDistance($from, $to) {
    $routes = [
        'Ahmedabad-Udaipur'   => ['distance' => '250 km', 'time' => '5-6 hours'],
        'Udaipur-Jodhpur'     => ['distance' => '250 km', 'time' => '5-6 hours'],
        'Jodhpur-Jaisalmer'   => ['distance' => '280 km', 'time' => '5-6 hours'],
        'Jaisalmer-Ahmedabad' => ['distance' => '650 km', 'time' => '12-14 hours'],
    ];
    $key = "$from-$to";
    return $routes[$key] ?? ['distance' => 'Approx. 200 km', 'time' => 'Approx. 4-5 hours'];
}


/**
 * Smart recommendation helpers.
 * This is a rule-based recommendation engine designed for the college mini project.
 */
function normalizeInterests($interests) {
    if (is_array($interests)) {
        return array_values(array_unique(array_filter(array_map('trim', $interests))));
    }
    return array_values(array_unique(array_filter(array_map('trim', explode(',', (string)$interests)))));
}

function activityInterestScore(array $activity, array $interests) {
    if (!$interests) return 10;

    $category = strtolower(trim((string)($activity['category'] ?? '')));
    $text = strtolower(
        (string)($activity['name'] ?? '') . ' ' .
        (string)($activity['description'] ?? '')
    );

    $keywords = [
        'Historical' => ['historical', 'history', 'fort', 'palace', 'museum', 'heritage', 'ashram'],
        'Nature' => ['nature', 'lake', 'garden', 'valley', 'tea', 'scenic', 'boat'],
        'Adventure' => ['adventure', 'safari', 'trek', 'gondola', 'camp', 'desert'],
        'Culture' => ['culture', 'cultural', 'heritage', 'walk', 'folk', 'city', 'local'],
        'Food' => ['food', 'cuisine', 'culinary', 'restaurant', 'market'],
        'Shopping' => ['shopping', 'market', 'shop', 'bazaar', 'handicraft']
    ];

    $score = 0;
    foreach ($interests as $interest) {
        if (strtolower($interest) === $category) {
            $score += 45;
            continue;
        }
        foreach ($keywords[$interest] ?? [] as $keyword) {
            if (strpos($text, $keyword) !== false) {
                $score += 30;
                break;
            }
        }
    }
    return $score;
}

function hotelRecommendationScore(array $hotel, $travelStyle, $perNightBudget) {
    $ratingScore = min(40, max(0, ((float)$hotel['rating'] / 5) * 40));
    $price = (float)$hotel['price_per_night'];
    $budgetBase = max(1, (float)$perNightBudget);

    $ratio = $price / $budgetBase;
    if ($travelStyle === 'Budget') {
        $styleScore = $ratio <= 1 ? 30 : max(0, 30 - (($ratio - 1) * 30));
    } elseif ($travelStyle === 'Luxury') {
        $styleScore = min(30, 10 + ((float)$hotel['rating'] * 4));
    } else {
        $styleScore = $ratio <= 1.25 ? 30 : max(0, 30 - (($ratio - 1.25) * 35));
    }

    $budgetScore = $ratio <= 1 ? 20 : max(0, 20 - (($ratio - 1) * 20));
    return round($ratingScore + $styleScore + $budgetScore + 10, 1);
}

function transportRecommendationScore(array $transport, $travelStyle, $perTravelerBudget) {
    $price = (float)$transport['price'];
    $budgetBase = max(1, (float)$perTravelerBudget);
    $ratio = $price / $budgetBase;

    $typeScoreMap = [
        'Budget' => ['Bus' => 35, 'Train' => 28, 'Flight' => 12],
        'Standard' => ['Train' => 35, 'Flight' => 30, 'Bus' => 20],
        'Luxury' => ['Flight' => 40, 'Train' => 28, 'Bus' => 15]
    ];

    $typeScore = $typeScoreMap[$travelStyle][$transport['type']] ?? 15;
    $priceScore = $ratio <= 0.35 ? 40 : max(0, 40 - (($ratio - 0.35) * 45));
    $seatScore = ((int)($transport['seats'] ?? 0) > 0) ? 15 : 0;
    $durationScore = 10;

    return round($typeScore + $priceScore + $seatScore + $durationScore, 1);
}
