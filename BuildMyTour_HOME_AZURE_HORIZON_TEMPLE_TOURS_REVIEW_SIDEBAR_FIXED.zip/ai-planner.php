<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Smart Trip Planner';

$packages = getTourPackages($pdo);
$categories = getTripCategories($pdo);
$reviewStats = getPackageReviewStats($pdo, array_keys($packages));
include 'includes/header.php';
?>
<section class="smart-planner-hero">
  <div class="container">
    <span class="smart-planner-eyebrow">✦ PACKAGE-BASED SMART TRIP PLANNER</span>
    <h1>Choose. Match. <span>Customize.</span></h1>
    <p>Tell us the kind of trip you want. BuildMyTour suggests the right package, then gives you Smart Saver, Best Balance and Premium Experience choices.</p>
  </div>
</section>

<div class="container smart-planner-page py-4 py-md-5">
<form id="plannerForm" method="POST" action="generate-trip.php">
<input type="hidden" name="category" id="selectedCategory">
<input type="hidden" name="package_name" id="selectedPackage">
<input type="hidden" name="variant" id="selectedVariant">

<section class="planner-step active" data-step="1">
 <div class="smart-planner-card card border-0 shadow-sm"><div class="card-body p-4 p-md-5">
  <div class="smart-section-heading"><div class="smart-step-icon">1</div><div><span>STEP 1</span><h2>What kind of trip do you want?</h2><p>Start by choosing your travel experience.</p></div></div>
  <div class="row g-4">
  <?php foreach($categories as $name => $meta): ?>
   <div class="col-md-4"><button type="button" class="trip-type-card w-100" data-category="<?php echo e($name); ?>">
    <div class="trip-type-image">
      <img src="<?php echo e($meta['image'] ?? 'assets/images/placeholder.jpg'); ?>" alt="<?php echo e($name); ?>" onerror="this.style.display='none';this.parentElement.classList.add('image-missing');">
      <div class="trip-type-image-fallback"><?php echo e($meta['icon']); ?></div>
    </div>
    <div class="trip-type-content"><div class="trip-type-icon"><?php echo e($meta['icon']); ?></div><h3><?php echo e($name); ?></h3><p><?php echo e($meta['description']); ?></p></div>
   </button></div>
  <?php endforeach; ?>
  </div>
 </div></div>
</section>

<section class="planner-step" data-step="2">
 <div class="smart-planner-card card border-0 shadow-sm"><div class="card-body p-4 p-md-5">
  <div class="smart-section-heading"><div class="smart-step-icon">2</div><div><span>STEP 2</span><h2>Choose your destination package</h2><p id="categoryText">We will show packages matching your trip type.</p></div></div>
  <div class="row g-4" id="packageGrid">
  <?php foreach($packages as $name=>$p): ?>
   <div class="col-md-6 package-option" data-category="<?php echo e($p['category']); ?>">
    <button type="button" class="smart-package-card w-100" data-package="<?php echo e($name); ?>">
     <div class="smart-package-image">
       <img src="<?php echo e($p['image'] ?? 'assets/images/placeholder.jpg'); ?>" alt="<?php echo e($name); ?>" onerror="this.style.display='none';this.parentElement.classList.add('image-missing');">
       <div class="package-image-fallback"><?php echo $p['icon']; ?></div>
       <?php if (!empty($p['offer_percentage'])): ?><div class="package-image-offer">🔥 <?php echo (int)$p['offer_percentage']; ?>% OFF</div><?php endif; ?>
     </div>
     <div class="smart-package-content">
     <div class="package-route"><?php echo e(implode(' → ', $p['cities'])); ?></div>
     <h3><?php echo $p['icon'].' '.e($name); ?></h3>
     <p><?php echo (int)$p['days']; ?> Days • <?php echo e($p['category']); ?></p>
     <?php $rs=$reviewStats[$name]??null; ?>
     <?php if($rs): ?><div class="package-rating">★★★★★ <?php echo e($rs['avg_rating']); ?>/5 · <?php echo (int)$rs['review_count']; ?> reviews</div><?php else: ?><div class="package-rating muted">No reviews yet</div><?php endif; ?>
     <span>View Package →</span>
     </div>
    </button>
   </div>
  <?php endforeach; ?>
  </div>
  <div class="planner-actions"><button type="button" class="btn btn-outline-secondary back-step">← Back</button></div>
 </div></div>
</section>

<section class="planner-step" data-step="3">
 <div class="smart-planner-card card border-0 shadow-sm"><div class="card-body p-4 p-md-5">
  <div class="smart-section-heading"><div class="smart-step-icon">3</div><div><span>STEP 3</span><h2>Trip details</h2><p id="selectedPackageText"></p></div></div>
  <div class="row g-3">
   <div class="col-md-4"><label class="form-label">Travel Start Date</label><input type="date" name="start_date" class="form-control" min="<?php echo date('Y-m-d'); ?>" value="<?php echo date('Y-m-d'); ?>" required></div>
   <div class="col-md-4"><label class="form-label">Number of Travelers</label><input type="number" id="travelers" name="travelers" min="1" max="20" value="2" class="form-control" required></div>
   <div class="col-md-4"><label class="form-label">Your Total Budget (₹)</label><input type="number" id="budget" name="budget" min="1000" step="500" value="30000" class="form-control" required></div>
   <div class="col-md-6"><label class="form-label">Travel With</label><select name="travel_with" class="form-select"><option>Solo</option><option selected>Friends</option><option>Couple</option><option>Family</option></select></div>
   <div class="col-md-6"><label class="form-label">Main Interest</label><select name="interests[]" class="form-select" required><option value="Adventure">Adventure</option><option value="Nature">Nature</option><option value="Culture">Culture</option><option value="Historical">Heritage & History</option><option value="Food">Food</option></select></div>
  </div>
  <div class="planner-actions"><button type="button" class="btn btn-outline-secondary back-step">← Back</button><button type="button" class="btn btn-primary next-details">Find My Smart Package →</button></div>
 </div></div>
</section>

<section class="planner-step" data-step="4">
 <div class="smart-planner-card card border-0 shadow-sm"><div class="card-body p-4 p-md-5">
  <div class="smart-section-heading"><div class="smart-step-icon">4</div><div><span>STEP 4</span><h2>Smart package recommendation</h2><p>Choose one of three versions. The highlighted option is the best fit for your budget.</p></div></div>
  <div class="row g-4" id="variantGrid"></div>
  <div class="planner-actions"><button type="button" class="btn btn-outline-secondary back-step">← Back</button></div>
 </div></div>
</section>
</form>
</div>

<script>
const packages = <?php echo json_encode($packages, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
const reviewStats = <?php echo json_encode($reviewStats, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES); ?>;
function variantOfferPriceClient(v,p){const pct=(p.offer_active?Number(p.offer_percentage||0):0);return pct>0?v.price_per_person*(1-pct/100):v.price_per_person;}
function formatINR(n){return '₹'+Math.round(n).toLocaleString('en-IN');}
let step=1, chosenPackage='';
const form=document.getElementById('plannerForm');
const selectedCategory=document.getElementById('selectedCategory');
const selectedPackage=document.getElementById('selectedPackage');
const selectedVariant=document.getElementById('selectedVariant');
function showStep(n){step=n;document.querySelectorAll('.planner-step').forEach(x=>x.classList.toggle('active',+x.dataset.step===n));window.scrollTo({top:0,behavior:'smooth'});}
document.querySelectorAll('.trip-type-card').forEach(b=>b.onclick=()=>{const c=b.dataset.category;selectedCategory.value=c;document.querySelectorAll('.package-option').forEach(x=>x.style.display=x.dataset.category===c?'block':'none');document.getElementById('categoryText').textContent='Packages selected for: '+c;showStep(2);});
document.querySelectorAll('.smart-package-card').forEach(b=>b.onclick=()=>{chosenPackage=b.dataset.package;selectedPackage.value=chosenPackage;const p=packages[chosenPackage];document.getElementById('selectedPackageText').textContent='Selected: '+chosenPackage+' • '+p.days+' Days';showStep(3);});
document.querySelectorAll('.back-step').forEach(b=>b.onclick=()=>showStep(step-1));
document.querySelector('.next-details').onclick=()=>{
 const t=+document.getElementById('travelers').value, bud=+document.getElementById('budget').value;
 if(!t||!bud||t<1||bud<1000){alert('Please enter valid travelers and budget.');return;}
 const p=packages[chosenPackage], variants=p.variants, days=p.days;
 const interestEl=document.querySelector('select[name="interests[]"]'); const interest=interestEl?interestEl.value:'';
 const travelWith=document.querySelector('select[name="travel_with"]')?.value||'';
 const entries=Object.entries(variants).map(([key,v])=>({key,...v,original:v.price_per_person,discountPercent:(p.offer_active?Number(p.offer_percentage||0):0),total:variantOfferPriceClient(v,p)*t}));
 // Strong recommendation: highest package level that fits the user's budget; otherwise choose the lowest-cost option.
 let recommended=entries.filter(v=>v.total<=bud).sort((a,b)=>b.total-a.total)[0];
 let budgetGap=0;
 if(!recommended){recommended=entries.slice().sort((a,b)=>a.total-b.total)[0];budgetGap=recommended.total-bud;}
 const scoreBase=(v)=>{
   const b= v.total<=bud ? 40 : Math.max(0,40-((v.total-bud)/Math.max(1,bud))*40);
   const d=20-Math.min(20,Math.abs(days-p.days)*10);
   const cat=(p.category||'').toLowerCase(); const i=(interest||'').toLowerCase();
   let im=0; if(i && cat.includes(i)) im=15; else if((p.description||'').toLowerCase().includes(i)) im=10;
   const tw=travelWith ? 10 : 0; return Math.round(b+d+im+tw);
 };
 entries.forEach(v=>v.score=Math.min(100,scoreBase(v)));
 entries.sort((a,b)=>b.score-a.score);
 const optionLabel=(k)=>k==='Budget'?'Smart Saver':(k==='Recommended'?'Best Balance':'Premium Experience');
 const stats=reviewStats[chosenPackage];
 const reviewsHtml=stats?`<div class="variant-review">★★★★★ ${stats.avg_rating}/5 · ${stats.review_count} reviews</div>`:'<div class="variant-review muted">No reviews yet</div>';
 document.getElementById('variantGrid').innerHTML=entries.map(v=>`<div class="col-md-4"><button type="button" class="variant-card ${v.key===recommended.key?'recommended':''}" data-variant="${v.key}">
   ${v.key===recommended.key?'<div class="smart-recommended-pill">⚖️ Best Balance For You</div>':''}
   <div class="variant-tag">${v.tag} ${optionLabel(v.key)}</div><h3>${v.name}</h3>
   <div class="variant-price">${v.discountPercent?`<del class="old-price">${formatINR(v.original*t)}</del> `:''}${formatINR(v.total)}</div>
   <p>For ${t} traveler${t>1?'s':''}${p.offer_active?` · 🔥 ${p.offer_percentage}% OFF`:''}</p>${reviewsHtml}
   <div class="match-score">${v.score}% Smart Match</div>
   <small>${v.key==='Budget'?'Save more, explore more':v.key==='Recommended'?'Great comfort at the right price':'Enhanced comfort and exclusive experiences'}</small>
   ${v.key===recommended.key?`<div class="why-recommended"><strong>Why this option?</strong><span>✓ Best fit for your budget</span><span>✓ Matches your ${eJS(p.category)} trip style</span><span>✓ ${days}-day package</span></div>`:''}
   ${v.key===recommended.key&&budgetGap>0?`<div class="budget-alternative">💡 ${formatINR(budgetGap)} above budget. Customize the trip to reduce cost.</div>`:''}
 </button></div>`).join('')+`<div class="col-12"><div class="package-compare"><strong>Compare your 3 options</strong><div class="compare-grid">${entries.map(v=>`<div><b>${optionLabel(v.key)}</b><span>${formatINR(v.total)}</span><small>${v.score}% match</small></div>`).join('')}</div></div></div>`;
 function eJS(x){return String(x||'').replace(/[<>&"]/g,s=>({'<':'&lt;','>':'&gt;','&':'&amp;','"':'&quot;'}[s]));}
 document.querySelectorAll('.variant-card').forEach(b=>b.onclick=()=>{selectedVariant.value=b.dataset.variant;form.submit();});
 showStep(4);
};
</script>
<?php include 'includes/footer.php'; ?>