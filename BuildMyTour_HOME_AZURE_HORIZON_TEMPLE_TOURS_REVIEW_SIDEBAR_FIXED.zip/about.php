<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
requireLogin();
$pageTitle = 'About';
include 'includes/header.php';
?>

<section class="simple-page">
    <div class="container simple-page-inner">
        <div class="simple-page-card about-card">
            <span class="simple-eyebrow">ABOUT BUILDMYTOUR</span>
            <h1>Plan Smarter. Travel Better.</h1>
            <p>BuildMyTour is a simple travel planning and booking platform that helps users organize their trips in one place.</p>

            <div class="simple-divider"></div>

            <h2>What you can do</h2>
            <ul class="simple-list">
                <li>Plan a personalized trip</li>
                <li>Select transport, hotel and activities</li>
                <li>Choose transport and hotels</li>
                <li>Review bookings and trip details</li>
            </ul>

            <p class="simple-note">Built as a college mini project using HTML, CSS, JavaScript, PHP and MySQL.</p>
        </div>
    </div>
</section>

<?php include 'includes/footer.php'; ?>
