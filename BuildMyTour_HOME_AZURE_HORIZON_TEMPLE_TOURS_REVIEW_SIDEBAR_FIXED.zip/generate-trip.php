<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: ai-planner.php'); exit; }

$userId = (int)currentUserId();
$packageName = trim($_POST['package_name'] ?? '');
$category = trim($_POST['category'] ?? '');
$variant = trim($_POST['variant'] ?? '');
$startDate = $_POST['start_date'] ?? '';
$travelers = (int)($_POST['travelers'] ?? 0);
$budget = (float)($_POST['budget'] ?? 0);
$travelWith = trim($_POST['travel_with'] ?? '');
$interests = normalizeInterests($_POST['interests'] ?? []);

$package = getTourPackage($pdo, $packageName);
if (!$package || $package['category'] !== $category || !isset($package['variants'][$variant]) ||
    !$startDate || strtotime($startDate) === false || $travelers < 1 || $travelers > 20 || $budget < 1000) {
    flash('error','Please complete the new Smart Trip Planner flow.');
    header('Location: ai-planner.php'); exit;
}

$days = (int)$package['days'];
$endDate = date('Y-m-d', strtotime($startDate.' +'.max(0,$days-1).' days'));
$variantData = $package['variants'][$variant];
$pricePerPerson = variantOfferPrice($variantData, $package);
$packageTotal = $pricePerPerson * $travelers;
$originalPackageTotal = (float)$variantData['price_per_person'] * $travelers;
$discountAmount = max(0, $originalPackageTotal - $packageTotal);
$travelStyle = $variant === 'Budget' ? 'Budget' : ($variant === 'Premium' ? 'Luxury' : 'Standard');
$pdo->beginTransaction();
try {
    $insert=$pdo->prepare("INSERT INTO trips
      (user_id,package_id,variant_id,start_location,destination,start_date,end_date,days,travelers,budget,travel_style,interests,transport_preference,estimated_distance,estimated_cost,status)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'planned')");
    $insert->execute([
        $userId,(int)$package['id'],(int)$variantData['id'],'Package Planner',$packageName,$startDate,$endDate,$days,$travelers,$budget,$travelStyle,
        implode(', ',$interests),'Any','Package route: '.implode(' → ',$package['cities']),$packageTotal
    ]);
    $tripId=(int)$pdo->lastInsertId();

    // Smart defaults come from lightweight application options, keeping the database at 8 core tables.
    $options=getCustomizationOptions($package['cities']);
    $transportRows=$options['transport']; $hotels=$options['hotels']; $activities=$options['activities'];
    $levelIndex=$variant==='Budget'?0:($variant==='Premium'?2:1);
    $bestTransport=$transportRows[$levelIndex];
    $bestHotel=$hotels[$levelIndex];
    $activityIds=$variant==='Budget'?[1]:($variant==='Premium'?[1,2,3]:[1,3]);

    $_SESSION['selection'][$tripId]=[
      'transport_id'=>(int)$bestTransport['id'],
      'hotel_id'=>(int)$bestHotel['id'],
      'activity_ids'=>$activityIds,
      'package_name'=>$packageName,
      'package_category'=>$category,
      'package_variant'=>$variant,
      'package_variant_name'=>$variantData['name'],
      'package_total'=>$packageTotal,
      'original_package_total'=>$originalPackageTotal,
      'discount_amount'=>$discountAmount,
      'offer_percentage'=>(float)($package['offer_percentage'] ?? 0),
      'travel_with'=>$travelWith,
      'interests'=>$interests,
      'system_generated'=>true,
      'customized'=>false,
      'base_package_total'=>$packageTotal,
      'base_package_original_total'=>$originalPackageTotal,
      'offer_discount'=>$discountAmount,
      'budget_status'=>$packageTotal <= $budget ? 'within_budget' : 'over_budget',
      'recommendation_explanation'=>[
        'package'=>'Matched using trip type, destination, travelers and total budget.',
        'variant'=>'You selected the '.$variant.' package level.',
        'customize'=>'Use the one-page customization to bring the trip closer to your budget.'
      ]
    ];
    $selectedActivities=array_values(array_filter($activities,fn($x)=>in_array((int)$x['id'],$activityIds,true)));
    $persist=$pdo->prepare("UPDATE trips SET customization_json=? WHERE id=?");
    $persist->execute([json_encode(['transport_id'=>$bestTransport['id'],'hotel_id'=>$bestHotel['id'],'activity_ids'=>$activityIds,'transport'=>$bestTransport,'hotel'=>$bestHotel,'activities'=>$selectedActivities], JSON_UNESCAPED_UNICODE),$tripId]);
    $pdo->commit();
    // Short Smart Planner flow: recommendation -> one customization step -> one final summary.
    $_SESSION['selection'][$tripId]['total_cost'] = $packageTotal;
    header("Location: customize-trip.php?trip_id=$tripId"); exit;
} catch(Throwable $e){
    if($pdo->inTransaction())$pdo->rollBack();
    if(isset($tripId))unset($_SESSION['selection'][$tripId]);
    flash('error','Smart plan could not be generated: '.$e->getMessage());
    header('Location: ai-planner.php'); exit;
}