<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';

if (isAdmin()) {
    header("Location: dashboard.php");
    exit;
}

$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($email === '' || $password === '') {
        $errors[] = "Please enter email and password.";
    } else {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? AND role = 'admin'");
        $stmt->execute([$email]);
        $admin = $stmt->fetch();

        if ($admin && password_verify($password, $admin['password'])) {
            $_SESSION['admin_id'] = $admin['id'];
            $_SESSION['admin_name'] = $admin['name'];
            header("Location: dashboard.php");
            exit;
        }

        $errors[] = "Invalid admin credentials.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Login - BuildMyTour</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" href="../assets/css/style.css">
</head>
<body class="admin-login-page">

<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-12 col-md-9 col-lg-6 col-xl-5">

            <div class="card shadow-sm border-0 admin-login-card">
                <div class="card-body p-4 p-md-5">

                    <div class="text-center mb-4">
                        <a href="../index.php" class="d-inline-block admin-login-logo-link">
                            <img src="../assets/images/logo/buildmytour-logo.png"
                                 alt="BuildMyTour"
                                 class="admin-login-logo-img">
                        </a>

                        <div class="admin-login-label mt-3">
                            ADMIN PANEL
                        </div>
                    </div>

                    <div class="mb-4">
                        <h1 class="h4 mb-1">Admin Login</h1>
                        <p class="text-muted mb-0">
                            Login to manage BuildMyTour.
                        </p>
                    </div>

                    <?php foreach ($errors as $err): ?>
                        <div class="alert alert-danger">
                            <?php echo e($err); ?>
                        </div>
                    <?php endforeach; ?>

                    <form method="POST" action="login.php" novalidate>

                        <div class="mb-3">
                            <label for="adminEmail" class="form-label">
                                Email
                            </label>
                            <input
                                type="email"
                                id="adminEmail"
                                name="email"
                                class="form-control"
                                value="<?php echo e($_POST['email'] ?? ''); ?>"
                                autocomplete="email"
                                required
                            >
                        </div>

                        <div class="mb-4">
                            <label for="adminPassword" class="form-label">
                                Password
                            </label>
                            <input
                                type="password"
                                id="adminPassword"
                                name="password"
                                class="form-control"
                                autocomplete="current-password"
                                required
                            >
                        </div>

                        <button type="submit" class="btn btn-primary w-100">
                            Login to Admin Panel
                        </button>

                    </form>

                    <div class="text-center mt-4 pt-3 border-top">
                        <a href="../auth.php?mode=login"
                           class="admin-login-back-link">
                            ← Back to User Login
                        </a>
                    </div>

                </div>
            </div>

        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
