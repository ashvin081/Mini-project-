<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Review Management';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tripId = (int)($_POST['trip_id'] ?? 0);
    $status = $_POST['review_status'] ?? '';
    $allowed = ['pending','approved','rejected'];
    if ($tripId > 0 && in_array($status, $allowed, true)) {
        // Update the review itself.
        $stmt = $pdo->prepare("SELECT user_id, package_id FROM reviews WHERE id = ? LIMIT 1");
        $stmt->execute([$tripId]);
        $review = $stmt->fetch();

        if ($review) {
            $stmt = $pdo->prepare("UPDATE reviews SET status = ? WHERE id = ?");
            $stmt->execute([$status, $tripId]);

            // Keep the related completed trip in sync so My Bookings also
            // reflects the review state immediately after admin approval.
            $stmt = $pdo->prepare("SELECT id FROM trips WHERE user_id = ? AND package_id = ? AND booking_status = 'completed' ORDER BY created_at DESC LIMIT 1");
            $stmt->execute([(int)$review['user_id'], (int)$review['package_id']]);
            $relatedTripId = (int)$stmt->fetchColumn();
            if ($relatedTripId > 0) {
                $stmt = $pdo->prepare("UPDATE trips SET review_status = ?, reviewed_at = NOW() WHERE id = ?");
                $stmt->execute([$status === 'pending' ? 'pending' : $status, $relatedTripId]);
            }

            flash('success', 'Review status updated to ' . ucfirst($status) . '.');
        }
    }
    header('Location: reviews.php');
    exit;
}

$reviews = $pdo->query("SELECT r.*, u.name AS user_name, u.email, p.name AS destination FROM reviews r JOIN users u ON u.id = r.user_id JOIN tour_packages p ON p.id = r.package_id ORDER BY FIELD(r.status, 'pending', 'approved', 'rejected'), r.created_at DESC")->fetchAll();
$successMsg = flash('success');
include '../includes/admin-header.php';
?>
<div class="admin-page-header">
  <div><h1>Review Management</h1><p>Approve or reject traveler reviews before they are shown publicly.</p></div>
  <div class="admin-page-meta">Engagement</div>
</div>
<?php if ($successMsg): ?><div class="alert alert-success admin-alert"><?php echo e($successMsg); ?></div><?php endif; ?>
<div class="admin-table-card">
  <div class="admin-table-card-head"><h2>Submitted Reviews</h2><span><?php echo count($reviews); ?> total</span></div>
  <div class="admin-table-scroll"><table>
    <tr><th>Traveler</th><th>Trip</th><th>Rating</th><th>Review</th><th>Submitted</th><th>Status</th></tr>
    <?php if (!$reviews): ?><tr><td colspan="6" class="text-center py-4">No reviews submitted yet.</td></tr><?php endif; ?>
    <?php foreach ($reviews as $r): ?>
    <tr>
      <td><?php echo e($r['user_name']); ?><br><small><?php echo e($r['email']); ?></small></td>
      <td><?php echo e($r['destination']); ?><br><small><?php echo e('Review #' . $r['id']); ?></small></td>
      <td><strong><?php echo str_repeat('★', max(0,(int)$r['rating'])); ?></strong><br><small><?php echo (int)$r['rating']; ?>/5</small></td>
      <td style="min-width:240px"><?php echo nl2br(e($r['comment'])); ?></td>
      <td><?php echo $r['created_at'] ? date('d M Y', strtotime($r['created_at'])) : '-'; ?></td>
      <td>
        <form method="POST" class="booking-status-select-form review-status-select-form">
          <input type="hidden" name="trip_id" value="<?php echo (int)$r['id']; ?>">
          <select name="review_status" class="booking-status-select review-status-select status-<?php echo e($r['status']); ?>" aria-label="Review status" onchange="this.form.submit()">
            <option value="pending" <?php echo $r['status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
            <option value="approved" <?php echo $r['status'] === 'approved' ? 'selected' : ''; ?>>Approved</option>
            <option value="rejected" <?php echo $r['status'] === 'rejected' ? 'selected' : ''; ?>>Rejected</option>
          </select>
        </form>
      </td>
    </tr>
    <?php endforeach; ?>
  </table></div>
</div>
<?php include '../includes/admin-footer.php'; ?>
