<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle='Smart Packages & Offers';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    try{
        $pdo->beginTransaction();
        if(in_array($action,['add','edit'],true)){
            $name=trim($_POST['name']??'');
            $description=trim($_POST['description']??'');
            $duration=trim($_POST['duration']??'');
            $days=max(1,(int)($_POST['days']??1));
            $categoryId=(int)($_POST['category_id']??0) ?: null;
            $icon=trim($_POST['icon']??'✈️');
            $image=trim($_POST['image']??'');
            $offer=max(0,min(100,(float)($_POST['offer_percentage']??0)));
            $start=$_POST['offer_start_date']?:null;
            $end=$_POST['offer_end_date']?:null;
            $status=($_POST['status']??'active')==='inactive'?'inactive':'active';
            $routeText=trim($_POST['route']??'');
            $variants=$_POST['variants']??[];
            if($name==='') throw new RuntimeException('Package name is required.');
            if($action==='add'){
                $basePrice=(float)($variants['Recommended']['price']??0);
                $st=$pdo->prepare("INSERT INTO tour_packages(name,description,duration,price,image,offer_percentage,offer_start_date,offer_end_date,status,category_id,days,icon,route) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)");
                $st->execute([$name,$description,$duration,$basePrice,$image,$offer,$start,$end,$status,$categoryId,$days,$icon,$routeText]);
                $id=(int)$pdo->lastInsertId();
            } else {
                $id=(int)$_POST['id'];
                $basePrice=(float)($variants['Recommended']['price']??0);
                $st=$pdo->prepare("UPDATE tour_packages SET name=?,description=?,duration=?,price=?,image=?,offer_percentage=?,offer_start_date=?,offer_end_date=?,status=?,category_id=?,days=?,icon=?,route=? WHERE id=?");
                $st->execute([$name,$description,$duration,$basePrice,$image,$offer,$start,$end,$status,$categoryId,$days,$icon,$routeText,$id]);
                $pdo->prepare("DELETE FROM package_variants WHERE package_id=?")->execute([$id]);
            }
            $tags=['Budget'=>'💰 Smart Saver','Recommended'=>'⚖️ Best Balance','Premium'=>'👑 Premium Experience'];
            $vst=$pdo->prepare("INSERT INTO package_variants(package_id,variant_key,name,price_per_person,tag,status) VALUES(?,?,?,?,?,?)");
            foreach(['Budget','Recommended','Premium'] as $key){
                $v=$variants[$key]??[];
                $vname=trim($v['name']??$key);
                $vprice=max(0,(float)($v['price']??0));
                $vstatus=($v['status']??'active')==='inactive'?'inactive':'active';
                $vst->execute([$id,$key,$vname,$vprice,$tags[$key],$vstatus]);
            }
        } elseif($action==='delete'){
            $pdo->prepare("DELETE FROM tour_packages WHERE id=?")->execute([(int)$_POST['id']]);
        }
        $pdo->commit();
    }catch(Throwable $e){if($pdo->inTransaction())$pdo->rollBack();flash('error','Package update failed: '.$e->getMessage());}
    header('Location: tour-packages.php');exit;
}

$categories=$pdo->query("SELECT * FROM trip_categories ORDER BY id")->fetchAll();
$edit=null;$editRoute='';$editVariants=[];
if(!empty($_GET['edit'])){
    $st=$pdo->prepare("SELECT * FROM tour_packages WHERE id=?");$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();
    if($edit){
        $editRoute=$edit['route'] ?? '';
        $st=$pdo->prepare("SELECT * FROM package_variants WHERE package_id=?");$st->execute([$edit['id']]);foreach($st->fetchAll() as $v)$editVariants[$v['variant_key']]=$v;
    }
}
$items=$pdo->query("SELECT p.*,c.name category_name,p.route FROM tour_packages p LEFT JOIN trip_categories c ON c.id=p.category_id ORDER BY p.id")->fetchAll();
include '../includes/admin-header.php';
?>
<div class="admin-page-header"><div><h1>Smart Packages & Offers</h1><p>One database source controls frontend packages, variants, routes, prices, offers and status.</p></div><div class="admin-page-meta">Admin → Database → Smart Planner</div></div>
<?php if($msg=flash('error')):?><div class="alert alert-danger"><?php echo e($msg);?></div><?php endif;?>
<div class="admin-form-card"><h3><?php echo $edit?'Edit Smart Package':'Add Smart Package';?></h3>
<form method="POST"><input type="hidden" name="action" value="<?php echo $edit?'edit':'add';?>"><?php if($edit):?><input type="hidden" name="id" value="<?php echo (int)$edit['id'];?>"><?php endif;?>
<div class="form-row"><div class="form-group"><label>Package Name</label><input class="form-control" name="name" required value="<?php echo e($edit['name']??'');?>"></div><div class="form-group"><label>Trip Type</label><select class="form-control" name="category_id" required><option value="">Select Trip Type</option><?php foreach($categories as $c):?><option value="<?php echo (int)$c['id'];?>" <?php echo (($edit['category_id']??'')==$c['id'])?'selected':'';?>><?php echo e($c['name']);?></option><?php endforeach;?></select></div></div>
<div class="form-row"><div class="form-group"><label>Days</label><input type="number" min="1" class="form-control" name="days" required value="<?php echo e($edit['days']??'');?>"></div><div class="form-group"><label>Duration Label</label><input class="form-control" name="duration" required value="<?php echo e($edit['duration']??'');?>"></div><div class="form-group"><label>Icon</label><input class="form-control" name="icon" value="<?php echo e($edit['icon']??'✈️');?>"></div></div>
<div class="form-group"><label>Description</label><textarea class="form-control" name="description" rows="2"><?php echo e($edit['description']??'');?></textarea></div>
<div class="form-group"><label>Main Image Path</label><input class="form-control" name="image" value="<?php echo e($edit['image']??'assets/images/placeholder.jpg');?>"></div>
<div class="form-group"><label>Package Route</label><input class="form-control" name="route" required placeholder="Leh → Nubra Valley → Pangong Lake" value="<?php echo e($editRoute ?? ''); ?>"></div>
<div class="admin-table-card" style="margin-top:16px"><div class="admin-table-card-head"><h2>💰 Smart Saver / ⚖️ Best Balance / 👑 Premium Experience</h2><span>Per-person prices</span></div><div class="admin-table-scroll"><table><tr><th>Variant</th><th>Display Name</th><th>Price Per Person (₹)</th><th>Status</th></tr><?php foreach(['Budget'=>'💰 Smart Saver','Recommended'=>'⚖️ Best Balance','Premium'=>'👑 Premium Experience'] as $key=>$tag):$v=$editVariants[$key]??[];?><tr><td><?php echo $tag.' '.e($key);?></td><td><input class="form-control" name="variants[<?php echo $key;?>][name]" required value="<?php echo e($v['name']??$key);?>"></td><td><input type="number" min="0" class="form-control" name="variants[<?php echo $key;?>][price]" required value="<?php echo e($v['price_per_person']??'');?>"></td><td><select class="form-control" name="variants[<?php echo $key;?>][status]"><option value="active" <?php echo (($v['status']??'active')==='active')?'selected':'';?>>Active</option><option value="inactive" <?php echo (($v['status']??'')==='inactive')?'selected':'';?>>Inactive</option></select></td></tr><?php endforeach;?></table></div></div>
<div class="form-row" style="margin-top:16px"><div class="form-group"><label>Offer Percentage</label><input type="number" min="0" max="100" step="0.01" class="form-control" name="offer_percentage" value="<?php echo e($edit['offer_percentage']??0);?>"></div><div class="form-group"><label>Offer Start</label><input type="date" class="form-control" name="offer_start_date" value="<?php echo e($edit['offer_start_date']??'');?>"></div><div class="form-group"><label>Offer End</label><input type="date" class="form-control" name="offer_end_date" value="<?php echo e($edit['offer_end_date']??'');?>"></div><div class="form-group"><label>Status</label><select class="form-control" name="status"><option value="active" <?php echo (($edit['status']??'active')==='active')?'selected':'';?>>Active</option><option value="inactive" <?php echo (($edit['status']??'')==='inactive')?'selected':'';?>>Inactive</option></select></div></div>
<button class="btn btn-primary"><?php echo $edit?'Update':'Add';?> Smart Package</button><?php if($edit):?><a class="btn btn-outline" href="tour-packages.php">Cancel</a><?php endif;?></form></div>
<div class="admin-table-card"><div class="admin-table-card-head"><h2>Live Smart Planner Packages</h2><span>Frontend reads these records directly</span></div><div class="admin-table-scroll"><table><tr><th>Package</th><th>Trip Type</th><th>Route</th><th>Days</th><th>Offer</th><th>Status</th><th>Actions</th></tr><?php foreach($items as $x):?><tr><td><?php echo e($x['icon']).' '.e($x['name']);?></td><td><?php echo e($x['category_name']??'—');?></td><td><?php echo e($x['route']??'—');?></td><td><?php echo (int)$x['days'];?></td><td><?php echo packageOfferActive($x)?e(packageOfferLabel($x)):'—';?></td><td><span class="admin-status-badge admin-status-<?php echo e($x['status']);?>"><?php echo e(ucfirst($x['status']));?></span></td><td><a class="admin-action-link" href="?edit=<?php echo (int)$x['id'];?>">Edit</a><form method="POST" style="display:inline" onsubmit="return confirm('Delete this package?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo (int)$x['id'];?>"><button class="admin-delete-btn">Delete</button></form></td></tr><?php endforeach;?></table></div></div>
<?php include '../includes/admin-footer.php'; ?>