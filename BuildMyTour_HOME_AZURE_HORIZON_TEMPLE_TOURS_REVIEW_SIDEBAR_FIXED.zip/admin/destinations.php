<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Destinations';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'] ?? '';

    if ($action === 'add' || $action === 'edit') {
        $name = trim($_POST['name']);
        $state = trim($_POST['state']);
        $description = trim($_POST['description']);
        $image = trim($_POST['image']);
        $category = trim($_POST['category']);
        $distance_info = trim($_POST['distance_info']);
        $status = $_POST['status'] === 'inactive' ? 'inactive' : 'active';

        if ($action === 'add') {
            $stmt = $pdo->prepare("INSERT INTO destinations (name, state, description, image, category, distance_info, status) VALUES (?,?,?,?,?,?,?)");
            $stmt->execute([$name, $state, $description, $image, $category, $distance_info, $status]);
        } else {
            $id = (int)$_POST['id'];
            $stmt = $pdo->prepare("UPDATE destinations SET name=?, state=?, description=?, image=?, category=?, distance_info=?, status=? WHERE id=?");
            $stmt->execute([$name, $state, $description, $image, $category, $distance_info, $status, $id]);
        }
    }

    if ($action === 'delete') {
        $id = (int)$_POST['id'];
        $stmt = $pdo->prepare("DELETE FROM destinations WHERE id = ?");
        $stmt->execute([$id]);
    }

    header("Location: destinations.php");
    exit;
}

$editItem = null;
if (!empty($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM destinations WHERE id = ?");
    $stmt->execute([(int)$_GET['edit']]);
    $editItem = $stmt->fetch();
}

$destinations = $pdo->query("SELECT * FROM destinations ORDER BY id DESC")->fetchAll();
include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div><h1>Destinations</h1><p>Manage travel destinations available on BuildMyTour.</p></div>
    <div class="admin-page-meta">Admin Panel</div>
</div>

<div class="admin-form-card">
    <h3><?php echo $editItem ? 'Edit Destination' : 'Add New Destination'; ?></h3>
    <form method="POST" action="destinations.php">
        <input type="hidden" name="action" value="<?php echo $editItem ? 'edit' : 'add'; ?>">
        <?php if ($editItem): ?><input type="hidden" name="id" value="<?php echo $editItem['id']; ?>"><?php endif; ?>
        <div class="form-row">
            <div class="form-group"><label>Name</label><input type="text" name="name" class="form-control" value="<?php echo e($editItem['name'] ?? ''); ?>" required></div>
            <div class="form-group"><label>State</label><input type="text" name="state" class="form-control" value="<?php echo e($editItem['state'] ?? ''); ?>" required></div>
        </div>
        <div class="form-group"><label>Description</label><textarea name="description" class="form-control" rows="2"><?php echo e($editItem['description'] ?? ''); ?></textarea></div>
        <div class="form-row">
            <div class="form-group"><label>Image Path</label><input type="text" name="image" class="form-control" value="<?php echo e($editItem['image'] ?? 'assets/images/placeholder.jpg'); ?>"></div>
            <div class="form-group"><label>Category</label><input type="text" name="category" class="form-control" value="<?php echo e($editItem['category'] ?? ''); ?>"></div>
        </div>
        <div class="form-row">
            <div class="form-group"><label>Distance Info</label><input type="text" name="distance_info" class="form-control" value="<?php echo e($editItem['distance_info'] ?? ''); ?>"></div>
            <div class="form-group"><label>Status</label>
                <select name="status" class="form-control">
                    <option value="active" <?php echo (($editItem['status'] ?? 'active') === 'active') ? 'selected' : ''; ?>>Active</option>
                    <option value="inactive" <?php echo (($editItem['status'] ?? '') === 'inactive') ? 'selected' : ''; ?>>Inactive</option>
                </select>
            </div>
        </div>
        <button type="submit" class="btn btn-primary"><?php echo $editItem ? 'Update' : 'Add'; ?> Destination</button>
        <?php if ($editItem): ?><a href="destinations.php" class="btn btn-outline">Cancel</a><?php endif; ?>
    </form>
</div>

<div class="admin-table-card">
    <div class="admin-table-card-head"><h2>Destination records</h2><span>Latest data</span></div>
    <div class="admin-table-scroll">
    <table>
    <tr><th>ID</th><th>Name</th><th>State</th><th>Category</th><th>Status</th><th>Actions</th></tr>
    <?php foreach ($destinations as $d): ?>
    <tr>
        <td><?php echo $d['id']; ?></td>
        <td><?php echo e($d['name']); ?></td>
        <td><?php echo e($d['state']); ?></td>
        <td><?php echo e($d['category']); ?></td>
        <td><span class="admin-status-badge admin-status-<?php echo e($d['status']); ?>"><?php echo ucfirst(e($d['status'])); ?></span></td>
        <td class="admin-actions">
            <a class="admin-action-link" href="destinations.php?edit=<?php echo $d['id']; ?>">Edit</a>
            <form method="POST" action="destinations.php" style="display:inline;" onsubmit="return confirm('Delete this destination?');">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" value="<?php echo $d['id']; ?>">
                <button type="submit" class="admin-delete-btn">Delete</button>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
    </div>
</div>

<?php include '../includes/admin-footer.php'; ?>
