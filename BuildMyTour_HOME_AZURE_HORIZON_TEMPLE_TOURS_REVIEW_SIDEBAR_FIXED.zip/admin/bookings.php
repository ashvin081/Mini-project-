<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle = 'Trips & Bookings';

// Admin can keep a booking Pending or change it to Confirmed / Cancelled.
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $bookingId = (int)($_POST['booking_id'] ?? 0);
    $status = $_POST['booking_status'] ?? '';
    $allowed = ['pending', 'confirmed', 'completed', 'cancelled'];

    if ($bookingId > 0 && in_array($status, $allowed, true)) {
        // bookings is the source of truth for booking operations.
        $stmt = $pdo->prepare("SELECT trip_id FROM bookings WHERE id = ? LIMIT 1");
        $stmt->execute([$bookingId]);
        $tripId = (int)$stmt->fetchColumn();

        if ($tripId > 0) {
            $stmt = $pdo->prepare("UPDATE bookings SET booking_status = ? WHERE id = ?");
            $stmt->execute([$status, $bookingId]);

            // Keep the trip record synchronized for My Bookings / confirmation pages.
            $tripStatus = $status === 'completed' ? 'completed' : ($status === 'cancelled' ? 'planned' : 'booked');
            $stmt = $pdo->prepare("UPDATE trips SET booking_status = ?, status = ? WHERE id = ?");
            $stmt->execute([$status, $tripStatus, $tripId]);

            flash('success', 'Booking status updated to ' . ucfirst($status) . '.');
        }
    }

    header('Location: bookings.php');
    exit;
}

$bookings = $pdo->query("SELECT b.*, t.destination, t.start_date, t.end_date, u.name AS user_name, u.email FROM bookings b JOIN trips t ON t.id = b.trip_id JOIN users u ON u.id = b.user_id ORDER BY CASE b.booking_status WHEN 'pending' THEN 0 WHEN 'confirmed' THEN 1 WHEN 'completed' THEN 2 ELSE 3 END, b.booking_date DESC")->fetchAll();
$successMsg = flash('success');
include '../includes/admin-header.php';
?>

<div class="admin-page-header">
    <div><h1>Trips & Booking Management</h1><p>Review planned trips, booking requests and update their booking status.</p></div>
    <div class="admin-page-meta">Admin Panel</div>
</div>
<?php if ($successMsg): ?><div class="alert alert-success admin-alert"><?php echo e($successMsg); ?></div><?php endif; ?>

<div class="admin-table-card">
    <div class="admin-table-card-head"><h2>All booking requests</h2><span>Latest data</span></div>
    <div class="admin-table-scroll">
    <table>
    <tr><th>ID</th><th>User</th><th>Destination</th><th>Dates</th><th>Amount</th><th>Payment</th><th>Status</th></tr>
    <?php foreach ($bookings as $b): ?>
    <tr>
        <td><?php echo (int)$b['id']; ?></td>
        <td><?php echo e($b['user_name']); ?><br><small><?php echo e($b['email']); ?></small></td>
        <td><?php echo e($b['destination']); ?></td>
        <td><?php echo date('d M', strtotime($b['start_date'])); ?> – <?php echo date('d M Y', strtotime($b['end_date'])); ?></td>
        <td><?php echo formatMoney($b['amount']); ?></td>
        <td><?php echo e($b['payment_method']); ?> (<?php echo e($b['payment_status']); ?>)</td>
        <td>
            <form method="POST" class="booking-status-select-form">
                <input type="hidden" name="booking_id" value="<?php echo (int)$b['id']; ?>">
                <select name="booking_status" class="booking-status-select status-<?php echo e($b['booking_status']); ?>" aria-label="Booking status" onchange="this.form.submit()">
                    <option value="pending" <?php echo $b['booking_status'] === 'pending' ? 'selected' : ''; ?>>Pending</option>
                    <option value="confirmed" <?php echo $b['booking_status'] === 'confirmed' ? 'selected' : ''; ?>>Confirmed</option>
                    <option value="completed" <?php echo $b['booking_status'] === 'completed' ? 'selected' : ''; ?>>Completed</option>
                    <option value="cancelled" <?php echo $b['booking_status'] === 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                </select>
            </form>
        </td>
    </tr>
    <?php endforeach; ?>
</table>
    </div>
</div>

<?php include '../includes/admin-footer.php'; ?>
