<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle='Admin Dashboard';

$stats=[
 'users'=>(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='user'")->fetchColumn(),
 'packages'=>(int)$pdo->query("SELECT COUNT(*) FROM tour_packages WHERE status='active'")->fetchColumn(),
 'trips'=>(int)$pdo->query("SELECT COUNT(*) FROM trips")->fetchColumn(),
 'bookings'=>(int)$pdo->query("SELECT COUNT(*) FROM bookings WHERE booking_status IN ('pending','confirmed')")->fetchColumn(),
 'reviews'=>(int)$pdo->query("SELECT COUNT(*) FROM reviews WHERE status='pending'")->fetchColumn(),
];

$recent=$pdo->query("SELECT b.*,u.name user_name,t.destination FROM bookings b JOIN users u ON u.id=b.user_id JOIN trips t ON t.id=b.trip_id ORDER BY b.booking_date DESC LIMIT 8")->fetchAll();

include '../includes/admin-header.php';
?>

<div class="admin-dashboard-hero">
    <div>
        <div class="admin-eyebrow"><span>✦</span> SMART TRAVEL OPERATIONS</div>
        <h1>Smart Planner Dashboard</h1>
        <p>Manage the complete BuildMyTour journey — from trip discovery to booking and reviews.</p>
    </div>
    <div class="admin-dashboard-meta">
        <span class="admin-meta-dot"></span>
        <div><strong>System Ready</strong><small>8-table database connected</small></div>
    </div>
</div>

<div class="admin-stats-grid four admin-dashboard-stats">
    <a class="admin-stat-card dashboard-stat-users" href="users.php">
        <div class="admin-stat-top"><span class="admin-stat-icon">👥</span><span class="admin-stat-arrow">↗</span></div>
        <div class="admin-stat-value"><?php echo $stats['users']; ?></div>
        <p class="admin-stat-label">Registered Users</p>
    </a>
    <a class="admin-stat-card dashboard-stat-packages" href="tour-packages.php">
        <div class="admin-stat-top"><span class="admin-stat-icon">🧳</span><span class="admin-stat-arrow">↗</span></div>
        <div class="admin-stat-value"><?php echo $stats['packages']; ?></div>
        <p class="admin-stat-label">Active Smart Packages</p>
    </a>
    <a class="admin-stat-card dashboard-stat-trips" href="trip-types.php">
        <div class="admin-stat-top"><span class="admin-stat-icon">🧠</span><span class="admin-stat-arrow">↗</span></div>
        <div class="admin-stat-value"><?php echo $stats['trips']; ?></div>
        <p class="admin-stat-label">Trips Planned</p>
    </a>
    <a class="admin-stat-card dashboard-stat-bookings" href="bookings.php">
        <div class="admin-stat-top"><span class="admin-stat-icon">📅</span><span class="admin-stat-arrow">↗</span></div>
        <div class="admin-stat-value"><?php echo $stats['bookings']; ?></div>
        <p class="admin-stat-label">Active Bookings</p>
    </a>
</div>

<div class="admin-dashboard-two-col">
    <section class="admin-panel-card admin-flow-card">
        <div class="admin-section-head">
            <div><span class="admin-section-kicker">CONTROL CENTER</span><h2>Smart Planner Flow</h2></div>
            <span class="admin-live-badge">● Live</span>
        </div>
        <p class="admin-flow-description">Control the content and operations behind every smart trip recommendation.</p>
        <div class="admin-flow-steps">
            <a href="trip-types.php" class="admin-flow-step"><span class="flow-number">01</span><strong>Trip Type</strong><small>Explore · Culture · Temple</small></a>
            <span class="flow-chevron">›</span>
            <a href="tour-packages.php" class="admin-flow-step"><span class="flow-number">02</span><strong>Smart Packages</strong><small>Packages & offers</small></a>
            <span class="flow-chevron">›</span>
            <div class="admin-flow-step flow-step-options"><span class="flow-number">03</span><strong>Smart Options</strong><small>Saver · Balance · Premium</small></div>
            <span class="flow-chevron">›</span>
            <div class="admin-flow-step"><span class="flow-number">04</span><strong>Customize</strong><small>Build the final plan</small></div>
            <span class="flow-chevron">›</span>
            <a href="bookings.php" class="admin-flow-step"><span class="flow-number">05</span><strong>Booking</strong><small>Payment & status</small></a>
            <span class="flow-chevron">›</span>
            <a href="reviews.php" class="admin-flow-step"><span class="flow-number">06</span><strong>Reviews</strong><small><?php echo $stats['reviews']; ?> pending</small></a>
        </div>
    </section>

    <section class="admin-panel-card admin-actions-card">
        <div class="admin-section-head"><div><span class="admin-section-kicker">QUICK ACCESS</span><h2>Manage Content</h2></div></div>
        <div class="admin-quick-grid">
            <a href="trip-types.php" class="admin-quick-action"><span>✦</span><div><strong>Trip Types</strong><small>Manage categories</small></div><b>›</b></a>
            <a href="destinations.php" class="admin-quick-action"><span>⌖</span><div><strong>Destinations</strong><small>Manage locations</small></div><b>›</b></a>
            <a href="tour-packages.php" class="admin-quick-action"><span>◈</span><div><strong>Packages & Offers</strong><small>Update smart packages</small></div><b>›</b></a>
            <a href="reviews.php" class="admin-quick-action"><span>★</span><div><strong>Reviews</strong><small>Approve traveler feedback</small></div><b><?php echo $stats['reviews']; ?></b></a>
        </div>
    </section>
</div>

<section class="admin-table-card admin-dashboard-recent">
    <div class="admin-table-card-head">
        <div><span class="admin-section-kicker">BOOKING OPERATIONS</span><h2>Recent Bookings</h2></div>
        <a class="admin-table-view-all" href="bookings.php">View all bookings →</a>
    </div>
    <div class="admin-table-scroll">
        <table>
            <thead><tr><th>ID</th><th>Traveler</th><th>Package</th><th>Amount</th><th>Status</th></tr></thead>
            <tbody>
            <?php if (!$recent): ?>
                <tr><td colspan="5" class="admin-empty-cell">No bookings yet.</td></tr>
            <?php else: foreach($recent as $r):
                $status = strtolower((string)$r['booking_status']);
            ?>
                <tr>
                    <td><strong class="admin-reference">#<?php echo (int)$r['id']; ?></strong></td>
                    <td><?php echo e($r['user_name']); ?></td>
                    <td><span class="admin-package-name"><?php echo e($r['destination']); ?></span></td>
                    <td><strong><?php echo formatMoney($r['amount']); ?></strong></td>
                    <td><span class="admin-status-badge admin-status-<?php echo e($status); ?>"><i></i><?php echo e(ucfirst($status)); ?></span></td>
                </tr>
            <?php endforeach; endif; ?>
            </tbody>
        </table>
    </div>
</section>

<div class="admin-dashboard-footer-note">
    <span>BuildMyTour Smart Planner</span>
    <span>Trip Types → Packages → Smart Options → Customize → Booking → Reviews</span>
</div>

<?php include '../includes/admin-footer.php'; ?>
