-- BuildMyTour - Final 8-Table Database Schema
-- Smart Travel Planning and Booking System
--
-- Tables (exactly 8):
-- 1 users
-- 2 trip_categories
-- 3 destinations
-- 4 tour_packages
-- 5 package_variants
-- 6 trips
-- 7 bookings
-- 8 reviews

CREATE DATABASE IF NOT EXISTS buildmytour
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;
USE buildmytour;

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS reviews;
DROP TABLE IF EXISTS bookings;
DROP TABLE IF EXISTS trips;
DROP TABLE IF EXISTS package_variants;
DROP TABLE IF EXISTS tour_packages;
DROP TABLE IF EXISTS destinations;
DROP TABLE IF EXISTS trip_categories;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL UNIQUE,
    phone VARCHAR(20) DEFAULT NULL,
    password VARCHAR(255) NOT NULL,
    role ENUM('user','admin') NOT NULL DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. TRIP CATEGORIES
CREATE TABLE trip_categories (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    icon VARCHAR(20) DEFAULT '✈️',
    description VARCHAR(255) DEFAULT NULL,
    image VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. DESTINATIONS
CREATE TABLE destinations (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    state VARCHAR(100) NOT NULL,
    description TEXT,
    image VARCHAR(255) DEFAULT NULL,
    category VARCHAR(100) DEFAULT NULL,
    distance_info VARCHAR(255) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. TOUR PACKAGES
CREATE TABLE tour_packages (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category_id INT DEFAULT NULL,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    duration VARCHAR(50),
    days INT NOT NULL DEFAULT 1,
    icon VARCHAR(20) DEFAULT '✈️',
    route VARCHAR(500) DEFAULT NULL,
    price DECIMAL(10,2) NOT NULL DEFAULT 0,
    image VARCHAR(255) DEFAULT NULL,
    offer_percentage DECIMAL(5,2) NOT NULL DEFAULT 0,
    offer_start_date DATE DEFAULT NULL,
    offer_end_date DATE DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    FOREIGN KEY (category_id) REFERENCES trip_categories(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. PACKAGE VARIANTS
-- Internal keys are kept for application compatibility.
-- The user-facing labels are Smart Saver / Best Balance / Premium Experience.
CREATE TABLE package_variants (
    id INT AUTO_INCREMENT PRIMARY KEY,
    package_id INT NOT NULL,
    variant_key ENUM('Budget','Recommended','Premium') NOT NULL,
    name VARCHAR(150) NOT NULL,
    price_per_person DECIMAL(10,2) NOT NULL,
    tag VARCHAR(20) DEFAULT NULL,
    status ENUM('active','inactive') NOT NULL DEFAULT 'active',
    UNIQUE KEY uq_package_variant (package_id, variant_key),
    FOREIGN KEY (package_id) REFERENCES tour_packages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. TRIPS
CREATE TABLE trips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    package_id INT DEFAULT NULL,
    variant_id INT DEFAULT NULL,
    start_location VARCHAR(100) NOT NULL,
    destination VARCHAR(150) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    days INT NOT NULL,
    travelers INT NOT NULL,
    budget DECIMAL(10,2) NOT NULL,
    travel_style ENUM('Budget','Standard','Luxury') NOT NULL DEFAULT 'Standard',
    interests VARCHAR(255) DEFAULT NULL,
    transport_preference VARCHAR(50) DEFAULT NULL,
    estimated_distance VARCHAR(500) DEFAULT NULL,
    estimated_cost DECIMAL(10,2) NOT NULL DEFAULT 0,
    customization_json LONGTEXT DEFAULT NULL,
    selected_transport_id INT DEFAULT NULL,
    selected_hotel_id INT DEFAULT NULL,
    selected_activity_ids VARCHAR(255) DEFAULT NULL,
    booking_reference VARCHAR(50) DEFAULT NULL UNIQUE,
    total_amount DECIMAL(10,2) DEFAULT NULL,
    payment_method ENUM('UPI','Card','Net Banking') DEFAULT NULL,
    transaction_id VARCHAR(100) DEFAULT NULL,
    payment_status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
    booking_status ENUM('not_booked','pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'not_booked',
    rating TINYINT DEFAULT NULL,
    review_comment TEXT,
    review_status ENUM('not_reviewed','pending','approved','rejected') NOT NULL DEFAULT 'not_reviewed',
    reviewed_at TIMESTAMP NULL DEFAULT NULL,
    status ENUM('planned','booked','completed','cancelled') NOT NULL DEFAULT 'planned',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES tour_packages(id) ON DELETE SET NULL,
    FOREIGN KEY (variant_id) REFERENCES package_variants(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. BOOKINGS
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    trip_id INT NOT NULL,
    user_id INT NOT NULL,
    booking_reference VARCHAR(50) NOT NULL UNIQUE,
    booking_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    amount DECIMAL(10,2) NOT NULL,
    booking_status ENUM('pending','confirmed','completed','cancelled') NOT NULL DEFAULT 'pending',
    payment_method ENUM('UPI','Card','Net Banking') DEFAULT NULL,
    payment_status ENUM('pending','success','failed') NOT NULL DEFAULT 'pending',
    payment_reference VARCHAR(100) DEFAULT NULL,
    FOREIGN KEY (trip_id) REFERENCES trips(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. REVIEWS
CREATE TABLE reviews (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NOT NULL,
    package_id INT NOT NULL,
    rating TINYINT NOT NULL,
    comment TEXT,
    status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (package_id) REFERENCES tour_packages(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =====================================================
-- DEMO DATA
-- =====================================================

-- Admin login: admin@buildmytour.com / admin123
INSERT INTO users (name, email, phone, password, role) VALUES
('Admin', 'admin@buildmytour.com', NULL,
 '$2y$12$03m3wAMfw2dorevPiyy4gOFXGOE0r218QE6GQVe2HrfH7UkEQDxG6', 'admin');

INSERT INTO trip_categories (name, icon, description, image, status) VALUES
('Explore & Adventure', '🏔️', 'Explore nature, wildlife and thrilling adventures', 'assets/images/trip-types/adventure-nature.jpg', 'active'),
('Culture & Heritage', '🏰', 'Discover India''s culture, history and iconic destinations', 'assets/images/trip-types/culture-heritage.jpg', 'active'),
('Temple Tours', '🛕', 'Discover sacred temples, ancient traditions and meaningful journeys', 'assets/images/trip-types/adventure-spiritual.jpg', 'active');

INSERT INTO destinations (name, state, description, image, category, distance_info, status) VALUES
('Leh', 'Ladakh', 'High-altitude Himalayan capital and gateway to Ladakh.', 'assets/images/destinations/leh.jpg', 'Adventure', 'Package route destination', 'active'),
('Nubra Valley', 'Ladakh', 'Scenic valley with mountains and desert landscapes.', 'assets/images/destinations/nubra-valley.jpg', 'Adventure', 'Package route destination', 'active'),
('Pangong Lake', 'Ladakh', 'Famous high-altitude lake with dramatic mountain views.', 'assets/images/destinations/leh.jpg', 'Nature', 'Package route destination', 'active'),
('Jaipur', 'Rajasthan', 'Pink City known for forts and royal heritage.', 'assets/images/destinations/jaipur.jpg', 'Heritage', 'Package route destination', 'active'),
('Udaipur', 'Rajasthan', 'City of Lakes with palaces and scenic views.', 'assets/images/destinations/udaipur.jpg', 'Heritage', 'Package route destination', 'active'),
('Jaisalmer', 'Rajasthan', 'Golden desert city with forts and dunes.', 'assets/images/destinations/jaipur.jpg', 'Culture', 'Package route destination', 'active'),
('Ujjain', 'Madhya Pradesh', 'Ancient spiritual city known for Mahakaleshwar.', 'assets/images/destinations/dwarka.jpg', 'Spiritual', 'Package route destination', 'active'),
('Omkareshwar', 'Madhya Pradesh', 'Sacred island town and Jyotirlinga destination.', 'assets/images/destinations/dwarka.jpg', 'Spiritual', 'Package route destination', 'active'),
('Gir', 'Gujarat', 'Wildlife destination famous for Asiatic lions.', 'assets/images/destinations/ahmedabad.jpg', 'Wildlife', 'Package route destination', 'active'),
('Bhuj', 'Gujarat', 'Cultural gateway to Kutch.', 'assets/images/destinations/ahmedabad.jpg', 'Culture', 'Package route destination', 'active'),
('Dhordo', 'Gujarat', 'Gateway village to the White Rann.', 'assets/images/destinations/ahmedabad.jpg', 'Culture', 'Package route destination', 'active'),
('White Rann', 'Gujarat', 'Unique white salt desert landscape.', 'assets/images/destinations/ahmedabad.jpg', 'Nature', 'Package route destination', 'active'),
('Rishikesh', 'Uttarakhand', 'Adventure and spiritual destination on the Ganga.', 'assets/images/destinations/srinagar.jpg', 'Adventure', 'Package route destination', 'active');

INSERT INTO tour_packages (category_id, name, description, duration, days, icon, route, price, image, offer_percentage, status) VALUES
(1, 'Leh–Ladakh Adventure Expedition', 'Leh, Nubra Valley and Pangong Lake adventure journey.', '7 Days / 6 Nights', 7, '🏔️', 'Leh → Nubra Valley → Pangong Lake', 52000, 'assets/images/packages/leh-ladakh.jpg', 10, 'active'),
(2, 'Rajasthan Royal Heritage Journey', 'Jaipur, Udaipur and Jaisalmer royal heritage journey.', '7 Days / 6 Nights', 7, '🏰', 'Jaipur → Udaipur → Jaisalmer', 38000, 'assets/images/packages/rajasthan-royal.jpg', 15, 'active'),
(3, 'Ujjain–Omkareshwar Jyotirlinga Journey', 'Spiritual journey across Jyotirlinga destinations.', '4 Days / 3 Nights', 4, '🛕', 'Ujjain → Omkareshwar', 12000, 'assets/images/packages/ujjain-omkareshwar.jpg', 5, 'active'),
(1, 'Gir Wildlife Safari Adventure', 'Wildlife and safari experience in Gir.', '3 Days / 2 Nights', 3, '🐅', 'Gir', 15000, 'assets/images/packages/gir-wildlife.jpg', 10, 'active'),
(2, 'Kutch White Desert & Cultural Escape', 'White Rann, Dhordo and Kutch culture.', '4 Days / 3 Nights', 4, '🏜️', 'Bhuj → Dhordo → White Rann', 18000, 'assets/images/packages/kutch-white-desert.jpg', 12, 'active'),
(3, 'Rishikesh Adventure & Spiritual Escape', 'River adventure and spiritual experience.', '4 Days / 3 Nights', 4, '🧗', 'Rishikesh', 14000, 'assets/images/packages/rishikesh-adventure.jpg', 8, 'active');

INSERT INTO package_variants (package_id, variant_key, name, price_per_person, tag, status)
SELECT id, 'Budget', 'Smart Saver', 18000, '💰', 'active' FROM tour_packages WHERE name='Leh–Ladakh Adventure Expedition'
UNION ALL SELECT id, 'Recommended', 'Best Balance', 26000, '⚖️', 'active' FROM tour_packages WHERE name='Leh–Ladakh Adventure Expedition'
UNION ALL SELECT id, 'Premium', 'Premium Experience', 39000, '👑', 'active' FROM tour_packages WHERE name='Leh–Ladakh Adventure Expedition'
UNION ALL SELECT id, 'Budget', 'Smart Saver', 12000, '💰', 'active' FROM tour_packages WHERE name='Rajasthan Royal Heritage Journey'
UNION ALL SELECT id, 'Recommended', 'Best Balance', 19000, '⚖️', 'active' FROM tour_packages WHERE name='Rajasthan Royal Heritage Journey'
UNION ALL SELECT id, 'Premium', 'Premium Experience', 30000, '👑', 'active' FROM tour_packages WHERE name='Rajasthan Royal Heritage Journey'
UNION ALL SELECT id, 'Budget', 'Smart Saver', 6500, '💰', 'active' FROM tour_packages WHERE name='Ujjain–Omkareshwar Jyotirlinga Journey'
UNION ALL SELECT id, 'Recommended', 'Best Balance', 10000, '⚖️', 'active' FROM tour_packages WHERE name='Ujjain–Omkareshwar Jyotirlinga Journey'
UNION ALL SELECT id, 'Premium', 'Premium Experience', 16000, '👑', 'active' FROM tour_packages WHERE name='Ujjain–Omkareshwar Jyotirlinga Journey'
UNION ALL SELECT id, 'Budget', 'Smart Saver', 8000, '💰', 'active' FROM tour_packages WHERE name='Gir Wildlife Safari Adventure'
UNION ALL SELECT id, 'Recommended', 'Best Balance', 13000, '⚖️', 'active' FROM tour_packages WHERE name='Gir Wildlife Safari Adventure'
UNION ALL SELECT id, 'Premium', 'Premium Experience', 21000, '👑', 'active' FROM tour_packages WHERE name='Gir Wildlife Safari Adventure'
UNION ALL SELECT id, 'Budget', 'Smart Saver', 8500, '💰', 'active' FROM tour_packages WHERE name='Kutch White Desert & Cultural Escape'
UNION ALL SELECT id, 'Recommended', 'Best Balance', 14000, '⚖️', 'active' FROM tour_packages WHERE name='Kutch White Desert & Cultural Escape'
UNION ALL SELECT id, 'Premium', 'Premium Experience', 23000, '👑', 'active' FROM tour_packages WHERE name='Kutch White Desert & Cultural Escape'
UNION ALL SELECT id, 'Budget', 'Smart Saver', 7000, '💰', 'active' FROM tour_packages WHERE name='Rishikesh Adventure & Spiritual Escape'
UNION ALL SELECT id, 'Recommended', 'Best Balance', 11500, '⚖️', 'active' FROM tour_packages WHERE name='Rishikesh Adventure & Spiritual Escape'
UNION ALL SELECT id, 'Premium', 'Premium Experience', 18500, '👑', 'active' FROM tour_packages WHERE name='Rishikesh Adventure & Spiritual Escape';
