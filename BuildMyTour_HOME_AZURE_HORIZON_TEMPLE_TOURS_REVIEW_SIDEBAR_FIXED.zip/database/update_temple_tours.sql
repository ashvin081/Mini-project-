-- BuildMyTour: Rename Trip Type from Spiritual Journeys to Temple Tours
-- Run this once if an existing buildmytour database is already installed.
USE buildmytour;

UPDATE trip_categories
SET name = 'Temple Tours',
    description = 'Discover sacred temples, ancient traditions and meaningful journeys',
    icon = '🛕'
WHERE name = 'Spiritual Journeys';

-- Keep the existing package/category relationships unchanged.
