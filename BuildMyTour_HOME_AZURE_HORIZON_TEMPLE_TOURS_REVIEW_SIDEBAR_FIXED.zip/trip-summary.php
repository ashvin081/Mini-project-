<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__ . '/config/database.php';
requireLogin();
$pageTitle = 'Smart Trip Summary';

$tripId = (int)($_GET['trip_id'] ?? 0);
$stmt = $pdo->prepare('SELECT * FROM trips WHERE id = ? AND user_id = ?');
$stmt->execute([$tripId, currentUserId()]);
$trip = $stmt->fetch();
if (!$trip) { header('Location: ai-planner.php'); exit; }

$sel = $_SESSION['selection'][$tripId] ?? [];
$packageName = $sel['package_name'] ?? $trip['destination'];
$package = getTourPackage($pdo, $packageName);
if (!$package) { header('Location: ai-planner.php'); exit; }

$variant = $sel['package_variant'] ?? 'Recommended';
$variantData = $package['variants'][$variant] ?? reset($package['variants']);
$travelers = max(1, (int)$trip['travelers']);
$baseTotal = (float)($sel['base_package_total'] ?? (variantOfferPrice($variantData, $package) * $travelers));
$baseOriginalTotal = (float)($sel['base_package_original_total'] ?? ((float)$variantData['price_per_person'] * $travelers));
$offerDiscount = (float)($sel['offer_discount'] ?? max(0, $baseOriginalTotal - $baseTotal));
$transportTotal = (float)($sel['transport_total'] ?? 0);
$hotelTotal = (float)($sel['hotel_total'] ?? 0);
$activityTotal = (float)($sel['activity_total'] ?? 0);
$totalCost = (float)($sel['total_cost'] ?? ($baseTotal + $transportTotal + $hotelTotal + $activityTotal));
$budget = (float)$trip['budget'];
$withinBudget = $totalCost <= $budget;
$_SESSION['selection'][$tripId]['total_cost'] = $totalCost;
$_SESSION['selection'][$tripId]['budget_status'] = $withinBudget ? 'within_budget' : 'over_budget';
$pdo->prepare('UPDATE trips SET estimated_cost = ? WHERE id = ? AND user_id = ?')->execute([$totalCost, $tripId, currentUserId()]);

$transport = null; $hotel = null; $activities = [];
$custom = [];
if (!empty($trip['customization_json'])) $custom = json_decode($trip['customization_json'], true) ?: [];
$options = getCustomizationOptions(getTripRoute($trip, $pdo));
$transportId = (int)($sel['transport_id'] ?? $custom['transport_id'] ?? 0);
$hotelId = (int)($sel['hotel_id'] ?? $custom['hotel_id'] ?? 0);
$activityIds = array_map('intval', $sel['activity_ids'] ?? $custom['activity_ids'] ?? []);
foreach($options['transport'] as $x) if((int)$x['id']===$transportId) $transport=$x;
foreach($options['hotels'] as $x) if((int)$x['id']===$hotelId) $hotel=$x;
foreach($options['activities'] as $x) if(in_array((int)$x['id'],$activityIds,true)) $activities[]=$x;
$optionMeta = getSmartOptionMeta($variant);
$badge = $optionMeta['tag'];
$variantLabel = $optionMeta['label'];
include 'includes/header.php';
?>
<div class="container py-4 py-md-5">
  <div class="page-header">
    <span class="summary-eyebrow">SMART TRIP PLANNER</span>
    <h1>Your Final Smart Trip ✨</h1>
    <p>Everything is in one place. Review your customized package, budget and final amount before booking.</p>
  </div>

  <?php if (!$withinBudget): ?>
    <div class="alert alert-danger border-0 shadow-sm"><strong>⚠️ Budget exceeded.</strong> Your customized trip is <?php echo formatMoney($totalCost-$budget); ?> over your budget. <a href="customize-trip.php?trip_id=<?php echo $tripId; ?>" class="alert-link">Customize again</a> to reduce the total.</div>
  <?php else: ?>
    <div class="alert alert-success border-0 shadow-sm"><strong>✅ Smart budget match.</strong> You are within budget by <?php echo formatMoney($budget-$totalCost); ?>.</div>
  <?php endif; ?>

  <section class="card border-0 shadow-sm mb-4 smart-summary-hero"><div class="card-body p-4 p-md-5">
    <div class="d-flex flex-wrap justify-content-between align-items-start gap-3">
      <div>
        <div class="text-muted small mb-2">SELECTED TOUR PACKAGE</div>
        <h2 class="mb-2"><?php echo e($package['icon'].' '.$packageName); ?></h2>
        <p class="mb-2 text-muted"><?php echo e(implode(' → ', $package['cities'])); ?></p>
        <span class="badge text-bg-primary"><?php echo e($package['category']); ?></span>
      </div>
      <div class="text-md-end">
        <div class="fs-5"><?php echo $badge; ?> <strong><?php echo e($variantLabel); ?></strong></div>
        <div class="text-muted"><?php echo e($variantData['name']); ?></div>
        <div class="fs-2 fw-bold mt-2"><?php echo formatMoney($totalCost); ?></div>
        <?php if($offerDiscount>0): ?><div class="text-success fw-semibold">🔥 Offer saved <?php echo formatMoney($offerDiscount); ?></div><?php endif; ?>
        <small class="text-muted">Final total for <?php echo $travelers; ?> traveler(s)</small>
      </div>
    </div>
    <hr>
    <div class="row text-center g-3">
      <div class="col-6 col-md-3"><strong>📅 <?php echo (int)$trip['days']; ?> Days</strong><br><small class="text-muted">Duration</small></div>
      <div class="col-6 col-md-3"><strong>👥 <?php echo $travelers; ?></strong><br><small class="text-muted">Travelers</small></div>
      <div class="col-6 col-md-3"><strong>🗓️ <?php echo date('d M Y', strtotime($trip['start_date'])); ?></strong><br><small class="text-muted">Start Date</small></div>
      <div class="col-6 col-md-3"><strong>💰 <?php echo formatMoney($budget); ?></strong><br><small class="text-muted">Your Budget</small></div>
    </div>
  </div></section>

  <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
    <div class="d-flex justify-content-between align-items-center mb-3"><div><div class="text-muted small">CUSTOMIZED DETAILS</div><h3 class="mb-0">What is included</h3></div><a href="customize-trip.php?trip_id=<?php echo $tripId; ?>" class="btn btn-outline-primary">✏️ Customize</a></div>
    <div class="row g-3">
      <div class="col-lg-3 col-md-6"><div class="border rounded-3 p-3 h-100"><div class="text-muted small">PACKAGE</div><?php if($offerDiscount>0): ?><div class="small text-muted"><del><?php echo formatMoney($baseOriginalTotal); ?></del> · 🔥 <?php echo (int)($package['offer_percentage']??0); ?>% OFF</div><?php endif; ?><strong><?php echo formatMoney($baseTotal); ?></strong><div class="small text-muted">Selected <?php echo e($variantLabel); ?> level</div></div></div>
      <div class="col-lg-3 col-md-6"><div class="border rounded-3 p-3 h-100"><div class="text-muted small">TRANSPORT</div><strong><?php echo e($transport['type'] ?? 'Not selected'); ?></strong><div class="small text-muted"><?php echo formatMoney($transportTotal); ?></div></div></div>
      <div class="col-lg-3 col-md-6"><div class="border rounded-3 p-3 h-100"><div class="text-muted small">HOTEL</div><strong><?php echo e($hotel['name'] ?? 'Not selected'); ?></strong><div class="small text-muted"><?php echo formatMoney($hotelTotal); ?> total stay</div></div></div>
      <div class="col-lg-3 col-md-6"><div class="border rounded-3 p-3 h-100"><div class="text-muted small">ACTIVITIES</div><strong><?php echo count($activities); ?> Selected</strong><div class="small text-muted"><?php echo formatMoney($activityTotal); ?> total</div></div></div>
    </div>
  </div></section>

  <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
    <h3>Selected Experiences</h3>
    <div class="row g-3 mt-1">
      <?php foreach ($activities as $a): ?><div class="col-md-6"><div class="border rounded-3 p-3"><strong>✓ <?php echo e($a['name']); ?></strong><div class="small text-muted"><?php echo e($a['dest_name']); ?> · <?php echo formatMoney((float)$a['price'] * $travelers); ?></div></div></div><?php endforeach; ?>
      <?php if (!$activities): ?><div class="col-12 text-muted">No optional activities added.</div><?php endif; ?>
    </div>
  </div></section>

  <?php $reviews = getPackageReviews($pdo, $packageName); ?>
  <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
    <div class="d-flex justify-content-between align-items-center mb-3"><div><div class="text-muted small">TRAVELER FEEDBACK</div><h3 class="mb-0">What travelers say</h3></div></div>
    <?php if($reviews): ?><div class="row g-3"><?php foreach($reviews as $r): ?><div class="col-md-6"><div class="border rounded-3 p-3 h-100"><div class="fw-semibold"><?php echo str_repeat('★',(int)$r['rating']); ?><span class="text-muted"> (<?php echo (int)$r['rating']; ?>/5)</span></div><p class="mb-0 mt-2">“<?php echo e($r['review_comment']); ?>”</p></div></div><?php endforeach; ?></div><?php else: ?><p class="text-muted mb-0">No approved reviews yet. Be the first traveler to share your experience after completing this trip.</p><?php endif; ?>
  </div></section>

  <?php if (!$withinBudget): ?>
  <section class="card border-0 shadow-sm mb-4 budget-alert-card"><div class="card-body p-4">
    <h3>💡 Smart Budget Alternative</h3>
    <p class="mb-3">Your customized trip is <?php echo formatMoney($totalCost-$budget); ?> over budget. Try a cheaper hotel/transport or remove an optional activity.</p>
    <a href="customize-trip.php?trip_id=<?php echo $tripId; ?>#budgetTips" class="btn btn-primary">✏️ Optimize My Budget</a>
  </div></section>
  <?php endif; ?>

  <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4 p-md-5">
    <div class="text-muted small">PRICE BREAKDOWN</div><h3 class="mb-3">What you pay</h3>
    <div class="price-breakdown">
      <div><span>Package (before offer)</span><strong><?php echo formatMoney($baseOriginalTotal); ?></strong></div>
      <?php if($offerDiscount>0): ?><div class="text-success"><span>Offer discount</span><strong>- <?php echo formatMoney($offerDiscount); ?></strong></div><?php endif; ?>
      <?php if($transportTotal>0): ?><div><span>Transport</span><strong><?php echo formatMoney($transportTotal); ?></strong></div><?php endif; ?>
      <?php if($hotelTotal>0): ?><div><span>Hotel</span><strong><?php echo formatMoney($hotelTotal); ?></strong></div><?php endif; ?>
      <?php if($activityTotal>0): ?><div><span>Activities</span><strong><?php echo formatMoney($activityTotal); ?></strong></div><?php endif; ?>
      <div class="total"><span>Final total</span><strong><?php echo formatMoney($totalCost); ?></strong></div>
    </div>
  </div></section>

  <section class="card border-0 shadow-sm"><div class="card-body p-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3">
      <div><div class="text-muted small">FINAL AMOUNT</div><h2 class="mb-0"><?php echo formatMoney($totalCost); ?></h2><small class="text-muted">Budget: <?php echo formatMoney($budget); ?></small></div>
      <div class="d-flex gap-2"><a href="customize-trip.php?trip_id=<?php echo $tripId; ?>" class="btn btn-outline-secondary">← Edit</a><?php if ($withinBudget): ?><a href="checkout.php?trip_id=<?php echo $tripId; ?>" class="btn btn-primary px-4">Continue to Booking →</a><?php else: ?><a href="customize-trip.php?trip_id=<?php echo $tripId; ?>" class="btn btn-danger px-4">Reduce Cost →</a><?php endif; ?></div>
    </div>
  </div></section>
</div>
<?php include 'includes/footer.php'; ?>
