# BuildMyTour

**Project Title:** Smart Travel Planning and Booking System  
**Website Name:** BuildMyTour  
**Technology:** HTML5, CSS3, JavaScript, Bootstrap 5, PHP, MySQL

## Final College Mini Project Scope

- User registration and login
- Separate admin login
- Destination management
- Tour packages with package offers
- Hotel, transport and activity management
- Package-based Smart Trip Planner
- 3 trip categories and 6 final India tour packages
- Smart Smart Saver / Best Balance / Premium Experience package versions
- Hotel, transport and activity customization after package selection
- Trip booking and payment simulation
- Admin booking approval and completion
- Completed-trip review with admin approval
- Exactly 8 database tables

## Database Tables

1. users
2. admins
3. destinations
4. tour_packages
5. hotels
6. transport
7. activities
8. trips

## Setup

1. Import `database/buildmytour.sql` in phpMyAdmin.
2. Update database credentials in `config/database.php` if required.
3. Place the project inside your local web server directory.
4. Open `index.php`.

### Demo Admin

- Email: `admin@buildmytour.com`
- Password: `admin123`

> For demonstration only, payment is simulated and no real payment gateway is used.

## Current Smart Planner Structure

The current project uses one consolidated Smart Trip Planner flow:
Trip Type → Tour Package → Trip Details → Smart Recommendation → Customize → Final Summary → Booking → Payment → Review.

The previous separate Transport, Hotel and Activities user-flow pages and obsolete SQL patch files have been removed. Transport, hotel and activity selection is handled only inside `customize-trip.php`.

## Current Smart Planner Structure

The current project uses one consolidated Smart Trip Planner flow:
Trip Type → Tour Package → Trip Details → Smart Recommendation → Customize → Final Summary → Booking → Payment → Review.

The previous separate Transport, Hotel and Activities user-flow pages and obsolete SQL patch files have been removed. Transport, hotel and activity selection is handled only inside `customize-trip.php`.


## Database-Driven Smart Trip Planner (Latest Update)

The Smart Trip Planner now uses the database as the single source of truth.

Admin changes now flow directly to the frontend:

Trip Types → `trip_categories`  
Smart Packages → `tour_packages`  
Smart Saver / Best Balance / Premium Experience → `package_variants`  
Package Route → `package_destinations` + `destinations`  
Offer / Status / Image → `tour_packages`

### Important
For a clean setup, import `database/buildmytour.sql` into phpMyAdmin so the new Smart Planner tables and seed data are created.

After importing, test:

1. Admin → Trip Types
2. Admin → Smart Packages & Offers
3. User → Smart Trip Planner

Changes to package category, route, variant price, offer, image and status are now reflected by the frontend from the same database.


## Final Database: Exactly 8 Tables

1. users
2. trip_categories
3. destinations
4. tour_packages
5. package_variants
6. trips
7. bookings
8. reviews

Hotels, transport and activities are lightweight application-level customization options, not separate database tables. Package route is stored directly in `tour_packages.route`.


## UI Theme

**Azure Horizon Theme:** Azure Blue + White + Deep Navy + Sunset Orange, applied globally across user and admin interfaces.
