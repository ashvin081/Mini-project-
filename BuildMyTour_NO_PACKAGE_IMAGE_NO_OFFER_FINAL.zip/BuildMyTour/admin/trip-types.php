<?php
require_once '../includes/auth.php';
require_once '../includes/functions.php';
require_once __DIR__ . '/../config/database.php';
requireAdmin();
$pageTitle='Trip Types';

if($_SERVER['REQUEST_METHOD']==='POST'){
    $action=$_POST['action']??'';
    try{
        if(in_array($action,['add','edit'],true)){
            $name=trim($_POST['name']??'');
            $description=trim($_POST['description']??'');
            $status=($_POST['status']??'active')==='inactive'?'inactive':'active';
            if($name==='') throw new RuntimeException('Trip type name is required.');
            if($action==='add'){
                $stmt=$pdo->prepare('INSERT INTO trip_categories(name,description,status) VALUES(?,?,?)');
                $stmt->execute([$name,$description,$status]);
                flash('success','Trip type added.');
            }else{
                $stmt=$pdo->prepare('UPDATE trip_categories SET name=?,description=?,status=? WHERE id=?');
                $stmt->execute([$name,$description,$status,(int)$_POST['id']]);
                flash('success','Trip type updated.');
            }
        }elseif($action==='delete'){
            $pdo->prepare('DELETE FROM trip_categories WHERE id=?')->execute([(int)$_POST['id']]);
            flash('success','Trip type deleted.');
        }
    }catch(Throwable $e){ flash('error','Trip type could not be saved. It may be linked to a tour package.'); }
    header('Location: trip-types.php'); exit;
}
$edit=null;
if(!empty($_GET['edit'])){$st=$pdo->prepare('SELECT * FROM trip_categories WHERE id=?');$st->execute([(int)$_GET['edit']]);$edit=$st->fetch();}
$items=$pdo->query("SELECT c.*,COUNT(p.id) package_count FROM trip_categories c LEFT JOIN tour_packages p ON p.category_id=c.id GROUP BY c.id ORDER BY c.id")->fetchAll();
include '../includes/admin-header.php';
?>
<div class="admin-page-header"><div><h1>Trip Types</h1><p>Categories used in Step 1 of the Smart Trip Planner.</p></div></div>
<div class="admin-form-card"><h3><?php echo $edit?'Edit Trip Type':'Add Trip Type'; ?></h3>
<form method="POST"><input type="hidden" name="action" value="<?php echo $edit?'edit':'add'; ?>"><?php if($edit):?><input type="hidden" name="id" value="<?php echo (int)$edit['id']; ?>"><?php endif;?>
<div class="form-row"><div class="form-group"><label>Name</label><input class="form-control" name="name" required value="<?php echo e($edit['name']??''); ?>"></div><div class="form-group"><label>Status</label><select class="form-control" name="status"><option value="active" <?php echo (($edit['status']??'active')==='active')?'selected':''; ?>>Active</option><option value="inactive" <?php echo (($edit['status']??'')==='inactive')?'selected':''; ?>>Inactive</option></select></div></div>
<div class="form-group"><label>Description</label><input class="form-control" name="description" value="<?php echo e($edit['description']??''); ?>"></div>
<button class="btn btn-primary"><?php echo $edit?'Update':'Add'; ?> Trip Type</button><?php if($edit):?><a class="btn btn-outline" href="trip-types.php">Cancel</a><?php endif;?></form></div>
<div class="admin-table-card"><div class="admin-table-card-head"><h2>Trip Types</h2><span>3 simple categories</span></div><div class="admin-table-scroll"><table><thead><tr><th>Name</th><th>Packages</th><th>Status</th><th>Actions</th></tr></thead><tbody><?php foreach($items as $x):?><tr><td><?php echo e($x['name']);?></td><td><?php echo (int)$x['package_count'];?></td><td><span class="admin-status-badge admin-status-<?php echo e($x['status']);?>"><?php echo e(ucfirst($x['status']));?></span></td><td class="admin-actions"><a class="admin-action-link" href="?edit=<?php echo (int)$x['id'];?>">Edit</a><form method="POST" style="display:inline" onsubmit="return confirm('Delete this trip type?');"><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?php echo (int)$x['id'];?>"><button class="admin-delete-btn">Delete</button></form></td></tr><?php endforeach;?></tbody></table></div></div>
<?php include '../includes/admin-footer.php'; ?>