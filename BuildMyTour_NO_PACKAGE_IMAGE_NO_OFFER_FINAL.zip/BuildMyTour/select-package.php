<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__.'/config/database.php';
requireLogin();

if($_SERVER['REQUEST_METHOD']!=='POST'){ header('Location: smart-trip-planner.php'); exit; }
$tripId=(int)($_POST['trip_id']??0); $packageId=(int)($_POST['package_id']??0); $userId=(int)currentUserId();
$stmt=$pdo->prepare('SELECT * FROM trips WHERE id=? AND user_id=? AND booking_status="not_booked"');
$stmt->execute([$tripId,$userId]); $trip=$stmt->fetch();
$package=$packageId?getTourPackage($pdo,$packageId):null;
if(!$trip||!$package||(int)$package['days']!==(int)$trip['days']){
    flash('error','Please select a valid package for this trip.'); header('Location: generated-tour-plan.php?trip_id='.$tripId); exit;
}
$category=(string)$package['category'];
// Keep the original planner trip type by verifying it against the stored generated plan.
$oldPlan=!empty($trip['generated_plan_json'])?json_decode($trip['generated_plan_json'],true):[];
$selectedCategory=(string)($oldPlan['package_category']??$category);
if($package['category']!==$selectedCategory){ flash('error','Please select a package from the selected trip type.'); header('Location: generated-tour-plan.php?trip_id='.$tripId); exit; }
$plan=buildGeneratedPackagePlan($package,$selectedCategory,(int)$trip['travelers'],(float)$trip['budget']);
$pdo->beginTransaction();
try{
  $u=$pdo->prepare('UPDATE trips SET package_id=?,destination=?,generated_plan_json=? WHERE id=? AND user_id=? AND booking_status="not_booked"');
  $u->execute([$package['id'],implode(' → ',$package['cities']),json_encode($plan,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES),$tripId,$userId]);
  $_SESSION['selection'][$tripId]=$plan; $pdo->commit();
  header('Location: generated-tour-plan.php?trip_id='.$tripId); exit;
}catch(Throwable $e){ if($pdo->inTransaction())$pdo->rollBack(); error_log('BuildMyTour select-package error: '.$e->getMessage()); flash('error','Package could not be selected. Please try again.'); header('Location: generated-tour-plan.php?trip_id='.$tripId); exit; }
