<?php
require_once 'includes/auth.php';
require_once 'includes/functions.php';
require_once __DIR__.'/config/database.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') { header('Location: smart-trip-planner.php'); exit; }

$userId = (int) currentUserId();
$category = trim($_POST['category'] ?? '');
$startDate = trim($_POST['start_date'] ?? '');
$duration = (int) ($_POST['duration_days'] ?? 0);
$travelers = (int) ($_POST['travelers'] ?? 0);
$budget = (float) ($_POST['budget'] ?? 0);

$allowedDurations = [3,4,7];
$allowedBudgets = [30000,50000,75000,100000,150000];
$categories = getTripCategories($pdo, true);

$validDate = $startDate !== '' && preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate) && strtotime($startDate) !== false && $startDate >= date('Y-m-d');
if (!isset($categories[$category]) || !in_array($duration, $allowedDurations, true) || !in_array((int)$budget, $allowedBudgets, true) || $travelers < 1 || $travelers > 10 || !$validDate) {
    flash('error', 'Please complete all trip details using the available options.');
    header('Location: smart-trip-planner.php'); exit;
}

$endDate = date('Y-m-d', strtotime($startDate . ' +' . ($duration - 1) . ' days'));
$packages = getTourPackages($pdo, true);
$candidates = [];
foreach ($packages as $package) {
    if ($package['category'] !== $category || (int)$package['days'] !== $duration) continue;
    $pricePerPerson = (float)$package['price'];
    $total = $pricePerPerson * $travelers;
    $candidates[] = ['package'=>$package, 'total'=>$total, 'within'=>$total <= $budget];
}

if (!$candidates) {
    flash('error', 'No active package matches that trip type and duration. Please select one of the available durations shown after choosing your trip type.');
    header('Location: smart-trip-planner.php'); exit;
}

// Always create the cheapest matching plan so the user can see the actual trip cost.
// If it is over budget, generated-tour-plan.php will clearly mark it as over budget
// and will not allow the user to continue to checkout.
usort($candidates, fn($a,$b) => $a['total'] <=> $b['total']);
$affordable = array_values(array_filter($candidates, fn($item) => $item['within']));
$chosen = $affordable[0] ?? $candidates[0];

$package = $chosen['package'];
$packageTotal = (float)$chosen['total'];
$generatedPlan = buildGeneratedPackagePlan($package, $category, $travelers, $budget);

try {
    $pdo->beginTransaction();
    $stmt = $pdo->prepare("INSERT INTO trips (user_id,package_id,destination,start_date,end_date,days,travelers,budget,generated_plan_json,status) VALUES (?,?,?,?,?,?,?,?,?, 'planned')");
    $stmt->execute([$userId,$package['id'],implode(' → ',$package['cities']),$startDate,$endDate,$duration,$travelers,$budget,json_encode($generatedPlan, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES)]);
    $tripId = (int)$pdo->lastInsertId();
    $_SESSION['selection'][$tripId] = $generatedPlan;
    $pdo->commit();
    header('Location: generated-tour-plan.php?trip_id='.$tripId); exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log('BuildMyTour generate-trip error: '.$e->getMessage());
    flash('error', 'Trip could not be generated. Please check that database/buildmytour.sql is imported.');
    header('Location: smart-trip-planner.php'); exit;
}
