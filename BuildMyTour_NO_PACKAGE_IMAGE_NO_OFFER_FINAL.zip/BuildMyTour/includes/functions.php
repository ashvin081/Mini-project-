<?php
/** Shared helpers for BuildMyTour. */
function e($str){ return htmlspecialchars((string)($str ?? ''), ENT_QUOTES, 'UTF-8'); }
function flash($key,$message=null){
    if($message!==null){ $_SESSION['flash'][$key]=$message; return null; }
    if(!empty($_SESSION['flash'][$key])){ $m=$_SESSION['flash'][$key]; unset($_SESSION['flash'][$key]); return $m; }
    return null;
}
function formatMoney($amount){ return '₹'.number_format((float)$amount,0); }
function getPackageReviews(PDO $pdo,$packageName){
    $s=$pdo->prepare("SELECT r.rating,r.comment AS review_comment,r.created_at FROM reviews r JOIN tour_packages p ON p.id=r.package_id WHERE p.name=? AND r.status='approved' AND TRIM(COALESCE(r.comment,''))<>'' ORDER BY r.created_at DESC LIMIT 6");
    $s->execute([$packageName]); return $s->fetchAll();
}
function getPackageReviewStats(PDO $pdo,$packageNames=[]){
    if(!$packageNames)return [];
    $ph=implode(',',array_fill(0,count($packageNames),'?'));
    $s=$pdo->prepare("SELECT p.name AS destination,COUNT(r.id) AS review_count,ROUND(AVG(r.rating),1) AS avg_rating FROM reviews r JOIN tour_packages p ON p.id=r.package_id WHERE p.name IN ($ph) AND r.status='approved' GROUP BY p.id,p.name");
    $s->execute(array_values($packageNames)); $out=[]; foreach($s->fetchAll() as $r)$out[$r['destination']]=$r; return $out;
}
function getTourPackages(PDO $pdo,$onlyActive=true){
    $where=$onlyActive?"WHERE p.status='active' AND (c.status='active' OR c.status IS NULL)":'';
    $rows=$pdo->query("SELECT p.*,c.name AS category FROM tour_packages p LEFT JOIN trip_categories c ON c.id=p.category_id $where ORDER BY p.id ASC")->fetchAll();
    $out=[];
    foreach($rows as $r){
        $r['id']=(int)$r['id']; $r['days']=(int)($r['days']?:1); $r['price']=(float)$r['price'];
        $r['cities']=array_values(array_filter(array_map('trim',preg_split('/\s*→\s*/u',trim((string)$r['route'])))));
        $out[$r['name']]=$r;
    }
    return $out;
}
function getTripCategories(PDO $pdo,$onlyActive=true){
    $rows=$pdo->query("SELECT * FROM trip_categories ".($onlyActive?"WHERE status='active' ":'')."ORDER BY id ASC")->fetchAll();
    $out=[]; foreach($rows as $r)$out[$r['name']]=['id'=>(int)$r['id'],'description'=>$r['description']?:'','status'=>$r['status']]; return $out;
}
function getTourPackage(PDO $pdo,$nameOrId){
    $packages=getTourPackages($pdo,true);
    if(is_numeric($nameOrId)){ foreach($packages as $p)if((int)$p['id']===(int)$nameOrId)return $p; return null; }
    return $packages[$nameOrId]??null;
}
function getPlanOptions(array $cities=[]){
    $destination=$cities[0]??'Your Destination'; $key=strtolower(trim($destination));
    $transportMap=[
      'leh'=>[['type'=>'Train/Coach','provider'=>'Ladakh Express Coach','from_location'=>'Your City','to_location'=>'Leh','price'=>2200,'image'=>'assets/images/packages/leh-ladakh/transport.jpg'],['type'=>'Private Cab','provider'=>'Ladakh Private Cab','from_location'=>'Leh','to_location'=>'Ladakh Route','price'=>3200,'image'=>'assets/images/packages/leh-ladakh/transport.jpg']],
      'jaipur'=>[['type'=>'Train','provider'=>'Rajasthan Express Train','from_location'=>'Your City','to_location'=>'Jaipur','price'=>1800,'image'=>'assets/images/packages/rajasthan-royal/transport.jpg'],['type'=>'Private Cab','provider'=>'Rajasthan Private Cab','from_location'=>'Jaipur','to_location'=>'Rajasthan Route','price'=>2800,'image'=>'assets/images/packages/rajasthan-royal/transport.jpg']],
      'ujjain'=>[['type'=>'Train','provider'=>'Ujjain Express Train','from_location'=>'Your City','to_location'=>'Ujjain','price'=>1500,'image'=>'assets/images/packages/ujjain-omkareshwar/transport.jpg'],['type'=>'Private Cab','provider'=>'Ujjain Private Cab','from_location'=>'Ujjain','to_location'=>'Omkareshwar','price'=>2400,'image'=>'assets/images/packages/ujjain-omkareshwar/transport.jpg']],
      'gir'=>[['type'=>'Train','provider'=>'Gir Express Train','from_location'=>'Your City','to_location'=>'Gir','price'=>2200,'image'=>'assets/images/packages/gir-wildlife/transport.jpg'],['type'=>'Private Cab','provider'=>'Gir Safari Cab','from_location'=>'Gir','to_location'=>'Sasan Gir','price'=>3800,'image'=>'assets/images/packages/gir-wildlife/transport.jpg']],
      'bhuj'=>[['type'=>'Train','provider'=>'Kutch Express Train','from_location'=>'Your City','to_location'=>'Bhuj','price'=>1900,'image'=>'assets/images/packages/kutch-white-desert/transport.jpg'],['type'=>'Private Cab','provider'=>'Kutch Private Cab','from_location'=>'Bhuj','to_location'=>'White Rann','price'=>3000,'image'=>'assets/images/packages/kutch-white-desert/transport.jpg']],
      'rishikesh'=>[['type'=>'Train','provider'=>'Rishikesh Express Train','from_location'=>'Your City','to_location'=>'Rishikesh','price'=>1700,'image'=>'assets/images/packages/rishikesh-adventure/transport.jpg'],['type'=>'Private Cab','provider'=>'Rishikesh Private Cab','from_location'=>'Rishikesh','to_location'=>'Ganga Route','price'=>2200,'image'=>'assets/images/packages/rishikesh-adventure/transport.jpg']]
    ];
    $transport=$transportMap[$key]??[['type'=>'Train','provider'=>$destination.' Express Train','from_location'=>'Your City','to_location'=>$destination,'price'=>1200,'image'=>'assets/images/placeholder.jpg'],['type'=>'Private Cab','provider'=>$destination.' Private Cab','from_location'=>$destination,'to_location'=>$destination.' Route','price'=>2200,'image'=>'assets/images/placeholder.jpg']];
    $hotelMap=[
      'leh'=>[['dest_name'=>'Leh','name'=>'Ladakh Mountain View Hotel','rating'=>4.2,'room_type'=>'Deluxe Room','price_per_night'=>2800,'image'=>'assets/images/packages/leh-ladakh/hotel.jpg'],['dest_name'=>'Leh','name'=>'Leh Himalayan Grand Hotel','rating'=>4.7,'room_type'=>'Premium Room','price_per_night'=>4200,'image'=>'assets/images/packages/leh-ladakh/hotel.jpg']],
      'jaipur'=>[['dest_name'=>'Jaipur','name'=>'Jaipur Heritage Palace Hotel','rating'=>4.3,'room_type'=>'Heritage Room','price_per_night'=>2600,'image'=>'assets/images/packages/rajasthan-royal/hotel.jpg'],['dest_name'=>'Jaipur','name'=>'Rajputana Royal Residency Hotel','rating'=>4.7,'room_type'=>'Royal Deluxe Room','price_per_night'=>3900,'image'=>'assets/images/packages/rajasthan-royal/hotel.jpg']],
      'ujjain'=>[['dest_name'=>'Ujjain','name'=>'Ujjain Sacred Stay Hotel','rating'=>4.2,'room_type'=>'Comfort Room','price_per_night'=>1800,'image'=>'assets/images/packages/ujjain-omkareshwar/hotel.jpg'],['dest_name'=>'Ujjain','name'=>'Mahakal Heritage Hotel','rating'=>4.6,'room_type'=>'Deluxe Room','price_per_night'=>2800,'image'=>'assets/images/packages/ujjain-omkareshwar/hotel.jpg']],
      'gir'=>[['dest_name'=>'Gir','name'=>'Gir Forest View Hotel','rating'=>4.2,'room_type'=>'Forest View Room','price_per_night'=>2200,'image'=>'assets/images/packages/gir-wildlife/hotel.jpg'],['dest_name'=>'Gir','name'=>'Gir Safari Retreat Hotel','rating'=>4.6,'room_type'=>'Safari Deluxe Room','price_per_night'=>3400,'image'=>'assets/images/packages/gir-wildlife/hotel.jpg']],
      'bhuj'=>[['dest_name'=>'Bhuj','name'=>'Kutch Desert View Hotel','rating'=>4.1,'room_type'=>'Desert View Room','price_per_night'=>2000,'image'=>'assets/images/packages/kutch-white-desert/hotel.jpg'],['dest_name'=>'Bhuj','name'=>'Rann Heritage Hotel','rating'=>4.6,'room_type'=>'Heritage Deluxe Room','price_per_night'=>3200,'image'=>'assets/images/packages/kutch-white-desert/hotel.jpg']],
      'rishikesh'=>[['dest_name'=>'Rishikesh','name'=>'Ganga Riverside Hotel','rating'=>4.3,'room_type'=>'River View Room','price_per_night'=>2200,'image'=>'assets/images/packages/rishikesh-adventure/hotel.jpg'],['dest_name'=>'Rishikesh','name'=>'Himalayan Adventure Retreat Hotel','rating'=>4.7,'room_type'=>'Premium Valley Room','price_per_night'=>3500,'image'=>'assets/images/packages/rishikesh-adventure/hotel.jpg']]
    ];
    $hotels=$hotelMap[$key]??[['dest_name'=>$destination,'name'=>$destination.' Comfort Hotel','rating'=>4.0,'room_type'=>'Comfort Room','price_per_night'=>1800,'image'=>'assets/images/placeholder.jpg'],['dest_name'=>$destination,'name'=>$destination.' Premium Hotel','rating'=>4.6,'room_type'=>'Deluxe Room','price_per_night'=>3000,'image'=>'assets/images/placeholder.jpg']];
    return ['transport'=>$transport,'hotels'=>$hotels,'activities'=>[['dest_name'=>$destination,'name'=>'Local Sightseeing','description'=>'Guided local highlights and sightseeing.','price'=>500],['dest_name'=>$destination,'name'=>'Adventure Experience','description'=>'Optional adventure experience for your trip.','price'=>900],['dest_name'=>$destination,'name'=>'Cultural Experience','description'=>'Discover local culture and traditions.','price'=>700]]];
}
function getTripRoute(array $trip, PDO $pdo=null){
    if($pdo){$package=getTourPackage($pdo,(int)($trip['package_id']??0)); if($package&&!empty($package['cities']))return $package['cities'];}
    $route=(string)($trip['estimated_distance']??''); if(stripos($route,'Package route:')===0){$route=trim(substr($route,14)); return array_values(array_filter(array_map('trim',preg_split('/\s*→\s*/u',$route))));}
    return [];
}

function buildGeneratedPackagePlan(array $package, string $category, int $travelers, float $budget){
    $options=getPlanOptions($package['cities']);
    $transport=$travelers>=3 ? ($options['transport'][1]??$options['transport'][0]) : ($options['transport'][0]??[]);
    $rooms=(int)ceil($travelers/2);
    $hotel=$options['hotels'][0]??[];
    $activityMap=[
        'Leh–Ladakh Adventure Expedition'=>[['name'=>'Mountain Sightseeing','description'=>'Guided highlights across Leh and the Himalayan landscape.'],['name'=>'Nubra Valley Exploration','description'=>'Scenic valley experience and local exploration.'],['name'=>'Pangong Lake Visit','description'=>'Visit the iconic high-altitude Pangong Lake.']],
        'Rajasthan Royal Heritage Journey'=>[['name'=>'Jaipur Heritage Tour','description'=>'Explore royal architecture and historic landmarks.'],['name'=>'Udaipur City Palace Experience','description'=>'Discover the lakeside royal heritage of Udaipur.'],['name'=>'Jaisalmer Fort Visit','description'=>'Experience the golden fort and desert heritage.']],
        'Ujjain–Omkareshwar Temple Tour'=>[['name'=>'Mahakaleshwar Temple Visit','description'=>'Sacred temple visit in Ujjain.'],['name'=>'Omkareshwar Jyotirlinga Visit','description'=>'Spiritual visit to Omkareshwar.'],['name'=>'Temple & Local Heritage Walk','description'=>'Explore local sacred and cultural places.']],
        'Gir Wildlife Safari Adventure'=>[['name'=>'Gir Jungle Safari','description'=>'Wildlife safari experience in Gir.'],['name'=>'Wildlife Interpretation Experience','description'=>'Learn about Gir wildlife and conservation.'],['name'=>'Somnath Heritage Visit','description'=>'Explore the nearby coastal heritage.']],
        'Kutch White Desert & Cultural Escape'=>[['name'=>'White Rann Experience','description'=>'Explore the iconic white desert landscape.'],['name'=>'Dhordo Cultural Experience','description'=>'Discover local crafts, traditions and culture.'],['name'=>'Kutch Heritage Exploration','description'=>'Experience the region’s heritage and local life.']],
        'Rishikesh Adventure & Spiritual Escape'=>[['name'=>'River Adventure Experience','description'=>'Enjoy a guided river-based adventure experience.'],['name'=>'Ganga Riverside Experience','description'=>'Relax and explore the Ganga riverside.'],['name'=>'Temple & Spiritual Visit','description'=>'Discover important spiritual places in Rishikesh.']]
    ];
    $activities=$activityMap[$package['name']]??($options['activities']??[]);
    $price=(float)$package['price']; $total=round($price*$travelers,2);
    return ['package_name'=>$package['name'],'package_category'=>$category,'package_total'=>$total,'price_per_person'=>$price,'transport'=>$transport,'hotel'=>$hotel,'hotel_rooms'=>$rooms,'meal_plan'=>'Breakfast + Lunch + Dinner','activities'=>$activities,'travelers'=>$travelers,'budget'=>$budget,'total_cost'=>$total,'destinations'=>$package['cities']];
}

function generateBookingReference(){ return 'BMT'.date('Y').strtoupper(substr(uniqid(),-6)); }
function generateTransactionId(){ return 'TXN'.strtoupper(substr(uniqid(),-10)); }
